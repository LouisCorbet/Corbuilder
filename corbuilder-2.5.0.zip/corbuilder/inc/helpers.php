<?php
defined( 'ABSPATH' ) || exit;

function corbuilder_defaults() {
	return array(
		'primary'            => '#2563eb',
		'secondary'          => '#0f766e',
		'accent'             => '#f59e0b',
		'light'              => '', // vide : teinte claire de la couleur secondaire
		'dark'               => '#111827',
		'radius'             => 12,
		'global_style'       => 'classique',
		'animation'          => 'none',
		'density'            => 'standard',
		'btn_style'          => 'solid',
		'btn_shape'          => 'theme',
		'card_style'         => 'shadow',
		'header_style'       => 'classic',
		'header_color'       => 'auto',
		'footer_color'       => 'auto',
		'header_image2'      => 0,
		'header_transparent' => false,
		'show_site_name'     => true,
		'hide_site_name_mobile' => false,
		'header_sticky'      => false,
		'header_height'      => 'normal',
		'editor_allow_bgimage' => true,
		'editor_zone_palette' => true,
		'editor_zone_dividers' => true,
		'editor_allow_lists' => false,
		'editor_zone_identity' => true,
		'editor_zone_icon'   => false,
		'editor_zone_contact' => true,
		'editor_zone_announce' => true,
		'editor_zone_footer' => true,
		'footer_style'       => 'simple',
		'footer_text'        => '© {year} {site}',
		'announce_on'        => false,
		'announce_text'      => '',
		'announce_url'       => '',
		'announce_closable'  => true,
		'classic_editor_posts' => true,
		'show_legal_links'   => true,
		'footer_title_main'  => '',
		'footer_title_menu1' => 'Navigation',
		'footer_title_menu2' => 'Informations',
		'footer_title_contact' => 'Contact',
		'footer_show_contact' => true,
		'footer_show_social' => true,
	);
}

function corbuilder_mod( $key ) {
	$d = corbuilder_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function corbuilder_color( $key ) {
	$d = corbuilder_defaults();
	$c = sanitize_hex_color( get_theme_mod( $key, $d[ $key ] ) );
	return $c ? $c : $d[ $key ];
}

/* ---------- Palette du site : 5 couleurs réglées dans Style → Couleurs, plus le blanc et le noir ---------- */
function corbuilder_palette_keys() {
	return array( 'primary', 'secondary', 'accent', 'light', 'dark' );
}

/* Libellés des couleurs de la palette ; « white » et « black » sont toujours disponibles */
function corbuilder_palette_labels() {
	return array(
		'primary'   => __( 'Couleur principale', 'corbuilder' ),
		'secondary' => __( 'Couleur secondaire', 'corbuilder' ),
		'accent'    => __( 'Couleur d’accent', 'corbuilder' ),
		'light'     => __( 'Fond clair', 'corbuilder' ),
		'dark'      => __( 'Fond sombre', 'corbuilder' ),
		'white'     => __( 'Blanc', 'corbuilder' ),
		'black'     => __( 'Noir', 'corbuilder' ),
	);
}

/* Couleur hexadécimale d'un choix de la palette ('' si le choix est inconnu). « tint » : ancien nom de « light ». */
function corbuilder_palette_hex( $key ) {
	switch ( 'tint' === $key ? 'light' : $key ) {
		case 'primary':
			return corbuilder_color( 'primary' );
		case 'secondary':
			return corbuilder_color( 'secondary' );
		case 'accent':
			return corbuilder_color( 'accent' );
		case 'light':
			$hex = sanitize_hex_color( (string) get_theme_mod( 'light', '' ) );
			return $hex ? $hex : corbuilder_tint( corbuilder_color( 'secondary' ), 0.9 );
		case 'dark':
			return corbuilder_color( 'dark' );
		case 'white':
			return '#ffffff';
		case 'black':
			return '#000000';
	}
	return '';
}

/* Choix de couleur proposés dans les listes : la palette, avec en option « Aucune » en tête */
function corbuilder_palette_choices( $with_none = false ) {
	$choices = $with_none ? array( 'none' => __( 'Aucune', 'corbuilder' ) ) : array();
	return $choices + corbuilder_palette_labels();
}

/* Couleur de la palette la plus proche d'une couleur saisie (migration des anciennes « couleurs personnalisées ») */
function corbuilder_nearest_palette_key( $hex ) {
	$hex = sanitize_hex_color( (string) $hex );
	if ( ! $hex ) {
		return 'primary';
	}
	list( $r, $g, $b ) = corbuilder_hex_to_rgb( $hex );
	$best = 'primary';
	$min  = PHP_INT_MAX;
	foreach ( array_keys( corbuilder_palette_labels() ) as $key ) {
		list( $pr, $pg, $pb ) = corbuilder_hex_to_rgb( corbuilder_palette_hex( $key ) );
		$dist = ( $r - $pr ) * ( $r - $pr ) + ( $g - $pg ) * ( $g - $pg ) + ( $b - $pb ) * ( $b - $pb );
		if ( $dist < $min ) {
			$min  = $dist;
			$best = $key;
		}
	}
	return $best;
}

/* ---------- Couleurs ---------- */
function corbuilder_hex_to_rgb( $hex ) {
	$hex = ltrim( $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
}

function corbuilder_rgb_to_hex( $rgb ) {
	return sprintf( '#%02x%02x%02x', round( $rgb[0] ), round( $rgb[1] ), round( $rgb[2] ) );
}

/* Texte clair ou foncé selon la couleur de fond */
function corbuilder_contrast( $hex ) {
	list( $r, $g, $b ) = corbuilder_hex_to_rgb( $hex );
	return ( ( $r * 299 + $g * 587 + $b * 114 ) / 1000 ) >= 150 ? '#111827' : '#ffffff';
}

/* Éclaircit une couleur (mélange avec du blanc) */
function corbuilder_tint( $hex, $t = 0.9 ) {
	list( $r, $g, $b ) = corbuilder_hex_to_rgb( $hex );
	return corbuilder_rgb_to_hex( array( $r * ( 1 - $t ) + 255 * $t, $g * ( 1 - $t ) + 255 * $t, $b * ( 1 - $t ) + 255 * $t ) );
}

/* ---------- Textes ---------- */
function corbuilder_allowed_html() {
	return array(
		'a'      => array( 'href' => array(), 'title' => array(), 'target' => array(), 'rel' => array() ),
		'strong' => array(),
		'em'     => array(),
		'br'     => array(),
		'ul'     => array(),
		'ol'     => array(),
		'li'     => array(),
	);
}

function corbuilder_sanitize_html( $value ) {
	return wp_kses( is_scalar( $value ) ? (string) $value : '', corbuilder_allowed_html() );
}

/* URL http(s) : une fonction à un seul paramètre, car le Customizer transmet aussi l'objet du réglage */
function corbuilder_sanitize_url( $value ) {
	return esc_url_raw( is_scalar( $value ) ? (string) $value : '', array( 'http', 'https' ) );
}

function corbuilder_sanitize_checkbox( $value ) {
	return (bool) $value;
}

function corbuilder_text( $text ) {
	return wpautop( corbuilder_sanitize_html( $text ) );
}

/* Texte avec listes à puces simples : les lignes qui commencent par « - » (ou « * ») deviennent une liste ; le HTML reste permis */
function corbuilder_text_with_lists( $text ) {
	$out  = array();
	$list = array();
	foreach ( explode( "\n", str_replace( array( "\r\n", "\r" ), "\n", (string) $text ) ) as $line ) {
		if ( preg_match( '/^\s*[-*•]\s+(.+)$/u', $line, $m ) ) {
			$list[] = '<li>' . trim( $m[1] ) . '</li>';
			continue;
		}
		if ( $list ) {
			$out[] = '<ul>' . implode( '', $list ) . '</ul>';
			$list  = array();
		}
		$out[] = $line;
	}
	if ( $list ) {
		$out[] = '<ul>' . implode( '', $list ) . '</ul>';
	}
	return corbuilder_text( implode( "\n", $out ) );
}

function corbuilder_image( $id, $size = 'large', $attr = array() ) {
	$id = absint( $id );
	return $id ? wp_get_attachment_image( $id, $size, false, $attr ) : '';
}

/* ---------- Pages ---------- */
/* Adresse à afficher dans l'aperçu du Customizer : le lien d'aperçu pour une page pas encore publiée */
function corbuilder_page_preview_url( $page ) {
	return 'publish' === $page->post_status ? get_permalink( $page ) : get_preview_post_link( $page );
}

function corbuilder_get_pages() {
	$args  = apply_filters( 'corbuilder_customizer_pages_args', array(
		'post_status' => array( 'publish', 'draft', 'private' ), // les brouillons aussi : on peut les remplir dans Personnaliser avant de les publier
		'sort_column' => 'menu_order,post_title',
		'exclude'     => array_filter( array( (int) get_option( 'page_for_posts' ) ) ),
		'number'      => 40,
	) );
	$pages = get_pages( $args );
	return $pages ? $pages : array();
}

/* ---------- Variables CSS issues des réglages ---------- */
function corbuilder_spacing_values() {
	return array(
		'none'     => '0',
		'compact'  => 'clamp(2rem,4vw,3rem)',
		'standard' => 'clamp(3rem,7vw,5.5rem)',
		'spacious' => 'clamp(4.5rem,10vw,8rem)',
	);
}

/* Écarts de l'en-tête des sections (titre → sous-titre, sous-titre → description, description → contenu) et avant le bouton de fin de section, selon la densité */
function corbuilder_head_gap_values() {
	return array(
		'compact'  => array( '.5rem', '1rem', '2.5rem', '2.25rem' ),
		'standard' => array( '.75rem', '1.5rem', '3.5rem', '3rem' ),
		'spacious' => array( '1rem', '2rem', '4.5rem', '4rem' ),
	);
}

function corbuilder_head_gap_css( $key ) {
	$all = corbuilder_head_gap_values();
	$g   = isset( $all[ $key ] ) ? $all[ $key ] : $all['standard'];
	return '--head-title-gap:' . $g[0] . ';--head-sub-gap:' . $g[1] . ';--head-end:' . $g[2] . ';--end-gap:' . $g[3] . ';';
}

/* Couleur d'un élément (« header » ou « footer ») : « auto » = celle de son style */
function corbuilder_surface_choices() {
	return array( 'auto' => __( 'Selon le style choisi', 'corbuilder' ) ) + corbuilder_palette_labels();
}

function corbuilder_surface_hex( $part ) {
	$choice = (string) corbuilder_mod( $part . '_color' );
	if ( 'custom' === $choice ) { // ancienne couleur personnalisée (avant la palette) : la couleur de la palette la plus proche
		$choice = corbuilder_nearest_palette_key( get_theme_mod( $part . '_color_custom', '' ) );
	}
	return ( 'auto' === $choice ) ? '' : corbuilder_palette_hex( $choice );
}

function corbuilder_root_css() {
	$primary   = corbuilder_color( 'primary' );
	$secondary = corbuilder_color( 'secondary' );
	$radius    = max( 0, min( 60, absint( corbuilder_mod( 'radius' ) ) ) );
	$spacing   = corbuilder_spacing_values();
	$density   = corbuilder_mod( 'density' );
	$shapes    = array( 'theme' => 'var(--radius)', 'pill' => '999px', 'square' => '0' );
	$shape     = corbuilder_mod( 'btn_shape' );

	$css  = ':root{';
	$css .= '--c-primary:' . $primary . ';';
	$css .= '--c-primary-text:' . corbuilder_contrast( $primary ) . ';';
	$css .= '--c-secondary:' . $secondary . ';';
	$css .= '--c-secondary-text:' . corbuilder_contrast( $secondary ) . ';';
	$light     = corbuilder_palette_hex( 'light' );
	$css .= '--c-secondary-tint:' . $light . ';--c-light:' . $light . ';--c-light-text:' . corbuilder_contrast( $light ) . ';';
	$css .= '--c-accent:' . corbuilder_color( 'accent' ) . ';--c-accent-text:' . corbuilder_contrast( corbuilder_color( 'accent' ) ) . ';';
	$css .= '--c-dark:' . corbuilder_color( 'dark' ) . ';--c-dark-text:' . corbuilder_contrast( corbuilder_color( 'dark' ) ) . ';';
	$css .= '--radius:' . $radius . 'px;';
	$css .= '--section-pad:' . ( isset( $spacing[ $density ] ) ? $spacing[ $density ] : $spacing['standard'] ) . ';';
	$css .= corbuilder_head_gap_css( $density );
	foreach ( array( 'header', 'footer' ) as $part ) { // couleur choisie : fond, texte (clair ou foncé selon le contraste), filets
		$hex = corbuilder_surface_hex( $part );
		if ( $hex ) {
			$fg    = corbuilder_contrast( $hex );
			$light = '#ffffff' === $fg;
			$css  .= '--' . $part . '-bg:' . $hex . ';--' . $part . '-fg:' . $fg . ';--' . $part . '-line:' . ( $light ? 'rgba(255,255,255,.3)' : 'rgba(0,0,0,.14)' ) . ';';
			if ( 'header' === $part ) {
				$css .= '--header-hover:' . $fg . ';--header-toggle:' . ( $light ? 'rgba(255,255,255,.55)' : 'rgba(0,0,0,.35)' ) . ';';
			}
		}
	}
	$css .= '--btn-radius:' . ( isset( $shapes[ $shape ] ) ? $shapes[ $shape ] : $shapes['theme'] ) . ';';
	$css .= '}';
	return $css;
}

/* ---------- Morceaux d'en-tête et de pied de page (partagés par les variantes) ---------- */
function corbuilder_brand_html() {
	$html = '<div class="brand">';
	if ( has_custom_logo() ) {
		$html .= get_custom_logo();
	}
	if ( corbuilder_mod( 'show_site_name' ) || ! has_custom_logo() ) {
		$html .= '<a class="site-title" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
	} else { // logo seul : le nom reste dans la page (lecteurs d'écran, référencement), masqué visuellement
		$html .= '<span class="site-title screen-reader-text">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
	}
	return $html . '</div>';
}

/* Menu de l'en-tête. $split : le dernier lien du 1er niveau est sorti dans une seconde liste (bouton à droite, en-tête « Menu centré ») */
function corbuilder_nav_html( $split = false ) {
	if ( ! has_nav_menu( 'primary' ) ) {
		return '';
	}
	$args = array( 'theme_location' => 'primary', 'container' => false, 'depth' => 2, 'echo' => false );
	if ( $split ) {
		$menu = wp_nav_menu( $args + array( 'menu_id' => 'menu-main', 'corbuilder_part' => 'main' ) )
			. wp_nav_menu( $args + array( 'menu_id' => 'menu-cta', 'menu_class' => 'menu menu--cta', 'corbuilder_part' => 'cta' ) );
	} else {
		$menu = wp_nav_menu( $args );
	}
	$cls = 'main-nav' . ( '' !== corbuilder_menu_buttons_mode() ? ' main-nav--has-buttons' : '' ) . ( $split ? ' main-nav--split' : '' );
	return '<button class="nav-toggle" aria-expanded="false" aria-controls="site-nav" aria-label="' . esc_attr__( 'Menu', 'corbuilder' ) . '"><span class="nav-toggle__bars" aria-hidden="true"></span></button>'
		. '<nav id="site-nav" class="' . esc_attr( $cls ) . '" aria-label="' . esc_attr__( 'Menu principal', 'corbuilder' ) . '">' . $menu . '</nav>';
}

/* En-tête « Menu centré » : la liste « main » garde tous les liens sauf le dernier, la liste « cta » ne garde que lui (avec ses sous-éléments) */
function corbuilder_split_menu_items( $items, $args ) {
	if ( empty( $args->corbuilder_part ) ) {
		return $items;
	}
	$last = null;
	foreach ( $items as $k => $item ) {
		if ( ! (int) $item->menu_item_parent ) {
			$last = $item->ID;
		}
	}
	$keep = array();
	foreach ( $items as $k => $item ) { // le dernier lien du 1er niveau et ses descendants
		if ( $item->ID === $last || in_array( (int) $item->menu_item_parent, $keep, true ) ) {
			$keep[] = (int) $item->ID;
		}
	}
	foreach ( $items as $k => $item ) {
		$is_cta = in_array( (int) $item->ID, $keep, true );
		if ( ( 'cta' === $args->corbuilder_part ) !== $is_cta ) {
			unset( $items[ $k ] );
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'corbuilder_split_menu_items', 20, 2 ); // après le repérage des boutons (priorité 10), qui se fait sur la liste complète

/* Liens du 1er niveau affichés en boutons : clé « buttons » de l'en-tête choisi ('last' = le dernier, 'all' = tous, sinon aucun) */
function corbuilder_menu_buttons_mode() {
	$header = corbuilder_selected( 'header' );
	return ( $header && isset( $header['buttons'] ) && in_array( $header['buttons'], array( 'last', 'all' ), true ) ) ? $header['buttons'] : '';
}

function corbuilder_menu_objects( $items, $args ) {
	$mode = corbuilder_menu_buttons_mode();
	if ( '' === $mode || empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $items;
	}
	$last = null;
	foreach ( $items as $k => $item ) {
		if ( ! (int) $item->menu_item_parent ) {
			$last = $k;
		}
	}
	foreach ( $items as $k => $item ) {
		if ( ! (int) $item->menu_item_parent && ( 'all' === $mode || $k === $last ) ) {
			$item->classes[] = 'menu-item--btn';
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'corbuilder_menu_objects', 10, 2 );

function corbuilder_menu_link_attributes( $atts, $item, $args, $depth ) {
	if ( 0 === $depth && ! empty( $args->theme_location ) && 'primary' === $args->theme_location && in_array( 'menu-item--btn', (array) $item->classes, true ) ) {
		$atts['class'] = trim( ( isset( $atts['class'] ) ? $atts['class'] . ' ' : '' ) . 'btn' );
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'corbuilder_menu_link_attributes', 10, 4 );

function corbuilder_footer_text() {
	$t = str_replace( array( '{year}', '{site}' ), array( gmdate( 'Y' ), get_bloginfo( 'name' ) ), (string) corbuilder_mod( 'footer_text' ) );
	return wpautop( wp_kses_post( $t ) );
}

/* Menu d'un emplacement du pied de page ('footer' ou 'footer2') ; vide si aucun menu n'y est affecté */
function corbuilder_footer_nav_html( $location = 'footer', $depth = 1 ) {
	if ( ! has_nav_menu( $location ) ) {
		return '';
	}
	$menu   = (string) wp_nav_menu( array( 'theme_location' => $location, 'container' => false, 'depth' => $depth, 'echo' => false ) );
	$labels = array(
		'footer'  => __( 'Menu du pied de page', 'corbuilder' ),
		'footer2' => __( 'Menu du pied de page, 2e colonne', 'corbuilder' ),
	);
	$label = isset( $labels[ $location ] ) ? $labels[ $location ] : __( 'Navigation du site', 'corbuilder' );
	return '<nav class="footer-nav" aria-label="' . esc_attr( $label ) . '">' . $menu . '</nav>';
}

/* Titre d'une colonne du pied de page (réglage du Customizer) ; vide = aucun titre, sauf valeur de repli */
function corbuilder_footer_col_title( $key, $fallback = '' ) {
	$title = trim( (string) corbuilder_mod( $key ) );
	if ( '' === $title ) {
		$title = $fallback;
	}
	return '' === $title ? '' : '<p class="footer-title">' . esc_html( $title ) . '</p>';
}

function corbuilder_render_header() {
	$def = corbuilder_selected( 'header' );
	if ( $def ) {
		call_user_func( $def['render'] );
	}
}

function corbuilder_render_footer() {
	$def = corbuilder_selected( 'footer' );
	if ( $def ) {
		call_user_func( $def['render'] );
	}
}

/* Barre d'annonce (fermable, mémorisée par texte) */
function corbuilder_announcement_bar() {
	if ( ! corbuilder_mod( 'announce_on' ) || '' === trim( (string) corbuilder_mod( 'announce_text' ) ) ) {
		return;
	}
	$text = (string) corbuilder_mod( 'announce_text' );
	$url  = (string) corbuilder_mod( 'announce_url' );
	$id   = 'a' . substr( md5( $text . $url ), 0, 8 );

	echo '<div class="announce" id="announce" data-id="' . esc_attr( $id ) . '"><div class="wrap announce__inner">';
	echo $url ? '<a href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>' : '<span>' . esc_html( $text ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( corbuilder_mod( 'announce_closable' ) ) {
		echo '<button type="button" class="announce__close" aria-label="' . esc_attr__( 'Fermer', 'corbuilder' ) . '">×</button>';
	}
	echo '</div></div>';
	echo '<script>(function(){var a=document.getElementById("announce");if(!a)return;var k="corbuilder_ann";try{if(localStorage.getItem(k)===a.dataset.id){a.hidden=true;return}}catch(e){}var b=a.querySelector(".announce__close");if(b)b.addEventListener("click",function(){a.hidden=true;try{localStorage.setItem(k,a.dataset.id)}catch(e){}})})();</script>';
}
