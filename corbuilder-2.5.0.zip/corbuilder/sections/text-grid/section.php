<?php
/**
 * Section « Texte + éléments » : la disposition de « Image + texte », avec une grille de 4 images au plus (2 × 2)
 * à la place de l'image, chacune avec une légende facultative.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Texte + éléments', 'corbuilder' ),
	'description' => __( 'Du texte d’un côté, une grille de 4 images au plus (2 × 2) de l’autre, chacune avec une légende facultative.', 'corbuilder' ),
	'order'       => 21,
	'head_align'  => false, // il a son propre réglage d'alignement du texte (« text_align »)
	'fields'      => array(
		'items'        => array(
			'type'       => 'repeater',
			'label'      => __( 'Images (4 au maximum)', 'corbuilder' ),
			'item_label' => __( 'Image', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une image', 'corbuilder' ),
			'max'        => 4,
			'fields'     => array(
				'image'   => array( 'type' => 'image', 'label' => __( 'Image', 'corbuilder' ) ),
				'caption' => array( 'type' => 'text', 'label' => __( 'Légende (facultative)', 'corbuilder' ) ),
			),
		),
		'image_side'   => array(
			'type'    => 'select',
			'label'   => __( 'Position des images', 'corbuilder' ),
			'choices' => array(
				'left'  => __( 'À gauche', 'corbuilder' ),
				'right' => __( 'À droite', 'corbuilder' ),
			),
		),
		'ratio'        => array(
			'type'    => 'select',
			'label'   => __( 'Format des images', 'corbuilder' ),
			'choices' => array(
				'square' => __( 'Carré', 'corbuilder' ),
				'43'     => __( '4:3', 'corbuilder' ),
				'32'     => __( '3:2', 'corbuilder' ),
			),
			'default' => 'square',
		),
		'image_shadow' => array(
			'type'    => 'select',
			'label'   => __( 'Ombre des images', 'corbuilder' ),
			'choices' => array(
				'none'   => __( 'Aucune', 'corbuilder' ),
				'soft'   => __( 'Légère', 'corbuilder' ),
				'strong' => __( 'Prononcée', 'corbuilder' ),
			),
			'default' => 'none',
		),
		'text_align'   => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du texte', 'corbuilder' ),
			'choices' => array(
				'left'    => __( 'À gauche', 'corbuilder' ),
				'right'   => __( 'À droite', 'corbuilder' ),
				'justify' => __( 'Justifié', 'corbuilder' ),
				'center'  => __( 'Centré', 'corbuilder' ),
			),
		),
		'title'        => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'     => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'         => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'button'       => array( 'type' => 'button', 'label' => __( 'Bouton (facultatif)', 'corbuilder' ) ),
		'button2'    => array( 'type' => 'button', 'label' => __( 'Second bouton (facultatif)', 'corbuilder' ) ),
	),
	'render'      => function ( $d ) {
		$figs  = '';
		$count = 0;
		foreach ( array_slice( array_values( (array) $d['items'] ), 0, 4 ) as $it ) {
			$img = ( is_array( $it ) && ! empty( $it['image'] ) ) ? corbuilder_image( absint( $it['image'] ), 'medium_large' ) : '';
			if ( '' === $img ) { // une image par élément : sans image, l'élément n'est pas affiché
				continue;
			}
			$count++;
			$figs .= '<figure class="elements__item"><div class="elements__img">' . $img . '</div>';
			if ( ! empty( $it['caption'] ) && '' !== trim( (string) $it['caption'] ) ) {
				$figs .= '<figcaption class="elements__caption">' . esc_html( $it['caption'] ) . '</figcaption>';
			}
			$figs .= '</figure>';
		}

		$ratio  = in_array( $d['ratio'], array( 'square', '43', '32' ), true ) ? $d['ratio'] : 'square';
		$shadow = in_array( $d['image_shadow'], array( 'soft', 'strong' ), true ) ? ' elements--shadow-' . $d['image_shadow'] : '';

		echo '<div class="single__grid' . ( $count ? '' : ' single__grid--noimg' ) . ( 'right' === $d['image_side'] ? ' single__grid--right' : '' ) . '">';
		if ( $count ) {
			echo '<div class="single__media elements elements--ratio-' . esc_attr( $ratio ) . $shadow . ( 1 === $count ? ' elements--n1' : '' ) . ' anim">' . $figs . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<div class="single__body single__body--align-' . esc_attr( $d['text_align'] ) . ' anim">';
		if ( '' !== $d['title'] ) {
			echo '<h2 class="section__title">' . esc_html( $d['title'] ) . '</h2>';
		}
		if ( '' !== $d['subtitle'] ) {
			echo '<h3 class="section__subtitle">' . esc_html( $d['subtitle'] ) . '</h3>';
		}
		if ( '' !== trim( (string) $d['text'] ) ) {
			echo '<div class="section__text">' . corbuilder_text( $d['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		$btn = corbuilder_button( $d['button'] ) . corbuilder_button( $d['button2'], 'btn--secondary' );
		if ( '' !== $btn ) {
			echo '<div class="section__actions">' . $btn . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	},
);
