<?php
/**
 * Section « Compteurs » : une liste de chiffres clés (ajout et suppression libres).
 * Chaque compteur : chiffre, préfixe et suffixe (position normale, indice haut ou indice bas), description,
 * « Animation du compteur » (le chiffre part de 0 et monte jusqu'à sa valeur en 2 secondes quand il devient visible) et couleur.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'corbuilder_counter_parse' ) ) {
	/* Chiffre saisi -> valeur, nombre de décimales, séparateurs ; null si ce n'est pas un nombre simple (ex. « 24/7 ») : pas d'animation */
	function corbuilder_counter_parse( $raw ) {
		$t       = trim( (string) $raw );
		$compact = preg_replace( '/[\s\x{00A0}\x{202F}]+/u', '', $t );
		if ( '' === $compact ) {
			return null;
		}
		if ( preg_match( '/^\d{1,3}(\.\d{3})+$/', $compact ) ) { // 1.250 : point des milliers
			return array( 'to' => (float) str_replace( '.', '', $compact ), 'decimals' => 0, 'sep' => ',', 'group' => 'dot' );
		}
		if ( preg_match( '/^\d+(?:([.,])(\d+))?$/', $compact, $m ) ) {
			return array(
				'to'       => (float) str_replace( ',', '.', $compact ),
				'decimals' => isset( $m[2] ) ? strlen( $m[2] ) : 0,
				'sep'      => ! empty( $m[1] ) ? $m[1] : ',',
				'group'    => preg_match( '/\d[\s\x{00A0}\x{202F}]+\d/u', $t ) ? 'space' : '', // « 1 250 » : espace des milliers
			);
		}
		return null;
	}
}

$corbuilder_counter_fix_pos = array(
	'normal' => __( 'Normale', 'corbuilder' ),
	'sup'    => __( 'Indice haut', 'corbuilder' ),
	'sub'    => __( 'Indice bas', 'corbuilder' ),
);

$corbuilder_counter_fields = array(
	'number'       => array( 'type' => 'text', 'label' => __( 'Chiffre (ex. 1 250 ou 4,8)', 'corbuilder' ) ),
	'prefix'       => array( 'type' => 'text', 'label' => __( 'Préfixe (ex. dès, €)', 'corbuilder' ) ),
	'prefix_pos'   => array( 'type' => 'select', 'label' => __( 'Position du préfixe', 'corbuilder' ), 'choices' => $corbuilder_counter_fix_pos, 'default' => 'normal' ),
	'suffix'       => array( 'type' => 'text', 'label' => __( 'Suffixe (ex. ans, +, %)', 'corbuilder' ) ),
	'suffix_pos'   => array( 'type' => 'select', 'label' => __( 'Position du suffixe', 'corbuilder' ), 'choices' => $corbuilder_counter_fix_pos, 'default' => 'normal' ),
	'desc'         => array( 'type' => 'text', 'label' => __( 'Description', 'corbuilder' ) ),
	'animate'      => array( 'type' => 'checkbox', 'label' => __( 'Animation du compteur', 'corbuilder' ) ),
	'color'        => array(
		'type'    => 'select',
		'label'   => __( 'Couleur du compteur', 'corbuilder' ),
		'choices' => array_slice( corbuilder_palette_labels(), 0, 5, true ) + array( 'text' => __( 'Couleur du texte du site', 'corbuilder' ) ) + array_slice( corbuilder_palette_labels(), 5, null, true ),
		'default' => 'primary',
	),
);

return array(
	'label'       => __( 'Compteurs', 'corbuilder' ),
	'description' => __( 'Des chiffres clés (années d’expérience, clients, note moyenne…), avec une animation facultative du chiffre pour chaque compteur.', 'corbuilder' ),
	'order'       => 34,
	'fields'      => array(
		'title'    => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'columns'  => corbuilder_card_columns_field( 'auto', true ),
		'items'    => array(
			'type'       => 'repeater',
			'label'      => __( 'Liste des compteurs', 'corbuilder' ),
			'item_label' => __( 'Compteur', 'corbuilder' ),
			'add_label'  => __( 'Ajouter un compteur', 'corbuilder' ),
			'max'        => 12,
			'fields'     => $corbuilder_counter_fields,
		),
	),
	'skip'        => function ( $d ) {
		return empty( $d['items'] ) || ! is_array( $d['items'] );
	},
	'render'      => function ( $d ) use ( $corbuilder_counter_fields ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$defaults = corbuilder_field_defaults( corbuilder_normalize_fields( $corbuilder_counter_fields ) );
		$fix      = function ( $text, $pos, $side ) {
			if ( '' === trim( (string) $text ) ) {
				return '';
			}
			$pos = in_array( $pos, array( 'sup', 'sub' ), true ) ? $pos : 'normal';
			return '<span class="counter__fix counter__fix--' . $pos . ' counter__fix--' . $side . '">' . esc_html( $text ) . '</span>';
		};

		$cols     = isset( $d['columns'] ) ? (string) $d['columns'] : 'auto';
		$class    = 'counters' . ( ( 'auto' !== $cols && '' !== $cols ) ? ' counters--' . sanitize_html_class( $cols ) : '' );
		$animated = false;
		$html     = '<div class="' . esc_attr( $class ) . '">';

		foreach ( array_values( $d['items'] ) as $i => $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			$it    = array_merge( $defaults, $it );
			$num   = trim( (string) $it['number'] );
			$color = corbuilder_color_choice_css( (string) $it['color'], '', isset( $it['color_custom'] ) ? $it['color_custom'] : '' );
			$style = '--i:' . (int) $i . ';' . ( '' !== $color ? '--counter-color:' . $color . ';' : '' );

			$num_html = '';
			if ( '' !== $num ) {
				$p = ! empty( $it['animate'] ) ? corbuilder_counter_parse( $num ) : null;
				if ( $p ) {
					$animated  = true;
					$num_html  = sprintf(
						'<span class="counter__num" aria-hidden="true" data-to="%s" data-decimals="%d" data-sep="%s" data-group="%s" data-final="%s">%s</span><span class="counter__sr">%s</span>',
						esc_attr( number_format( $p['to'], $p['decimals'], '.', '' ) ),
						(int) $p['decimals'],
						esc_attr( $p['sep'] ),
						esc_attr( $p['group'] ),
						esc_attr( $num ),
						esc_html( $num ),
						esc_html( $num )
					);
				} else {
					$num_html = '<span class="counter__num">' . esc_html( $num ) . '</span>';
				}
			}

			$html .= '<div class="counter anim" style="' . esc_attr( $style ) . '"><span class="counter__value">'
				. $fix( $it['prefix'], $it['prefix_pos'], 'before' ) . $num_html . $fix( $it['suffix'], $it['suffix_pos'], 'after' ) . '</span>';
			if ( '' !== trim( (string) $it['desc'] ) ) {
				$html .= '<p class="counter__desc">' . esc_html( $it['desc'] ) . '</p>';
			}
			$html .= '</div>';
		}
		echo $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput

		if ( $animated ) {
			wp_enqueue_script( 'corbuilder-counters', get_template_directory_uri() . '/assets/counters.js', array(), CORBUILDER_VERSION, true );
		}
	},
);
