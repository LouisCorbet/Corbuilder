<?php
/**
 * Section « Tableau » : un tableau de 6 colonnes au plus, rempli ligne par ligne.
 * Une ligne = une liste de cellules ; la première ligne peut servir d'en-têtes. Les colonnes entièrement vides sont ignorées.
 * Sur mobile, le tableau défile horizontalement ou s'empile (chaque ligne devient un bloc, avec le nom de sa colonne).
 */
defined( 'ABSPATH' ) || exit;

/* Cellules d'une ligne : « c1 » à « c6 » */
if ( ! function_exists( 'corbuilder_table_cell_fields' ) ) {
function corbuilder_table_cell_fields() {
	$fields = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		/* translators: %d : numéro de la colonne */
		$fields[ 'c' . $i ] = array( 'type' => 'text', 'label' => sprintf( __( 'Colonne %d', 'corbuilder' ), $i ) );
	}
	return $fields;
}
}

/* Lignes utiles : [ [ cellules… ], … ], avec autant de cellules par ligne que de colonnes remplies (les colonnes vides à droite sont retirées) */
if ( ! function_exists( 'corbuilder_table_rows' ) ) {
function corbuilder_table_rows( $d ) {
	$rows = array();
	$cols = 0;
	foreach ( (array) $d['rows'] as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$cells = array();
		for ( $i = 1; $i <= 6; $i++ ) {
			$cells[] = isset( $row[ 'c' . $i ] ) ? trim( (string) $row[ 'c' . $i ] ) : '';
			if ( '' !== end( $cells ) ) {
				$cols = max( $cols, $i );
			}
		}
		$rows[] = $cells;
	}
	foreach ( $rows as $k => $cells ) {
		$rows[ $k ] = array_slice( $cells, 0, max( 1, $cols ) );
	}
	return $rows;
}
}

return array(
	'label'       => __( 'Tableau', 'corbuilder' ),
	'description' => __( 'Un tableau de 6 colonnes au plus, rempli ligne par ligne (tarifs, horaires, comparatif…). La première ligne peut servir d’en-têtes.', 'corbuilder' ),
	'order'       => 41,
	'head_align'  => 'center',
	'fields'      => array(
		'title'       => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'    => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'        => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'rows'        => array(
			'type'       => 'repeater',
			'label'      => __( 'Lignes du tableau (les colonnes laissées vides à droite ne s’affichent pas)', 'corbuilder' ),
			'item_label' => __( 'Ligne', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une ligne', 'corbuilder' ),
			'max'        => 60,
			'fields'     => corbuilder_table_cell_fields(),
		),
		'header_row'  => array( 'type' => 'checkbox', 'label' => __( 'La première ligne contient les en-têtes de colonnes', 'corbuilder' ), 'default' => true ),
		'first_col'   => array( 'type' => 'checkbox', 'label' => __( 'La première colonne est mise en avant (texte en gras)', 'corbuilder' ) ),
		'caption'     => array( 'type' => 'text', 'label' => __( 'Légende sous le tableau (facultative)', 'corbuilder' ) ),
		'style'       => array(
			'type'    => 'select',
			'label'   => __( 'Présentation', 'corbuilder' ),
			'choices' => array(
				'lines' => __( 'Filets horizontaux', 'corbuilder' ),
				'grid'  => __( 'Quadrillé', 'corbuilder' ),
			),
			'default' => 'lines',
		),
		'striped'     => array( 'type' => 'checkbox', 'label' => __( 'Lignes alternées (une sur deux teintée)', 'corbuilder' ), 'default' => true ),
		'cell_align'  => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du texte des cellules', 'corbuilder' ),
			'choices' => array(
				'left'   => __( 'À gauche', 'corbuilder' ),
				'center' => __( 'Centré', 'corbuilder' ),
				'right'  => __( 'À droite', 'corbuilder' ),
			),
			'default' => 'left',
		),
		'width'       => array(
			'type'    => 'select',
			'label'   => __( 'Largeur du tableau', 'corbuilder' ),
			'choices' => array(
				'medium' => __( 'Moyenne', 'corbuilder' ),
				'wide'   => __( 'Pleine largeur', 'corbuilder' ),
			),
			'default' => 'medium',
		),
		'mobile'      => array(
			'type'    => 'select',
			'label'   => __( 'Sur mobile', 'corbuilder' ),
			'choices' => array(
				'scroll' => __( 'Le tableau défile horizontalement', 'corbuilder' ),
				'stack'  => __( 'Les lignes s’empilent (le nom de la colonne précède chaque valeur)', 'corbuilder' ),
			),
			'default' => 'scroll',
		),
	),
	'skip'        => function ( $d ) {
		if ( '' !== $d['title'] || '' !== $d['subtitle'] || '' !== trim( (string) $d['text'] ) ) {
			return false;
		}
		foreach ( corbuilder_table_rows( $d ) as $cells ) {
			if ( array_filter( $cells, 'strlen' ) ) {
				return false;
			}
		}
		return true;
	},
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$rows = corbuilder_table_rows( $d );
		if ( ! $rows ) {
			return;
		}
		$has_head = ! empty( $d['header_row'] );
		$head     = $has_head ? array_shift( $rows ) : array();
		$align    = in_array( $d['cell_align'], array( 'left', 'center', 'right' ), true ) ? $d['cell_align'] : 'left';
		$class    = 'data-table data-table--' . ( 'grid' === $d['style'] ? 'grid' : 'lines' )
			. ( ! empty( $d['striped'] ) ? ' data-table--striped' : '' )
			. ( ! empty( $d['first_col'] ) ? ' data-table--first-bold' : '' )
			. ( 'stack' === $d['mobile'] ? ' data-table--stack' : '' );

		$html  = '<div class="table-wrap table-wrap--' . ( 'wide' === $d['width'] ? 'wide' : 'medium' ) . ' anim" style="--cell-align:' . esc_attr( $align ) . '">';
		$html .= '<div class="table__scroll" role="region" tabindex="0" aria-label="' . esc_attr( '' !== $d['title'] ? $d['title'] : __( 'Tableau', 'corbuilder' ) ) . '">';
		$html .= '<table class="' . esc_attr( $class ) . '">';
		if ( '' !== trim( (string) $d['caption'] ) ) {
			$html .= '<caption>' . esc_html( $d['caption'] ) . '</caption>';
		}
		if ( $head ) {
			$html .= '<thead><tr>';
			foreach ( $head as $cell ) {
				$html .= '<th scope="col">' . esc_html( $cell ) . '</th>';
			}
			$html .= '</tr></thead>';
		}
		$html .= '<tbody>';
		foreach ( $rows as $cells ) {
			$html .= '<tr>';
			foreach ( $cells as $i => $cell ) {
				$label = ( $head && isset( $head[ $i ] ) && '' !== $head[ $i ] ) ? ' data-label="' . esc_attr( $head[ $i ] ) . '"' : '';
				$html .= ( 0 === $i && ! empty( $d['first_col'] ) )
					? '<th scope="row"' . $label . '>' . esc_html( $cell ) . '</th>'
					: '<td' . $label . '>' . esc_html( $cell ) . '</td>';
			}
			$html .= '</tr>';
		}
		echo $html . '</tbody></table></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
