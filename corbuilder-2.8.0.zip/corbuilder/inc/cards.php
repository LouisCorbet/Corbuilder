<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * CARTES : champs et rendu des sections « Cartes » et « Liste » (mêmes champs ; seule la position
 * de l'image change : en haut pour les cartes, à gauche ou à droite pour la liste).
 * Seuls les éléments remplis s'affichent. Dans l'interface, les champs d'une carte sont rangés
 * en 4 menus dépliants (clé 'group') : En-tête, Contenu, Pied de carte, Style.
 * Chaque groupe a son alignement (gauche, centré, droite) ; pour « Style », il ne porte que sur le bouton.
 * ========================================================================= */

/* Choix de couleur d'une icône (hors bouton) : la palette du site, le blanc, le noir et la couleur du texte.
   $default : choix « automatique » (couleur d'origine du composant) */
function corbuilder_color_choice_fields( $key, $label, $default = 'primary' ) {
	$choices = array_slice( corbuilder_palette_labels(), 0, 5, true ) + array( 'text' => __( 'Couleur du texte', 'corbuilder' ) ) + array_slice( corbuilder_palette_labels(), 5, null, true );
	if ( isset( $choices[ $default ] ) ) {
		$choices[ $default ] .= ' ' . __( '(par défaut)', 'corbuilder' );
	}
	return array(
		$key => array( 'type' => 'select', 'label' => $label, 'choices' => $choices, 'default' => $default ),
	);
}

/* Couleur CSS du choix ; '' pour le choix par défaut (le composant garde alors sa couleur d'origine, y compris sur fond sombre).
   $legacy_custom : ancienne couleur libre, encore lue si le choix est « custom » (réglage d'avant la palette). */
function corbuilder_color_choice_css( $choice, $default = 'primary', $legacy_custom = '' ) {
	if ( 'custom' === $choice ) {
		$choice = corbuilder_nearest_palette_key( $legacy_custom );
	}
	if ( $choice === $default ) {
		return '';
	}
	switch ( $choice ) {
		case 'primary':
		case 'secondary':
		case 'accent':
		case 'light':
		case 'dark':
			return 'var(--c-' . $choice . ')';
		case 'tint':
			return 'var(--c-light)';
		case 'text':
			return 'var(--c-text)';
		case 'white':
			return '#ffffff';
		case 'black':
			return '#000000';
	}
	return '';
}

/* Densité des cartes : « Normale » ou « Aérée » (marges intérieures et espaces entre cartes plus grands) */
function corbuilder_card_density_field() {
	return array(
		'type'    => 'select',
		'label'   => __( 'Densité des cartes', 'corbuilder' ),
		'choices' => array(
			'normal' => __( 'Normale', 'corbuilder' ),
			'airy'   => __( 'Aérée', 'corbuilder' ),
		),
		'default' => 'normal',
	);
}

function corbuilder_card_align_choices() {
	return array(
		'left'   => __( 'À gauche', 'corbuilder' ),
		'center' => __( 'Centré', 'corbuilder' ),
		'right'  => __( 'À droite', 'corbuilder' ),
	);
}

/* $layout : 'cards' (image en haut) ou 'list' (image à gauche ou à droite) */
function corbuilder_card_fields( $layout = 'cards' ) {
	$g_head    = __( 'En-tête', 'corbuilder' );
	$g_content = __( 'Contenu', 'corbuilder' );
	$g_footer  = __( 'Pied de carte', 'corbuilder' );
	$g_style   = __( 'Style', 'corbuilder' );
	$align     = function ( $label ) {
		return array( 'type' => 'select', 'label' => $label, 'choices' => corbuilder_card_align_choices(), 'default' => 'left' );
	};

	// L'ordre des champs fixe l'ordre des groupes ; « group_open » : menu ouvert par défaut.
	$fields = array(
		// En-tête
		'title'         => array( 'type' => 'text', 'label' => __( 'Titre (H3)', 'corbuilder' ), 'group' => $g_head, 'group_open' => true ),
		'subtitle'      => array( 'type' => 'text', 'label' => __( 'Sous-titre', 'corbuilder' ), 'group' => $g_head ),
		'header_align'  => $align( __( 'Alignement de l’en-tête', 'corbuilder' ) ) + array( 'group' => $g_head ),

		// Contenu
		'price'         => array( 'type' => 'text', 'label' => __( 'Prix (ex. 49 €)', 'corbuilder' ), 'group' => $g_content, 'group_open' => true ),
		'price_note'    => array( 'type' => 'text', 'label' => __( 'Précision du prix (ex. / mois)', 'corbuilder' ), 'group' => $g_content ),
		'text'          => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ), 'group' => $g_content ),
		'points'        => array(
			'type'       => 'repeater',
			'label'      => __( 'Liste de points', 'corbuilder' ),
			'item_label' => __( 'Point', 'corbuilder' ),
			'add_label'  => __( 'Ajouter un point', 'corbuilder' ),
			'max'        => 20,
			'group'      => $g_content,
			'fields'     => array(
				'text' => array( 'type' => 'text', 'label' => __( 'Texte du point', 'corbuilder' ) ),
				'icon' => array( 'type' => 'icon', 'label' => __( 'Icône (une coche par défaut)', 'corbuilder' ) ),
			) + corbuilder_color_choice_fields( 'color', __( 'Couleur de l’icône', 'corbuilder' ) ),
		),
		'content_align' => $align( __( 'Alignement du contenu', 'corbuilder' ) ) + array( 'group' => $g_content ),

		// Pied de carte
		'footer_text'   => array( 'type' => 'text', 'label' => __( 'Texte de pied de carte', 'corbuilder' ), 'group' => $g_footer ),
		'footer_align'  => $align( __( 'Alignement du pied de carte', 'corbuilder' ) ) + array( 'group' => $g_footer ),

		// Style
		'icon'          => array( 'type' => 'icon', 'label' => __( 'Icône', 'corbuilder' ), 'group' => $g_style ),
		'badge'         => array( 'type' => 'text', 'label' => __( 'Étiquette (ex. Nouveau)', 'corbuilder' ), 'group' => $g_style ),
		'button'        => array( 'type' => 'button', 'label' => __( 'Bouton (facultatif)', 'corbuilder' ), 'group' => $g_style ),
		'button_align'  => $align( __( 'Alignement du bouton', 'corbuilder' ) ) + array( 'group' => $g_style ),
		'image'         => array( 'type' => 'image', 'label' => __( 'Image', 'corbuilder' ), 'group' => $g_style ),
		'image_mode'    => array(
			'type'    => 'select',
			'label'   => __( 'Position de l’image', 'corbuilder' ),
			'choices' => ( 'list' === $layout )
				? array(
					'left'       => __( 'À gauche de la carte', 'corbuilder' ),
					'right'      => __( 'À droite de la carte', 'corbuilder' ),
					'background' => __( 'En fond de carte', 'corbuilder' ),
				)
				: array(
					'top'        => __( 'En haut de la carte', 'corbuilder' ),
					'background' => __( 'En fond de carte', 'corbuilder' ),
				),
			'default' => ( 'list' === $layout ) ? 'left' : 'top',
			'group'   => $g_style,
		),
		'bg_color'      => array(
			'type'    => 'select',
			'label'   => __( 'Couleur par-dessus l’image', 'corbuilder' ),
			'choices' => corbuilder_palette_choices( true ),
			'default' => 'black',
			'show_if' => array( 'image_mode', 'background' ),
			'group'   => $g_style,
		),
		'bg_opacity'    => array(
			'type'    => 'range',
			'label'   => __( 'Opacité de la couleur (%)', 'corbuilder' ),
			'min'     => 0,
			'max'     => 100,
			'step'    => 5,
			'default' => 50,
			'show_if' => array( 'image_mode', 'background' ),
			'group'   => $g_style,
		),
		'text_tone'     => array(
			'type'    => 'select',
			'label'   => __( 'Couleur du texte', 'corbuilder' ),
			'choices' => array(
				'auto'  => __( 'Automatique', 'corbuilder' ),
				'light' => __( 'Claire', 'corbuilder' ),
				'dark'  => __( 'Foncée', 'corbuilder' ),
			),
			'default' => 'auto',
			'show_if' => array( 'image_mode', 'background' ),
			'group'   => $g_style,
		),
		// Mise en avant : deux cases indépendantes (la clé « featured » est celle de la bordure, déjà utilisée par les anciennes cartes)
		'featured'      => array( 'type' => 'checkbox', 'label' => __( 'Bordure de mise en avant', 'corbuilder' ), 'group' => $g_style ),
		'featured_size' => array( 'type' => 'checkbox', 'label' => __( 'Taille augmentée', 'corbuilder' ), 'group' => $g_style ),
	);
	$border = corbuilder_color_choice_fields( 'border_color', __( 'Couleur de la bordure', 'corbuilder' ) );
	$border['border_color']['show_if'] = array( 'featured', true );
	foreach ( array(
		'border_top'    => __( 'Bordure : côté haut', 'corbuilder' ),
		'border_right'  => __( 'Bordure : côté droit', 'corbuilder' ),
		'border_bottom' => __( 'Bordure : côté bas', 'corbuilder' ),
		'border_left'   => __( 'Bordure : côté gauche', 'corbuilder' ),
	) as $k => $label ) {
		$border[ $k ] = array( 'type' => 'checkbox', 'label' => $label, 'default' => true, 'show_if' => array( 'featured', true ) );
	}
	foreach ( $border as $k => $d ) {
		$border[ $k ] = $d + array( 'group' => $g_style );
	}
	$fields = corbuilder_fields_insert_after( $fields, 'featured', $border );

	$icon_color = array();
	foreach ( corbuilder_color_choice_fields( 'icon_color', __( 'Couleur de l’icône', 'corbuilder' ) ) as $k => $d ) {
		$icon_color[ $k ] = $d + array( 'group' => $g_style );
	}
	return corbuilder_fields_insert_after( $fields, 'icon', $icon_color );
}

/* Cartes de la version 1.0.6 : « featured » + « featured_style » (bordure ou taille) -> deux cases indépendantes */
function corbuilder_card_migrate( $item ) {
	if ( ! is_array( $item ) ) {
		return $item;
	}
	if ( array_key_exists( 'featured_style', $item ) ) {
		if ( ! empty( $item['featured'] ) && 'size' === $item['featured_style'] ) {
			$item['featured']      = false;
			$item['featured_size'] = true;
		}
		unset( $item['featured_style'] );
	}
	// Anciennes listes de points : un texte avec un point par ligne -> liste de points (icône et couleur par défaut)
	if ( array_key_exists( 'features', $item ) ) {
		if ( empty( $item['points'] ) && is_string( $item['features'] ) ) {
			$item['points'] = array();
			foreach ( array_filter( array_map( 'trim', preg_split( '/\R/', $item['features'] ) ) ) as $line ) {
				$item['points'][] = array( 'text' => wp_strip_all_tags( $line ), 'icon' => '', 'color' => 'primary' );
			}
		}
		unset( $item['features'] );
	}
	return $item;
}

/* Anciennes couleurs d'une section ou d'un élément (récursif) : « Secondaire clair » (tint) devient « Fond clair » (light),
   une couleur personnalisée devient la couleur de la palette la plus proche (la palette est réglée dans Style → Couleurs). */
function corbuilder_migrate_colors( $data ) {
	if ( ! is_array( $data ) ) {
		return $data;
	}
	foreach ( $data as $key => $value ) {
		if ( is_array( $value ) ) {
			$data[ $key ] = corbuilder_migrate_colors( $value );
			continue;
		}
		if ( ! is_string( $key ) || ! is_string( $value ) || false === strpos( $key, 'color' ) ) {
			continue;
		}
		if ( 'tint' === $value ) {
			$data[ $key ] = 'light';
		} elseif ( 'custom' === $value ) {
			$hex = '';
			foreach ( array( $key . '_custom', str_replace( 'color', 'custom', $key ) ) as $custom_key ) { // icon_color_custom, bg_custom…
				if ( array_key_exists( $custom_key, $data ) ) {
					$hex = $data[ $custom_key ];
					unset( $data[ $custom_key ] );
					break;
				}
			}
			$data[ $key ] = corbuilder_nearest_palette_key( $hex );
		}
	}
	return $data;
}

/* Même conversion sur le JSON des sections (pour que le Customizer affiche les bonnes cases) */
function corbuilder_migrate_sections_json( $json ) {
	if ( ! is_string( $json ) || ( false === strpos( $json, 'featured_style' ) && false === strpos( $json, '"features"' ) && false === strpos( $json, '"gradient"' ) && false === strpos( $json, '"custom"' ) && false === strpos( $json, '"tint"' ) ) ) {
		return $json;
	}
	$sections = json_decode( $json, true );
	if ( ! is_array( $sections ) ) {
		return $json;
	}
	foreach ( $sections as $i => $section ) {
		if ( is_array( $section ) && isset( $section['data'] ) && is_array( $section['data'] ) ) {
			$sections[ $i ]['data'] = corbuilder_migrate_colors( $section['data'] );
			$section['data']        = $sections[ $i ]['data'];
		}
		// Dégradé enregistré avant l'opacité par couleur : la 2e opacité reprend la 1re (le rendu ne change pas)
		if ( is_array( $section ) && isset( $section['data'] ) && is_array( $section['data'] ) && isset( $section['data']['bg_mode'], $section['data']['bg_opacity'] )
			&& 'gradient' === $section['data']['bg_mode'] && ! array_key_exists( 'bg_opacity2', $section['data'] ) ) {
			$sections[ $i ]['data']['bg_opacity2'] = $section['data']['bg_opacity'];
		}
		if ( is_array( $section ) && isset( $section['type'], $section['data']['items'] ) && in_array( $section['type'], array( 'cards', 'list' ), true ) && is_array( $section['data']['items'] ) ) {
			$sections[ $i ]['data']['items'] = array_map( 'corbuilder_card_migrate', $sections[ $i ]['data']['items'] );
		}
	}
	return wp_json_encode( $sections );
}

/* Valeurs par défaut d'une carte (pour les cartes enregistrées avant l'ajout d'un champ) */
function corbuilder_card_defaults( $layout = 'cards' ) {
	static $defaults = array();
	if ( ! isset( $defaults[ $layout ] ) ) {
		$defaults[ $layout ] = corbuilder_field_defaults( corbuilder_normalize_fields( corbuilder_card_fields( $layout ) ) );
	}
	return $defaults[ $layout ];
}

/* HTML d'une carte. $item : valeurs saisies ; $layout : 'cards' ou 'list'. */
function corbuilder_render_card( $item, $i = 0, $layout = 'cards' ) {
	$layout = ( 'list' === $layout ) ? 'list' : 'cards';
	$item   = array_merge( corbuilder_card_defaults( $layout ), corbuilder_card_migrate( is_array( $item ) ? $item : array() ) );
	$g    = function ( $key ) use ( $item ) {
		return $item[ $key ];
	};
	$align = function ( $key ) use ( $g ) {
		return ' card__align--' . ( in_array( $g( $key ), array( 'left', 'center', 'right' ), true ) ? $g( $key ) : 'left' );
	};

	$img_id = absint( $g( 'image' ) );
	$as_bg  = $img_id && 'background' === $g( 'image_mode' );
	$icon   = $g( 'icon' ) ? corbuilder_icon_svg( (string) $g( 'icon' ), 'card__icon-svg' ) : '';

	$class = 'card';
	if ( $g( 'featured' ) ) { // mise en avant : bordure et/ou taille augmentée
		$class .= ' card--featured-border';
	}
	if ( $g( 'featured_size' ) ) {
		$class .= ' card--featured-size';
	}
	if ( 'list' === $layout && ! $as_bg && 'right' === $g( 'image_mode' ) ) {
		$class .= ' card--img-right';
	}
	$vars  = '--i:' . (int) $i . ';';
	if ( $g( 'featured' ) ) { // bordure : côtés et couleur au choix (3 px sur les côtés cochés)
		$widths = array();
		foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
			$widths[] = $g( 'border_' . $side ) ? '3px' : '0';
		}
		$vars .= '--card-bw:' . implode( ' ', $widths ) . ';';
		$bc    = corbuilder_color_choice_css( $g( 'border_color' ), 'primary', isset( $item['border_color_custom'] ) ? $item['border_color_custom'] : '' );
		if ( '' !== $bc ) {
			$vars .= '--card-bc:' . $bc . ';';
		}
	}
	if ( $as_bg ) { // image en fond, couleur par-dessus : même logique que le fond des sections
		$look    = array( 'bg_color' => $g( 'bg_color' ), 'bg_custom' => isset( $item['bg_custom'] ) ? $item['bg_custom'] : '', 'text_tone' => $g( 'text_tone' ) );
		$rgb     = corbuilder_bg_rgb( $look );
		$opacity = max( 0, min( 100, (int) $g( 'bg_opacity' ) ) ) / 100;
		if ( $rgb ) {
			$vars .= sprintf( '--card-overlay:rgba(%d,%d,%d,%s);', $rgb[0], $rgb[1], $rgb[2], number_format( $opacity, 2, '.', '' ) );
		}
		$class .= ' card--bg' . ( 'light' === corbuilder_section_tone( $look, $rgb, $opacity, true ) ? ' card--light' : '' );
	}
	$html = '<article class="' . esc_attr( $class . ' anim' ) . '" style="' . esc_attr( $vars ) . '">';

	if ( $as_bg ) {
		$html .= corbuilder_image( $img_id, 'large', array( 'class' => 'card__bgimg', 'alt' => '' ) );
	}
	if ( '' !== trim( (string) $g( 'badge' ) ) ) {
		$html .= '<span class="card__badge">' . esc_html( $g( 'badge' ) ) . '</span>';
	}
	if ( $img_id && ! $as_bg ) {
		$html .= '<div class="card__img">' . corbuilder_image( $img_id, 'medium_large' ) . '</div>';
	}
	$html .= '<div class="card__body">';

	// En-tête : icône, titre, sous-titre
	$header = '';
	if ( $icon ) {
		$icon_css = corbuilder_color_choice_css( $g( 'icon_color' ), 'primary', isset( $item['icon_color_custom'] ) ? $item['icon_color_custom'] : '' );
		$header  .= '<span class="card__icon"' . ( '' !== $icon_css ? ' style="--icon-color:' . esc_attr( $icon_css ) . '"' : '' ) . ' aria-hidden="true">' . $icon . '</span>';
	}
	if ( '' !== (string) $g( 'title' ) ) {
		$header .= '<h3 class="card__title">' . esc_html( $g( 'title' ) ) . '</h3>';
	}
	if ( '' !== (string) $g( 'subtitle' ) ) {
		$header .= '<p class="card__subtitle">' . esc_html( $g( 'subtitle' ) ) . '</p>';
	}
	if ( '' !== $header ) {
		$html .= '<div class="card__header' . $align( 'header_align' ) . '">' . $header . '</div>';
	}

	// Contenu : prix, paragraphe, liste de points
	$content = '';
	if ( '' !== (string) $g( 'price' ) ) {
		$content .= '<p class="card__price"><span class="card__price-amount">' . esc_html( $g( 'price' ) ) . '</span>'
			. ( '' !== (string) $g( 'price_note' ) ? '<span class="card__price-note">' . esc_html( $g( 'price_note' ) ) . '</span>' : '' ) . '</p>';
	}
	if ( '' !== trim( (string) $g( 'text' ) ) ) {
		$content .= '<div class="card__text">' . corbuilder_text( $g( 'text' ) ) . '</div>';
	}
	$list = '';
	foreach ( (array) $g( 'points' ) as $pt ) {
		if ( ! is_array( $pt ) || '' === trim( isset( $pt['text'] ) ? (string) $pt['text'] : '' ) ) {
			continue;
		}
		$slug = ! empty( $pt['icon'] ) ? (string) $pt['icon'] : 'check';
		$css  = corbuilder_color_choice_css( isset( $pt['color'] ) ? $pt['color'] : 'primary', 'primary', isset( $pt['color_custom'] ) ? $pt['color_custom'] : '' );
		$list .= '<li><span class="card__point-icon"' . ( '' !== $css ? ' style="--icon-color:' . esc_attr( $css ) . '"' : '' ) . ' aria-hidden="true">' . corbuilder_icon_svg( $slug, 'card__point-svg' ) . '</span><span class="card__point-text">' . esc_html( $pt['text'] ) . '</span></li>';
	}
	if ( '' !== $list ) {
		$content .= '<ul class="card__features">' . $list . '</ul>';
	}
	if ( '' !== $content ) {
		$html .= '<div class="card__content' . $align( 'content_align' ) . '">' . $content . '</div>';
	}

	// Bouton, puis pied de carte
	$btn = corbuilder_button( is_array( $g( 'button' ) ) ? $g( 'button' ) : array() );
	if ( '' !== $btn ) {
		$html .= '<div class="card__actions' . $align( 'button_align' ) . '">' . $btn . '</div>';
	}
	if ( '' !== (string) $g( 'footer_text' ) ) {
		$html .= '<p class="card__footer' . $align( 'footer_align' ) . '">' . esc_html( $g( 'footer_text' ) ) . '</p>';
	}
	return $html . '</div></article>';
}

/* Choix du nombre de colonnes d'une grille de cartes (clés non numériques : l'ordre est gardé côté JavaScript) */
function corbuilder_card_columns_field( $default = 'auto', $with_auto = true ) {
	$choices = array();
	if ( $with_auto ) {
		$choices['auto'] = __( 'Automatique', 'corbuilder' );
	}
	$choices += array(
		'cols-2' => __( '2 colonnes', 'corbuilder' ),
		'cols-3' => __( '3 colonnes', 'corbuilder' ),
		'cols-4' => __( '4 colonnes', 'corbuilder' ),
		'cols-5' => __( '5 colonnes', 'corbuilder' ),
	);
	return array( 'type' => 'select', 'label' => __( 'Colonnes', 'corbuilder' ), 'choices' => $choices, 'default' => $default );
}

/* Classe de la grille selon le choix de colonnes */
function corbuilder_card_grid_class( $columns ) {
	return 'cards__grid' . ( ( 'auto' !== $columns && '' !== $columns ) ? ' cards__grid--' . sanitize_html_class( $columns ) : '' );
}

/* Titre et sous-titre d'une section : deux éléments (H2 puis H3 par défaut) ou, avec la case « Regrouper », un seul H2 en deux parties.
   Options : title_tag, sub_tag, title_class, sub_class, title_sub_class (ajoutée au titre quand un sous-titre suit). */
function corbuilder_heading_html( $d, $o = array() ) {
	$o = array_merge( array(
		'title_tag'       => 'h2',
		'sub_tag'         => 'h3',
		'title_class'     => 'section__title',
		'sub_class'       => 'section__subtitle',
		'title_sub_class' => '',
	), $o );
	$has_t = '' !== (string) $d['title'];
	$has_s = '' !== (string) $d['subtitle'];
	$sub_c = ( $has_s && '' !== $o['title_sub_class'] ) ? ' ' . $o['title_sub_class'] : '';
	$html  = '';
	if ( $has_t && $has_s && ! empty( $d['merge_heading'] ) ) {
		return '<' . $o['title_tag'] . ' class="' . esc_attr( $o['title_class'] . $sub_c ) . ' section__title--merged">'
			. '<span class="section__title-text">' . corbuilder_multiline_html( $d['title'] ) . '</span> '
			. '<span class="' . esc_attr( $o['sub_class'] ) . '">' . corbuilder_multiline_html( $d['subtitle'] ) . '</span>'
			. '</' . $o['title_tag'] . '>';
	}
	if ( $has_t ) {
		$html .= '<' . $o['title_tag'] . ' class="' . esc_attr( $o['title_class'] . $sub_c ) . '">' . corbuilder_multiline_html( $d['title'] ) . '</' . $o['title_tag'] . '>';
	}
	if ( $has_s ) {
		$html .= '<' . $o['sub_tag'] . ' class="' . esc_attr( $o['sub_class'] ) . '">' . corbuilder_multiline_html( $d['subtitle'] ) . '</' . $o['sub_tag'] . '>';
	}
	return $html;
}

/* En-tête de section commun (H2, H3, paragraphe) */
function corbuilder_section_head_html( $d ) {
	if ( '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && ! corbuilder_chips_filled( $d ) ) {
		return '';
	}
	$align = ( isset( $d['head_align'] ) && in_array( $d['head_align'], array( 'left', 'center', 'right' ), true ) ) ? $d['head_align'] : 'center';
	$html  = '<div class="section__head section__head--' . $align . ' anim">';
	$html .= corbuilder_heading_html( $d );
	if ( '' !== trim( (string) $d['text'] ) ) {
		$html .= '<div class="section__text">' . corbuilder_text( $d['text'] ) . '</div>';
	}
	$html .= corbuilder_chips_html( $d, $align );
	return $html . '</div>';
}
