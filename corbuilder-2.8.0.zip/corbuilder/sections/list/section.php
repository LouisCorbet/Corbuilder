<?php
/**
 * Section « Liste » : mêmes réglages que « Cartes » (voir inc/cards.php), mais les cartes
 * s'affichent en liste : une par ligne, image à gauche ou à droite (choix dans « Style »).
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Liste', 'corbuilder' ),
	'description' => __( 'Les mêmes cartes que la section « Cartes », affichées en liste : une par ligne, avec l’image à gauche ou à droite (ou en fond de carte).', 'corbuilder' ),
	'order'       => 31,
	'bg'          => array( 'color' => 'tint' ),
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'density'  => corbuilder_card_density_field(),
		'items'    => array(
			'type'       => 'repeater',
			'label'      => __( 'Liste des cartes', 'corbuilder' ),
			'item_label' => __( 'Carte', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une carte', 'corbuilder' ),
			'max'        => 24,
			'fields'     => corbuilder_card_fields( 'list' ),
		),
	),
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! empty( $d['items'] ) && is_array( $d['items'] ) ) {
			echo '<div class="cards__list' . ( 'airy' === $d['density'] ? ' cards__list--airy' : '' ) . '">';
			foreach ( array_values( $d['items'] ) as $i => $item ) {
				echo corbuilder_render_card( $item, $i, 'list' ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div>';
		}
	},
);
