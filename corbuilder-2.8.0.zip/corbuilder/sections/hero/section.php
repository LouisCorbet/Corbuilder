<?php
/**
 * Section « Image Head » : bandeau avec titre H1, paragraphe et un ou deux boutons, en quatre variantes :
 * classique, texte animé (une partie du titre s'écrit et change toute seule), texte + image, texte encadré.
 * L'image de fond se règle dans « Image de fond » (commun à toutes les sections).
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Image Head', 'corbuilder' ),
	'description' => __( 'Bandeau d’en-tête. Choisis l’image dans « Image de fond » (plus bas) ; la couleur se superpose par-dessus.', 'corbuilder' ),
	'order'       => 10,
	'h1'          => true,
	'head_align'  => 'left', // alignement du titre, du sous-titre, du texte et des boutons
	'animate'     => false, // pas d'animation : elle retarderait l'affichage du haut de page
	'bg'          => array( 'color' => 'black', 'opacity' => 45 ),
	'fields'      => array(
		'variant'  => array(
			'type'    => 'choice',
			'label'   => __( 'Variante du bandeau', 'corbuilder' ),
			'choices' => function () {
				return array(
					'classic' => array( 'label' => __( 'Classique', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/variant-classic.svg' ) ),
					'typed'   => array( 'label' => __( 'Texte animé', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/variant-typed.svg' ) ),
					'typed_side' => array( 'label' => __( 'Texte animé séparé', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/variant-typed-side.svg' ) ),
					'split'   => array( 'label' => __( 'Texte + image', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/variant-split.svg' ) ),
					'card'    => array( 'label' => __( 'Texte encadré', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/variant-card.svg' ) ),
				);
			},
		),
		'title_style' => array(
			'type'    => 'choice',
			'label'   => __( 'Style du titre et du sous-titre (disposition et tailles)', 'corbuilder' ),
			'choices' => function () {
				return array(
					'stacked' => array( 'label' => __( 'Classique', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/title-stacked.svg' ) ),
					'kicker'  => array( 'label' => __( 'Sous-titre au-dessus', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/title-kicker.svg' ) ),
					'lead'    => array( 'label' => __( 'Sous-titre en grand', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/title-lead.svg' ) ),
					'split'   => array( 'label' => __( 'Côte à côte', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/title-split.svg' ) ),
					'giant'   => array( 'label' => __( 'Titre géant', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/title-giant.svg' ) ),
				);
			},
		),
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H1)', 'corbuilder' ) ),
		'typed_words' => array(
			'type'    => 'textarea',
			'label'   => __( 'Mots animés (à la suite du titre, ou à droite pour « Texte animé séparé » ; un par ligne ; plusieurs lignes : ils se remplacent à tour de rôle)', 'corbuilder' ),
			'show_if' => array( 'variant', array( 'typed', 'typed_side' ) ),
		),
		'typed_color' => array(
			'type'    => 'select',
			'label'   => __( 'Couleur des mots animés', 'corbuilder' ),
			'choices' => array( 'inherit' => __( 'Comme le titre', 'corbuilder' ) ) + corbuilder_palette_labels(),
			'default' => 'accent',
			'show_if' => array( 'variant', array( 'typed', 'typed_side' ) ),
		),
		'typed_speed' => array(
			'type'    => 'select',
			'label'   => __( 'Vitesse de l’animation', 'corbuilder' ),
			'choices' => array(
				'slow'   => __( 'Lente', 'corbuilder' ),
				'normal' => __( 'Normale', 'corbuilder' ),
				'fast'   => __( 'Rapide', 'corbuilder' ),
			),
			'default' => 'normal',
			'show_if' => array( 'variant', array( 'typed', 'typed_side' ) ),
		),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre', 'corbuilder' ) ),
		'title_color' => array(
			'type'    => 'select',
			'label'   => __( 'Couleur du titre', 'corbuilder' ),
			'choices' => array( 'auto' => __( 'Automatique (selon le fond)', 'corbuilder' ) ) + corbuilder_palette_labels(),
			'default' => 'auto',
		),
		'subtitle_color' => array(
			'type'    => 'select',
			'label'   => __( 'Couleur du sous-titre', 'corbuilder' ),
			'choices' => array( 'auto' => __( 'Automatique (selon le fond)', 'corbuilder' ) ) + corbuilder_palette_labels(),
			'default' => 'auto',
		),
		'merge_heading' => array(
			'type'  => 'checkbox',
			'label' => __( 'Regrouper le titre et le sous-titre en un seul H1 (aucun changement visuel : utile quand le sous-titre complète le titre, les deux se lisent à la suite)', 'corbuilder' ),
		),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'button'  => array( 'type' => 'button', 'label' => __( 'Bouton (facultatif)', 'corbuilder' ) ),
		'button2' => array( 'type' => 'button', 'label' => __( 'Second bouton (facultatif)', 'corbuilder' ) ),
		'side_image' => array(
			'type'    => 'image',
			'label'   => __( 'Image à côté du texte', 'corbuilder' ),
			'show_if' => array( 'variant', 'split' ),
		),
		'side_pos' => array(
			'type'    => 'select',
			'label'   => __( 'Position de l’image', 'corbuilder' ),
			'choices' => array(
				'right' => __( 'À droite', 'corbuilder' ),
				'left'  => __( 'À gauche', 'corbuilder' ),
			),
			'default' => 'right',
			'show_if' => array( 'variant', 'split' ),
		),
		'height' => array(
			'type'    => 'select',
			'label'   => __( 'Hauteur du bandeau', 'corbuilder' ),
			'choices' => array(
				'medium'  => __( 'Moyenne', 'corbuilder' ),
				'compact' => __( 'Compacte', 'corbuilder' ),
				'tall'    => __( 'Grande', 'corbuilder' ),
				'full'    => __( 'Plein écran', 'corbuilder' ),
			),
		),
	),
	'classes'     => function ( $d ) {
		return array(
			'hero--h-' . $d['height'],
			'hero--align-' . ( in_array( $d['head_align'], array( 'left', 'center', 'right' ), true ) ? $d['head_align'] : 'left' ),
			'hero--v-' . ( in_array( $d['variant'], array( 'typed', 'typed_side', 'split', 'card' ), true ) ? $d['variant'] : 'classic' ),
		);
	},
	'render'      => function ( $d, $ctx ) {
		$tag     = $ctx->h1 ? 'h2' : 'h1'; // un seul H1 par page
		$title   = (string) $d['title'];
		$styles  = array( 'stacked', 'kicker', 'lead', 'split', 'giant' );
		$tstyle  = in_array( $d['title_style'], $styles, true ) ? $d['title_style'] : 'stacked';
		$variant = in_array( $d['variant'], array( 'typed', 'typed_side', 'split', 'card' ), true ) ? $d['variant'] : 'classic';
		if ( '' === $title && ! $ctx->h1 ) {
			$title = get_the_title( $ctx->pid );
		}
		$ctx->h1 = true;

		// Texte animé : les mots (un par ligne) s'écrivent à la suite du titre ; le premier reste dans la page pour les lecteurs d'écran et sans JavaScript
		$typed = '';
		if ( in_array( $variant, array( 'typed', 'typed_side' ), true ) ) {
			$words = array_slice( array_values( array_filter( array_map( function ( $w ) {
				return mb_substr( trim( $w ), 0, 80 );
			}, preg_split( '/\R/', wp_strip_all_tags( (string) $d['typed_words'] ) ) ), 'strlen' ) ), 0, 8 );
			if ( $words ) {
				$longest = $words[0];
				foreach ( $words as $w ) {
					if ( mb_strlen( $w ) > mb_strlen( $longest ) ) {
						$longest = $w;
					}
				}
				$color = corbuilder_color_choice_css( (string) $d['typed_color'], '' );
				$speed = in_array( $d['typed_speed'], array( 'slow', 'normal', 'fast' ), true ) ? $d['typed_speed'] : 'normal';
				$typed = '<span class="screen-reader-text">' . esc_html( $words[0] ) . '</span>'
					. '<span class="hero__typed" aria-hidden="true" data-words="' . esc_attr( wp_json_encode( $words ) ) . '" data-speed="' . esc_attr( $speed ) . '"' . ( '' !== $color ? ' style="color:' . esc_attr( $color ) . '"' : '' ) . '>'
					. '<span class="hero__typed-ghost">' . esc_html( $longest ) . '</span><span class="hero__typed-text">' . esc_html( $words[0] ) . '</span></span>';
				wp_enqueue_script( 'corbuilder-hero-typed', get_template_directory_uri() . '/assets/hero-typed.js', array(), CORBUILDER_VERSION . '.' . (int) @filemtime( get_template_directory() . '/assets/hero-typed.js' ), true );
			}
		}

		$copy = '';
		// Titre et sous-titre : un bloc « hero__head » dont l'ordre dans la page est celui de l'affichage ; couleurs facultatives
		$has_title = ( '' !== $title || ( 'typed' === $variant && '' !== $typed ) );
		$has_sub   = ( '' !== $d['subtitle'] );
		$t_css     = corbuilder_color_choice_css( (string) $d['title_color'], 'auto' );
		$s_css     = corbuilder_color_choice_css( (string) $d['subtitle_color'], 'auto' );
		$t_attr    = '' !== $t_css ? ' style="color:' . esc_attr( $t_css ) . '"' : '';
		$s_attr    = '' !== $s_css ? ' style="color:' . esc_attr( $s_css ) . '"' : '';
		$inline    = ( 'typed' === $variant ) ? $typed : '';
		$title_in  = corbuilder_multiline_html( $title ) . ( '' !== $inline && '' !== $title ? ' ' : '' ) . $inline; // phpcs:ignore WordPress.Security.EscapeOutput -- $typed est déjà échappé
		$sub_in    = corbuilder_multiline_html( $d['subtitle'] );
		$head_cls  = 'hero__head hero__head--' . $tstyle;
		if ( $has_title && $has_sub && ! empty( $d['merge_heading'] ) ) {
			// Un seul titre (H1) en deux parties : même rendu, mais le sous-titre fait partie du titre de la page
			$t_el   = '<span class="hero__title hero__title--sub"' . $t_attr . '>' . $title_in . '</span>';
			$s_el   = '<span class="section__subtitle hero__subtitle"' . $s_attr . '>' . $sub_in . '</span>';
			$copy  .= '<' . $tag . ' class="' . $head_cls . ' hero__head--merged">' . ( 'kicker' === $tstyle ? $s_el . ' ' . $t_el : $t_el . ' ' . $s_el ) . '</' . $tag . '>';
		} elseif ( $has_title || $has_sub ) {
			$t_el   = $has_title ? '<' . $tag . ' class="hero__title' . ( $has_sub ? ' hero__title--sub' : '' ) . '"' . $t_attr . '>' . $title_in . '</' . $tag . '>' : '';
			$s_el   = $has_sub ? '<p class="section__subtitle hero__subtitle"' . $s_attr . '>' . $sub_in . '</p>' : '';
			$copy  .= '<div class="' . $head_cls . '">' . ( 'kicker' === $tstyle ? $s_el . $t_el : $t_el . $s_el ) . '</div>';
		}
		if ( '' !== trim( (string) $d['text'] ) ) {
			$copy .= '<div class="hero__text">' . corbuilder_text( $d['text'] ) . '</div>';
		}
		$copy .= corbuilder_chips_html( $d, $d['head_align'] );
		$btn = corbuilder_button( $d['button'] ) . corbuilder_button( $d['button2'], 'btn--secondary' );
		if ( '' !== $btn ) {
			$copy .= '<div class="hero__actions">' . $btn . '</div>';
		}

		if ( 'typed_side' === $variant && '' !== $typed ) { // texte à gauche, mots animés à droite
			echo '<div class="hero__split hero__split--typed"><div class="hero__copy">' . $copy . '</div><div class="hero__typed-side hero__title">' . $typed . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} elseif ( 'split' === $variant ) { // texte d'un côté, image de l'autre
			$img = corbuilder_image( $d['side_image'], 'large', array( 'class' => 'hero__side-img' ) );
			echo '<div class="hero__split' . ( '' === $img ? ' hero__split--noimg' : '' ) . ( 'left' === $d['side_pos'] ? ' hero__split--left' : '' ) . '"><div class="hero__copy">' . $copy . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( '' !== $img ) {
				echo '<div class="hero__media">' . $img . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div>';
		} elseif ( 'card' === $variant ) { // texte sur un panneau translucide
			echo '<div class="hero__card">' . $copy . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo $copy; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	},
);
