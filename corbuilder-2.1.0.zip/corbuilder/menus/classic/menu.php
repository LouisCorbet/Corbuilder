<?php
/** Style de menu « Classique » : liens simples dans l’en-tête (style actuel). */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Classique', 'corbuilder' ),
	'description' => __( 'Liens simples dans l’en-tête (style actuel).', 'corbuilder' ),
	'order'       => 10,
	'buttons'     => 'none', // liens du 1er niveau affichés en boutons : none, last (le dernier) ou all (tous)
);
