<?php
/** Style de menu « Appel à l’action » : le dernier lien du menu est mis en avant comme un bouton. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Appel à l’action', 'corbuilder' ),
	'description' => __( 'Le dernier lien du menu est mis en avant comme un bouton.', 'corbuilder' ),
	'order'       => 20,
	'buttons'     => 'last', // liens du 1er niveau affichés en boutons : none, last (le dernier) ou all (tous)
);
