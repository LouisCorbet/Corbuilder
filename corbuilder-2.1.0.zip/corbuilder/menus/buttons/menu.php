<?php
/** Style de menu « Boutons » : tous les liens du menu prennent le style des boutons. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Boutons', 'corbuilder' ),
	'description' => __( 'Tous les liens du menu prennent le style des boutons.', 'corbuilder' ),
	'order'       => 30,
	'buttons'     => 'all', // liens du 1er niveau affichés en boutons : none, last (le dernier) ou all (tous)
);
