<?php
defined( 'ABSPATH' ) || exit;

/* Choix par vignettes (styles, en-têtes, pieds de page) : chaque élément a un libellé et une image d'aperçu. */
class Corbuilder_Choice_Control extends WP_Customize_Control {
	public $type  = 'corbuilder_choice';
	public $items = array(); // id => array( label, description, preview )

	protected function render_content() {
		$name = '_customize-choice-' . $this->id;
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-choices">
			<?php foreach ( $this->items as $id => $item ) : ?>
				<label class="corbuilder-choice" title="<?php echo esc_attr( isset( $item['description'] ) ? $item['description'] : '' ); ?>">
					<input type="radio" class="screen-reader-text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $id ); ?>" <?php $this->link(); ?> <?php checked( $this->value(), $id ); ?>>
					<span class="corbuilder-choice__img">
						<?php if ( ! empty( $item['preview'] ) ) : ?>
							<img src="<?php echo esc_url( $item['preview'] ); ?>" alt="" loading="lazy">
						<?php else : ?>
							<span class="corbuilder-choice__ph"><?php echo esc_html( mb_substr( $item['label'], 0, 1 ) ); ?></span>
						<?php endif; ?>
					</span>
					<span class="corbuilder-choice__label"><?php echo esc_html( $item['label'] ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
		<?php
	}
}

/* Liste des sections d'une page. L'interface est construite par assets/customizer.js à partir
   du schéma des sections ; la valeur du réglage est un JSON nettoyé côté serveur. */
class Corbuilder_Sections_Control extends WP_Customize_Control {
	public $type    = 'corbuilder_sections';
	public $context = 'page'; // 'page' ou 'post' (modèle des articles)

	public function to_json() {
		parent::to_json();
		$this->json['context'] = $this->context;
	}

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-sections">
			<div class="corbuilder-sections__list corbuilder-list"></div>
			<button type="button" class="button button-primary corbuilder-sections__toggle"><?php esc_html_e( '+ Ajouter une section', 'corbuilder' ); ?></button>
			<div class="corbuilder-picker"></div>
		</div>
		<?php
	}
}

/* Simple affichage d'information (aucun réglage enregistré) : sert à montrer la version du thème. */
class Corbuilder_Info_Control extends WP_Customize_Control {
	public $type = 'corbuilder_info';

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<?php
	}
}

/* Historique des versions du thème (aucun réglage enregistré) */
class Corbuilder_Changelog_Control extends WP_Customize_Control {
	public $type = 'corbuilder_changelog';

	protected function render_content() {
		require_once get_template_directory() . '/inc/changelog.php';
		$types = corbuilder_changelog_types();
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<ul class="corbuilder-changelog">
			<?php
			$first = true;
			foreach ( corbuilder_changelog() as $version => $lines ) :
				?>
				<li>
					<details<?php echo $first ? ' open' : ''; ?>>
						<summary><strong><?php echo esc_html( $version ); ?></strong></summary>
						<ul>
							<?php foreach ( $lines as $line ) : ?>
								<li><span class="corbuilder-pill corbuilder-pill--<?php echo esc_attr( $line[0] ); ?>"><?php echo esc_html( isset( $types[ $line[0] ] ) ? $types[ $line[0] ] : $line[0] ); ?></span> <?php echo esc_html( $line[1] ); ?></li>
							<?php endforeach; ?>
						</ul>
					</details>
				</li>
				<?php
				$first = false;
			endforeach;
			?>
		</ul>
		<?php
	}
}
