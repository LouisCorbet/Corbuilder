<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * RÔLE « ÉDITEUR DE CONTENU »
 * Un compte qui modifie les textes, les images et les liens des pages dans Personnaliser (avec l'aperçu en direct),
 * sans toucher à la structure ni aux réglages : pas d'ajout, de suppression ni de déplacement de section, pas de fond,
 * de couleur, de style de bouton, d'en-tête, de pied de page, de menu, d'export ni de thème.
 * La restriction est appliquée par le serveur (corbuilder_restrict_sections) : l'éditeur de contenu ne peut pas la contourner.
 * Il peut aussi rédiger des articles dans l'éditeur WordPress, mais ne peut ni créer ni modifier les pages dans cet éditeur.
 * ========================================================================= */

/* Pourquoi « edit_theme_options » est dans la définition du rôle : WordPress vérifie le droit d'accéder à Personnaliser AVANT de charger
   le thème (méthode WP_Customize_Manager::setup_theme), donc avant que les filtres de Corbuilder existent. Le thème retire ensuite
   cette capacité à ce rôle à chaque requête (corbuilder_restrict_editor_caps) : elle ne sert qu'à franchir ce contrôle. */
function corbuilder_content_editor_caps() {
	return array(
		'edit_theme_options'      => true, // neutralisée par le thème, voir ci-dessus
		'read'                    => true,
		'upload_files'            => true, // médiathèque : envoyer ses images
		'edit_posts'              => true, // articles
		'edit_others_posts'       => true,
		'edit_published_posts'    => true,
		'publish_posts'           => true,
		'corbuilder_edit_content' => true, // contenu des pages dans Personnaliser
	);
}

/* Crée le rôle (une fois, ou quand sa définition change) */
function corbuilder_ensure_roles() {
	if ( '2' === get_option( 'corbuilder_roles_version' ) && get_role( 'corbuilder_content_editor' ) ) {
		return;
	}
	remove_role( 'corbuilder_content_editor' );
	add_role( 'corbuilder_content_editor', 'Éditeur de contenu', corbuilder_content_editor_caps() );
	update_option( 'corbuilder_roles_version', '2' );
}
add_action( 'init', 'corbuilder_ensure_roles' );

/* Si on quitte Corbuilder, le rôle perd « edit_theme_options » (plus rien ne la neutraliserait) ; elle revient à la réactivation */
function corbuilder_retire_editor_cap() {
	$role = get_role( 'corbuilder_content_editor' );
	if ( $role ) {
		$role->remove_cap( 'edit_theme_options' );
	}
	update_option( 'corbuilder_roles_version', '0' );
}
add_action( 'switch_theme', 'corbuilder_retire_editor_cap' );

/* L'éditeur de contenu n'a PAS le droit de modifier les options du thème : menus, widgets, réglages, thèmes… (sauf s'il cumule un autre rôle qui l'a) */
function corbuilder_restrict_editor_caps( $allcaps, $caps, $args, $user ) {
	if ( ! $user || ! in_array( 'corbuilder_content_editor', (array) $user->roles, true ) ) {
		return $allcaps;
	}
	foreach ( $user->roles as $role_name ) {
		$role = ( 'corbuilder_content_editor' === $role_name ) ? null : get_role( $role_name );
		if ( $role && $role->has_cap( 'edit_theme_options' ) ) {
			return $allcaps;
		}
	}
	$allcaps['edit_theme_options'] = false;
	return $allcaps;
}
add_filter( 'user_has_cap', 'corbuilder_restrict_editor_caps', 5, 4 );

/* Les administrateurs (qui peuvent modifier les options du thème) ont aussi la capacité « contenu » */
function corbuilder_grant_content_cap( $allcaps ) {
	if ( ! empty( $allcaps['edit_theme_options'] ) ) {
		$allcaps['corbuilder_edit_content'] = true;
	}
	return $allcaps;
}
add_filter( 'user_has_cap', 'corbuilder_grant_content_cap' );

/* Accès à Personnaliser pour l'éditeur de contenu (WordPress le réserve normalement à « edit_theme_options ») */
function corbuilder_map_customize_cap( $caps, $cap, $user_id ) {
	if ( 'customize' === $cap && user_can( $user_id, 'corbuilder_edit_content' ) ) {
		return array( 'corbuilder_edit_content' );
	}
	return $caps;
}
add_filter( 'map_meta_cap', 'corbuilder_map_customize_cap', 10, 3 );

/* Lien « Modifier le site » dans le menu de l'éditeur de contenu (les administrateurs ont déjà Apparence → Personnaliser) */
function corbuilder_editor_menu() {
	if ( current_user_can( 'edit_theme_options' ) || ! current_user_can( 'corbuilder_edit_content' ) ) {
		return;
	}
	add_menu_page( __( 'Modifier le site', 'corbuilder' ), __( 'Modifier le site', 'corbuilder' ), 'corbuilder_edit_content', 'customize.php', '', 'dashicons-edit-page', 3 );
}
add_action( 'admin_menu', 'corbuilder_editor_menu' );

/* ---------- Restriction appliquée à l'enregistrement ---------- */

/* Champs de contenu : le reste (listes déroulantes, cases, curseurs, couleurs, icônes, fond de la section…) est conservé tel quel */
function corbuilder_merge_editable( $fields, $old, $new, $allow_lists ) {
	$old = is_array( $old ) ? $old : array();
	$new = is_array( $new ) ? $new : array();
	$out = $old;
	foreach ( $fields as $key => $def ) {
		if ( ! array_key_exists( $key, $new ) ) {
			continue;
		}
		switch ( $def['type'] ) {
			case 'text':
			case 'textarea':
			case 'url':
			case 'image':
			case 'gallery':
			case 'file':
				$out[ $key ] = $new[ $key ];
				break;
			case 'button': // texte, lien et ouverture dans un nouvel onglet seulement (pas la variante ni l'icône)
				$btn = ( isset( $out[ $key ] ) && is_array( $out[ $key ] ) ) ? $out[ $key ] : corbuilder_button_default();
				$src = is_array( $new[ $key ] ) ? $new[ $key ] : array();
				foreach ( array( 'label', 'url', 'new_tab' ) as $prop ) {
					if ( array_key_exists( $prop, $src ) ) {
						$btn[ $prop ] = $src[ $prop ];
					}
				}
				$out[ $key ] = $btn;
				break;
			case 'repeater':
				$old_items = ( isset( $out[ $key ] ) && is_array( $out[ $key ] ) ) ? array_values( $out[ $key ] ) : array();
				$new_items = is_array( $new[ $key ] ) ? array_values( $new[ $key ] ) : array();
				$sub       = $def['fields'];
				$count     = $allow_lists ? count( $new_items ) : count( $old_items ); // sinon : même nombre d'éléments, dans le même ordre
				$items     = array();
				for ( $i = 0; $i < $count; $i++ ) {
					$base    = isset( $old_items[ $i ] ) ? $old_items[ $i ] : corbuilder_field_defaults( $sub );
					$items[] = corbuilder_merge_editable( $sub, $base, isset( $new_items[ $i ] ) ? $new_items[ $i ] : array(), $allow_lists );
				}
				$out[ $key ] = $items;
				break;
		}
	}
	return $out;
}

/* Sections envoyées par l'éditeur de contenu + sections enregistrées -> les sections enregistrées, avec seulement le contenu mis à jour */
function corbuilder_restrict_sections( $new, $old, $allow_lists ) {
	$registry = corbuilder_get_sections();
	$by_id    = array();
	foreach ( (array) $new as $section ) {
		if ( is_array( $section ) && isset( $section['id'] ) && is_scalar( $section['id'] ) ) {
			$by_id[ (string) $section['id'] ] = $section;
		}
	}
	$out = array();
	foreach ( (array) $old as $section ) { // l'ordre, le nombre et le type des sections sont ceux qui sont enregistrés
		if ( ! is_array( $section ) ) {
			continue;
		}
		$id   = isset( $section['id'] ) ? (string) $section['id'] : '';
		$sent = isset( $by_id[ $id ] ) ? $by_id[ $id ] : null;
		if ( $sent && isset( $sent['type'], $section['type'] ) && $sent['type'] === $section['type'] && isset( $registry[ $section['type'] ] ) ) {
			$section['data'] = corbuilder_merge_editable(
				$registry[ $section['type'] ]['fields'],
				isset( $section['data'] ) ? $section['data'] : array(),
				isset( $sent['data'] ) ? $sent['data'] : array(),
				$allow_lists
			);
		}
		$out[] = $section;
	}
	return $out;
}

/* Valeur envoyée par Personnaliser (JSON) -> JSON restreint au contenu, d'après la valeur enregistrée pour ce réglage */
function corbuilder_restrict_posted_sections( $value, $key ) {
	$mods   = get_option( 'theme_mods_' . get_option( 'stylesheet' ) ); // valeur enregistrée, sans les aperçus en cours
	$stored = ( is_array( $mods ) && isset( $mods[ $key ] ) ) ? corbuilder_migrate_sections_json( $mods[ $key ] ) : '[]';
	$old    = json_decode( is_string( $stored ) ? $stored : '[]', true );
	$new    = json_decode( is_string( $value ) ? $value : '[]', true );
	return wp_json_encode( corbuilder_restrict_sections( is_array( $new ) ? $new : array(), is_array( $old ) ? $old : array(), (bool) corbuilder_mod( 'editor_allow_lists' ) ) );
}
