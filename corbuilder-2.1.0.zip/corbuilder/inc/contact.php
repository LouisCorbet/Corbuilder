<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * COORDONNÉES : adresse, téléphone, e-mail, horaires, réseaux sociaux, carte.
 * Saisies une seule fois (Personnaliser → Coordonnées), utilisées par la section
 * « Coordonnées » et par le pied de page.
 * ========================================================================= */

function corbuilder_contact_value( $key ) {
	return trim( (string) get_theme_mod( $key, '' ) );
}

/* Numéro prêt pour un lien tel: (chiffres et +) */
function corbuilder_tel_href( $phone ) {
	$number = preg_replace( '/[^\d+]/', '', (string) $phone );
	return '' === $number ? '' : 'tel:' . $number;
}

function corbuilder_day_labels() {
	return array(
		__( 'Lundi', 'corbuilder' ),
		__( 'Mardi', 'corbuilder' ),
		__( 'Mercredi', 'corbuilder' ),
		__( 'Jeudi', 'corbuilder' ),
		__( 'Vendredi', 'corbuilder' ),
		__( 'Samedi', 'corbuilder' ),
		__( 'Dimanche', 'corbuilder' ),
	);
}

/* Horaires : 7 textes (lundi à dimanche) ; un jour vide = fermé */
function corbuilder_hours() {
	$out = array();
	for ( $i = 1; $i <= 7; $i++ ) {
		$out[] = corbuilder_contact_value( 'hours_' . $i );
	}
	return $out;
}

function corbuilder_hours_html() {
	$hours = corbuilder_hours();
	if ( ! array_filter( $hours ) ) { // aucun horaire saisi : rien à afficher
		return '';
	}
	$html = '<dl class="hours">';
	foreach ( corbuilder_day_labels() as $i => $day ) {
		$value = $hours[ $i ];
		$html .= '<div class="hours__row' . ( '' === $value ? ' is-closed' : '' ) . '"><dt>' . esc_html( $day ) . '</dt><dd>'
			. ( '' === $value ? esc_html__( 'Fermé', 'corbuilder' ) : esc_html( $value ) ) . '</dd></div>';
	}
	return $html . '</dl>';
}

/* ---------- Réseaux sociaux ---------- */
function corbuilder_social_networks() {
	return array(
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'linkedin'  => 'LinkedIn',
		'x'         => 'X',
		'youtube'   => 'YouTube',
		'tiktok'    => 'TikTok',
		'pinterest' => 'Pinterest',
		'whatsapp'  => 'WhatsApp',
	);
}

/* Liens renseignés : slug => URL (http ou https uniquement) */
function corbuilder_social_links() {
	$links = array();
	foreach ( corbuilder_social_networks() as $slug => $label ) {
		$url = esc_url_raw( corbuilder_contact_value( 'social_' . $slug ), array( 'http', 'https' ) );
		if ( '' !== $url ) {
			$links[ $slug ] = $url;
		}
	}
	return $links;
}

/* Logo d'un réseau (dossier icons/social), nettoyé : couleur du texte, taille en em */
function corbuilder_social_icon_svg( $slug ) {
	static $cache = array();
	if ( isset( $cache[ $slug ] ) ) {
		return $cache[ $slug ];
	}
	$file = '';
	foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $dir ) {
		if ( preg_match( '/^[a-z0-9-]+$/', $slug ) && is_readable( $dir . '/icons/social/' . $slug . '.svg' ) ) {
			$file = $dir . '/icons/social/' . $slug . '.svg';
			break;
		}
	}
	if ( '' === $file ) {
		return '';
	}
	$svg = (string) file_get_contents( $file );
	$svg = preg_replace( '/<!--.*?-->|<title>.*?<\/title>/s', '', $svg );
	$svg = preg_replace_callback( '/<svg\b[^>]*>/s', function ( $m ) {
		$tag = preg_replace( '/\s(width|height|class|role|fill)="[^"]*"/', '', $m[0] );
		return preg_replace( '/<svg/', '<svg class="social__icon" aria-hidden="true" focusable="false" fill="currentColor"', $tag, 1 );
	}, $svg, 1 );
	$svg = trim( preg_replace( '/\s+/', ' ', $svg ) );
	$svg = str_replace( '> <', '><', preg_replace( '/\s+>/', '>', $svg ) );
	return $cache[ $slug ] = ( false !== strpos( $svg, '<svg' ) ) ? $svg : '';
}

function corbuilder_social_html( $class = '' ) {
	$links = corbuilder_social_links();
	if ( ! $links ) {
		return '';
	}
	$labels = corbuilder_social_networks();
	$html   = '<ul class="social' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '">';
	foreach ( $links as $slug => $url ) {
		$html .= '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( $labels[ $slug ] ) . '">' . corbuilder_social_icon_svg( $slug ) . '</a></li>';
	}
	return $html . '</ul>';
}

/* ---------- Carte : chargée seulement après un clic (aucune requête avant) ---------- */
function corbuilder_map_hosts() {
	return apply_filters( 'corbuilder_map_hosts', array( 'www.google.com', 'maps.google.com', 'www.openstreetmap.org', 'umap.openstreetmap.fr' ) );
}

/* Adresse d'intégration (https, sites de cartes connus) ou chaîne vide */
function corbuilder_sanitize_map_url( $url ) {
	$url  = esc_url_raw( trim( (string) $url ), array( 'https' ) );
	$host = $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
	return ( $host && in_array( strtolower( $host ), corbuilder_map_hosts(), true ) ) ? $url : '';
}

function corbuilder_map_html() {
	static $script_done = false;
	$url = corbuilder_sanitize_map_url( corbuilder_contact_value( 'contact_map_url' ) );
	if ( '' === $url ) {
		return '';
	}
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$html = '<div class="map" data-src="' . esc_url( $url ) . '" data-title="' . esc_attr__( 'Carte', 'corbuilder' ) . '"><div class="map__placeholder">'
		/* translators: %s : nom du site de cartes */
		. '<p>' . esc_html( sprintf( __( 'La carte est fournie par %s. En l’affichant, votre adresse IP lui est transmise.', 'corbuilder' ), $host ) ) . '</p>'
		. '<button type="button" class="btn map__load">' . esc_html__( 'Afficher la carte', 'corbuilder' ) . '</button></div></div>';
	if ( ! $script_done ) {
		$script_done = true;
		$html .= '<script>document.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest(".map__load");if(!b)return;var m=b.closest(".map");if(!m)return;var f=document.createElement("iframe");f.src=m.getAttribute("data-src");f.title=m.getAttribute("data-title")||"Carte";f.loading="lazy";f.referrerPolicy="no-referrer";f.allowFullscreen=true;m.innerHTML="";m.appendChild(f);m.classList.add("is-loaded")});</script>';
	}
	return $html;
}

/* ---------- Section « Coordonnées » ---------- */
function corbuilder_contact_item_html( $icon, $title, $inner ) {
	return '<div class="contact-item"><span class="contact-item__icon">' . corbuilder_icon_svg( $icon, 'contact-item__svg' ) . '</span><div class="contact-item__body"><h3 class="contact-item__title">' . esc_html( $title ) . '</h3>' . $inner . '</div></div>';
}

/* Contenu de la section selon les cases cochées ; vide si rien n'est renseigné */
function corbuilder_contact_info_html( $d ) {
	$items   = '';
	$address = corbuilder_contact_value( 'contact_address' );
	$phone   = corbuilder_contact_value( 'contact_phone' );
	$email   = corbuilder_contact_value( 'contact_email' );

	if ( ! empty( $d['show_address'] ) && '' !== $address ) {
		$route  = 'https://www.openstreetmap.org/search?query=' . rawurlencode( preg_replace( '/\s*\R\s*/', ', ', $address ) );
		$items .= corbuilder_contact_item_html( 'map-pin', __( 'Adresse', 'corbuilder' ),
			'<p>' . nl2br( esc_html( $address ) ) . '</p><a class="contact-item__link" href="' . esc_url( $route ) . '" target="_blank" rel="noopener">' . esc_html__( 'Voir l’itinéraire', 'corbuilder' ) . '</a>' );
	}
	if ( ! empty( $d['show_phone'] ) && '' !== corbuilder_tel_href( $phone ) ) {
		$items .= corbuilder_contact_item_html( 'phone', __( 'Téléphone', 'corbuilder' ), '<p><a href="' . esc_url( corbuilder_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a></p>' );
	}
	if ( ! empty( $d['show_email'] ) && is_email( $email ) ) {
		$items .= corbuilder_contact_item_html( 'mail', __( 'E-mail', 'corbuilder' ), '<p><a href="mailto:' . esc_attr( antispambot( $email, 1 ) ) . '">' . antispambot( esc_html( $email ) ) . '</a></p>' );
	}
	$hours  = ( ! empty( $d['show_hours'] ) && '' !== corbuilder_hours_html() ) ? corbuilder_contact_item_html( 'clock', __( 'Horaires', 'corbuilder' ), corbuilder_hours_html() ) : '';
	$social = ( ! empty( $d['show_social'] ) && '' !== corbuilder_social_html() ) ? corbuilder_social_html( 'social--section' ) : '';

	if ( '' !== $hours && ( '' !== $items || '' !== $social ) ) {
		// Deux colonnes : les horaires d'un côté, le reste (adresse, téléphone, e-mail, réseaux sociaux) de l'autre
		$rest  = '' === $items ? '' : '<div class="contact-grid">' . $items . '</div>';
		$rest .= '' === $social ? '' : '<div class="contact-social">' . $social . '</div>';
		$html  = '<div class="contact-cols anim"><div class="contact-col contact-col--hours"><div class="contact-grid">' . $hours . '</div></div>'
			. '<div class="contact-col contact-col--info">' . $rest . '</div></div>';
	} else { // une seule colonne : mise en page habituelle
		$items .= $hours;
		$html   = '' === $items ? '' : '<div class="contact-grid anim">' . $items . '</div>';
		if ( '' !== $social ) {
			$html .= '<div class="contact-social anim">' . $social . '</div>';
		}
	}
	if ( ! empty( $d['show_map'] ) && '' !== corbuilder_map_html() ) {
		$html .= '<div class="contact-map anim">' . corbuilder_map_html() . '</div>';
	}
	return $html;
}

/* ---------- Pied de page ---------- */
function corbuilder_footer_contact_html() {
	if ( ! corbuilder_mod( 'footer_show_contact' ) ) {
		return '';
	}
	$lines   = '';
	$address = corbuilder_contact_value( 'contact_address' );
	$phone   = corbuilder_contact_value( 'contact_phone' );
	$email   = corbuilder_contact_value( 'contact_email' );
	if ( '' !== $address ) {
		$lines .= '<li>' . nl2br( esc_html( $address ) ) . '</li>';
	}
	if ( '' !== corbuilder_tel_href( $phone ) ) {
		$lines .= '<li><a href="' . esc_url( corbuilder_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a></li>';
	}
	if ( is_email( $email ) ) {
		$lines .= '<li><a href="mailto:' . esc_attr( antispambot( $email, 1 ) ) . '">' . antispambot( esc_html( $email ) ) . '</a></li>';
	}
	return '' === $lines ? '' : '<ul class="footer-contact">' . $lines . '</ul>';
}

function corbuilder_footer_social_html() {
	return corbuilder_mod( 'footer_show_social' ) ? corbuilder_social_html( 'social--footer' ) : '';
}
