<?php
defined( 'ABSPATH' ) || exit;

function corbuilder_customize_register( $wp_customize ) {
	require_once get_template_directory() . '/inc/controls.php';
	$d = corbuilder_defaults();

	$setting = function ( $id, $default, $sanitize, $capability = 'edit_theme_options' ) use ( $wp_customize ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $default,
			'sanitize_callback' => $sanitize,
			'capability'        => $capability,
		) );
	};
	$in = function ( array $allowed, $default ) {
		return function ( $value ) use ( $allowed, $default ) {
			return in_array( $value, $allowed, true ) ? $value : $default;
		};
	};
	$items = function ( $modules ) {
		$out = array();
		foreach ( $modules as $id => $m ) {
			$out[ $id ] = array( 'label' => $m['label'], 'description' => $m['description'], 'preview' => $m['preview'] );
		}
		return $out;
	};
	$select = function ( $id, $label, $section, $choices ) use ( $wp_customize, $setting, $in, $d ) {
		$setting( $id, $d[ $id ], $in( array_keys( $choices ), $d[ $id ] ) );
		$wp_customize->add_control( $id, array( 'label' => $label, 'section' => $section, 'type' => 'select', 'choices' => $choices ) );
	};
	$checkbox = function ( $id, $label, $section ) use ( $wp_customize, $setting, $d ) {
		$setting( $id, $d[ $id ], 'corbuilder_sanitize_checkbox' );
		$wp_customize->add_control( $id, array( 'label' => $label, 'section' => $section, 'type' => 'checkbox' ) );
	};
	$choice = function ( $id, $label, $section, $modules ) use ( $wp_customize, $setting, $in, $items, $d ) {
		$setting( $id, $d[ $id ], $in( array_keys( $modules ), $d[ $id ] ) );
		$wp_customize->add_control( new Corbuilder_Choice_Control( $wp_customize, $id, array(
			'label'   => $label,
			'section' => $section,
			'items'   => $items( $modules ),
		) ) );
	};

	/* ---------- Panneau « Style » : style global, couleurs, boutons et cartes ---------- */
	$wp_customize->add_panel( 'corbuilder_look_panel', array(
		'title'       => __( 'Style', 'corbuilder' ),
		'description' => __( 'L’apparence générale du site : style, couleurs, arrondi, boutons, cartes et densité.', 'corbuilder' ),
		'priority'    => 24,
	) );

	/* ---------- Panneau : réglages généraux ---------- */
	$wp_customize->add_panel( 'corbuilder_style_panel', array(
		'title'       => __( 'Réglages du thème', 'corbuilder' ),
		'description' => __( 'Le logo et le nom du site se modifient dans « Identité du site », les menus dans « Menus ».', 'corbuilder' ),
		'priority'    => 25,
	) );

	/* Style global et animation */
	$wp_customize->add_section( 'corbuilder_global', array( 'title' => __( 'Style global et animation', 'corbuilder' ), 'panel' => 'corbuilder_look_panel' ) );
	$choice( 'global_style', __( 'Style global', 'corbuilder' ), 'corbuilder_global', corbuilder_get_styles() );
	$anims = array( 'none' => __( 'Aucune animation', 'corbuilder' ) );
	foreach ( corbuilder_get_animations() as $id => $a ) {
		$anims[ $id ] = $a['label'];
	}
	$select( 'animation', __( 'Animation à l’apparition', 'corbuilder' ), 'corbuilder_global', $anims );

	/* Couleurs et arrondi */
	$wp_customize->add_section( 'corbuilder_style', array( 'title' => __( 'Couleurs et arrondi', 'corbuilder' ), 'panel' => 'corbuilder_look_panel' ) );
	$setting( 'primary', $d['primary'], 'sanitize_hex_color' );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'primary', array(
		'label'   => __( 'Couleur principale (liens, titres, accents)', 'corbuilder' ),
		'section' => 'corbuilder_style',
	) ) );
	$setting( 'secondary', $d['secondary'], 'sanitize_hex_color' );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'secondary', array(
		'label'   => __( 'Couleur secondaire (fonds, pied de page, cartes)', 'corbuilder' ),
		'section' => 'corbuilder_style',
	) ) );
	$setting( 'radius', $d['radius'], 'absint' );
	$wp_customize->add_control( 'radius', array(
		'label'       => __( 'Arrondi des images et composants (px)', 'corbuilder' ),
		'section'     => 'corbuilder_style',
		'type'        => 'range',
		'input_attrs' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
	) );

	/* Boutons, cartes et densité */
	$wp_customize->add_section( 'corbuilder_ui', array( 'title' => __( 'Boutons, cartes et densité', 'corbuilder' ), 'panel' => 'corbuilder_look_panel' ) );
	$select( 'btn_style', __( 'Style des boutons', 'corbuilder' ), 'corbuilder_ui', array(
		'solid'   => __( 'Pleins', 'corbuilder' ),
		'outline' => __( 'Contour', 'corbuilder' ),
	) );
	$select( 'btn_shape', __( 'Forme des boutons', 'corbuilder' ), 'corbuilder_ui', array(
		'theme'  => __( 'Arrondi du thème', 'corbuilder' ),
		'pill'   => __( 'Pilule', 'corbuilder' ),
		'square' => __( 'Carrée', 'corbuilder' ),
	) );
	$select( 'card_style', __( 'Style des cartes', 'corbuilder' ), 'corbuilder_ui', array(
		'shadow' => __( 'Ombre', 'corbuilder' ),
		'strong' => __( 'Ombre prononcée', 'corbuilder' ),
		'border' => __( 'Bordure', 'corbuilder' ),
		'flat'   => __( 'Sans ombre ni bordure', 'corbuilder' ),
	) );
	$select( 'density', __( 'Densité des pages (espace entre sections)', 'corbuilder' ), 'corbuilder_ui', array(
		'compact'  => __( 'Compacte', 'corbuilder' ),
		'standard' => __( 'Standard', 'corbuilder' ),
		'spacious' => __( 'Aérée', 'corbuilder' ),
	) );

	/* En-tête */
	$wp_customize->add_section( 'corbuilder_header', array( 'title' => __( 'En-tête', 'corbuilder' ), 'panel' => 'corbuilder_style_panel' ) );
	$choice( 'header_style', __( 'Style de l’en-tête', 'corbuilder' ), 'corbuilder_header', corbuilder_get_headers() );
	$choice( 'menu_style', __( 'Style du menu', 'corbuilder' ), 'corbuilder_header', corbuilder_get_menus() );
	// Seconde image : proposée seulement avec un style d'en-tête qui la prévoit (clé « second_image » du module)
	$setting( 'header_image2', 0, 'absint' );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'header_image2', array(
		'label'           => __( 'Seconde image de l’en-tête', 'corbuilder' ),
		'description'     => __( 'Affichée à gauche avec le style d’en-tête « Deux images ».', 'corbuilder' ),
		'section'         => 'corbuilder_header',
		'mime_type'       => 'image',
		'active_callback' => function () use ( $wp_customize ) {
			$setting = $wp_customize->get_setting( 'header_style' );
			$id      = $setting ? $setting->value() : corbuilder_mod( 'header_style' );
			$headers = corbuilder_get_headers();
			return ! empty( $headers[ $id ]['second_image'] );
		},
	) ) );
	$select( 'header_color', __( 'Couleur de l’en-tête', 'corbuilder' ), 'corbuilder_header', corbuilder_surface_choices() );
	$setting( 'header_color_custom', $d['header_color_custom'], 'sanitize_hex_color' );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'header_color_custom', array(
		'label'           => __( 'Couleur personnalisée de l’en-tête', 'corbuilder' ),
		'section'         => 'corbuilder_header',
		'active_callback' => function () use ( $wp_customize ) {
			$s = $wp_customize->get_setting( 'header_color' );
			return $s && 'custom' === $s->value();
		},
	) ) );
	$checkbox( 'header_transparent', __( 'En-tête transparent sur le bandeau (Image Head en première section)', 'corbuilder' ), 'corbuilder_header' );
	$checkbox( 'show_site_name', __( 'Afficher le nom du site à côté du logo', 'corbuilder' ), 'corbuilder_header' );
	$checkbox( 'hide_site_name_mobile', __( 'Cacher le nom du site sur petit écran (le logo reste seul)', 'corbuilder' ), 'corbuilder_header' );
	$checkbox( 'header_sticky', __( 'En-tête fixe : il se masque quand on descend et réapparaît dès qu’on remonte', 'corbuilder' ), 'corbuilder_header' );

	/* Pied de page : style, texte, titres des colonnes et liens des pages légales */
	$wp_customize->add_section( 'corbuilder_footer', array(
		'title'       => __( 'Pied de page', 'corbuilder' ),
		'description' => __( 'Les menus du pied de page se choisissent dans « Menus » (emplacements « Pied de page » et « Pied de page, 2e colonne »).', 'corbuilder' ),
		'panel'       => 'corbuilder_style_panel',
	) );
	$choice( 'footer_style', __( 'Style du pied de page', 'corbuilder' ), 'corbuilder_footer', corbuilder_get_footers() );
	$select( 'footer_color', __( 'Couleur du pied de page', 'corbuilder' ), 'corbuilder_footer', corbuilder_surface_choices() );
	$setting( 'footer_color_custom', $d['footer_color_custom'], 'sanitize_hex_color' );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_color_custom', array(
		'label'           => __( 'Couleur personnalisée du pied de page', 'corbuilder' ),
		'section'         => 'corbuilder_footer',
		'active_callback' => function () use ( $wp_customize ) {
			$s = $wp_customize->get_setting( 'footer_color' );
			return $s && 'custom' === $s->value();
		},
	) ) );
	$setting( 'footer_text', $d['footer_text'], 'wp_kses_post' );
	$wp_customize->add_control( 'footer_text', array(
		'label'       => __( 'Texte du pied de page', 'corbuilder' ),
		'description' => __( 'Variables : {year} et {site}.', 'corbuilder' ),
		'section'     => 'corbuilder_footer',
		'type'        => 'textarea',
	) );

	$checkbox( 'footer_show_contact', __( 'Afficher les coordonnées (adresse, téléphone, e-mail)', 'corbuilder' ), 'corbuilder_footer' );
	$checkbox( 'footer_show_social', __( 'Afficher les réseaux sociaux', 'corbuilder' ), 'corbuilder_footer' );

	// Titres des colonnes : seulement avec le style « Colonnes ».
	$columns_only = function () {
		return 'columns' === corbuilder_mod( 'footer_style' );
	};
	$titles = array(
		'footer_title_main'  => array( __( 'Titre de la colonne de présentation', 'corbuilder' ), __( 'Vide : le nom du site.', 'corbuilder' ) ),
		'footer_title_contact' => array( __( 'Titre de la colonne des coordonnées', 'corbuilder' ), __( 'Laisse vide pour ne pas afficher de titre.', 'corbuilder' ) ),
		'footer_title_menu1' => array( __( 'Titre de la colonne « Pied de page »', 'corbuilder' ), __( 'Laisse vide pour ne pas afficher de titre.', 'corbuilder' ) ),
		'footer_title_menu2' => array( __( 'Titre de la colonne « 2e colonne »', 'corbuilder' ), __( 'Laisse vide pour ne pas afficher de titre.', 'corbuilder' ) ),
	);
	foreach ( $titles as $id => $info ) {
		$setting( $id, $d[ $id ], 'sanitize_text_field' );
		$wp_customize->add_control( $id, array(
			'label'           => $info[0],
			'description'     => $info[1],
			'section'         => 'corbuilder_footer',
			'type'            => 'text',
			'active_callback' => $columns_only,
		) );
	}

	// Liens des pages légales (les brouillons se créent dans Apparence → Brouillons disponibles).
	$setting( 'show_legal_links', $d['show_legal_links'], 'corbuilder_sanitize_checkbox' );
	$wp_customize->add_control( 'show_legal_links', array(
		'label'       => __( 'Afficher les liens des pages légales', 'corbuilder' ),
		'description' => __( 'Choisis la page de chaque lien ; seules les pages publiées s’affichent. Modèles à compléter : Apparence → Brouillons disponibles. Politique de confidentialité : à défaut, la page définie dans Réglages → Confidentialité.', 'corbuilder' ),
		'section'     => 'corbuilder_footer',
		'type'        => 'checkbox',
	) );
	foreach ( corbuilder_legal_pages() as $legal ) {
		$setting( $legal['mod'], 0, 'absint' );
		$wp_customize->add_control( $legal['mod'], array(
			/* translators: %s : nom de la page légale */
			'label'   => sprintf( __( 'Lien « %s » : page', 'corbuilder' ), $legal['label'] ),
			'section' => 'corbuilder_footer',
			'type'    => 'dropdown-pages',
		) );
	}

	/* Barre d'annonce */
	$wp_customize->add_section( 'corbuilder_announce', array( 'title' => __( 'Barre d’annonce', 'corbuilder' ), 'panel' => 'corbuilder_style_panel' ) );
	$checkbox( 'announce_on', __( 'Afficher la barre d’annonce', 'corbuilder' ), 'corbuilder_announce' );
	$setting( 'announce_text', '', 'sanitize_text_field' );
	$wp_customize->add_control( 'announce_text', array( 'label' => __( 'Texte', 'corbuilder' ), 'section' => 'corbuilder_announce', 'type' => 'text' ) );
	$setting( 'announce_url', '', 'corbuilder_sanitize_url' );
	$wp_customize->add_control( 'announce_url', array( 'label' => __( 'Lien (facultatif)', 'corbuilder' ), 'section' => 'corbuilder_announce', 'type' => 'url' ) );
	$checkbox( 'announce_closable', __( 'Le visiteur peut la fermer', 'corbuilder' ), 'corbuilder_announce' );

	/* Articles : éditeur utilisé pour écrire les articles */
	$wp_customize->add_section( 'corbuilder_posts', array(
		'title'       => __( 'Articles', 'corbuilder' ),
		'description' => __( 'Les pages gardent toujours l’éditeur de blocs. Un article déjà écrit en blocs peut perdre sa mise en forme (colonnes, couvertures) s’il est enregistré dans l’éditeur classique : sauvegarde avant de changer.', 'corbuilder' ),
		'panel'       => 'corbuilder_style_panel',
	) );
	$checkbox( 'classic_editor_posts', __( 'Écrire les articles avec l’éditeur classique (sinon : éditeur de blocs)', 'corbuilder' ), 'corbuilder_posts' );

	/* Éditeur de contenu : ce que le rôle « Éditeur de contenu » peut faire dans Personnaliser */
	$wp_customize->add_section( 'corbuilder_editor', array(
		'title'       => __( 'Éditeur de contenu', 'corbuilder' ),
		'description' => __( 'Le rôle « Éditeur de contenu » (Utilisateurs → Ajouter) modifie les textes, les images et les liens des pages dans Personnaliser, sans pouvoir changer la structure ni les réglages.', 'corbuilder' ),
		'panel'       => 'corbuilder_style_panel',
		'priority'    => 990,
	) );
	$checkbox( 'editor_allow_lists', __( 'Autoriser l’ajout, la suppression et le déplacement d’éléments dans les listes (cartes, équipe, compteurs…)', 'corbuilder' ), 'corbuilder_editor' );

	/* À propos : numéro de version du thème (dernière entrée du panneau « Réglages du thème ») */
	$wp_customize->add_section( 'corbuilder_about', array(
		/* translators: %s: numéro de version du thème */
		'title'    => sprintf( __( 'À propos (version %s)', 'corbuilder' ), CORBUILDER_VERSION ),
		'panel'    => 'corbuilder_style_panel',
		'priority' => 999,
	) );
	$wp_customize->add_control( new Corbuilder_Info_Control( $wp_customize, 'corbuilder_about_version', array(
		'label'       => sprintf( __( 'Corbuilder %s', 'corbuilder' ), CORBUILDER_VERSION ),
		'description' => __( 'Version du thème installée sur ce site.', 'corbuilder' ),
		'section'     => 'corbuilder_about',
		'settings'    => array(),
	) ) );
	$wp_customize->add_control( new Corbuilder_Changelog_Control( $wp_customize, 'corbuilder_about_changelog', array(
		'label'    => __( 'Historique des versions', 'corbuilder' ),
		'section'  => 'corbuilder_about',
		'settings' => array(),
	) ) );

	/* ---------- Panneau « Coordonnées » : saisies une fois, utilisées par le pied de page et la section Coordonnées ---------- */
	$wp_customize->add_panel( 'corbuilder_contact_panel', array(
		'title'       => __( 'Coordonnées', 'corbuilder' ),
		'description' => __( 'Adresse, téléphone, e-mail, horaires, réseaux sociaux et carte. Ces informations servent au pied de page et à la section « Coordonnées ».', 'corbuilder' ),
		'priority'    => 27,
	) );

	$wp_customize->add_section( 'corbuilder_contact', array( 'title' => __( 'Adresse et contact', 'corbuilder' ), 'panel' => 'corbuilder_contact_panel' ) );
	$setting( 'contact_address', '', 'sanitize_textarea_field' );
	$wp_customize->add_control( 'contact_address', array( 'label' => __( 'Adresse', 'corbuilder' ), 'section' => 'corbuilder_contact', 'type' => 'textarea' ) );
	$setting( 'contact_phone', '', 'sanitize_text_field' );
	$wp_customize->add_control( 'contact_phone', array( 'label' => __( 'Téléphone', 'corbuilder' ), 'section' => 'corbuilder_contact', 'type' => 'text' ) );
	$setting( 'contact_email', '', 'sanitize_email' );
	$wp_customize->add_control( 'contact_email', array( 'label' => __( 'E-mail', 'corbuilder' ), 'section' => 'corbuilder_contact', 'type' => 'email' ) );
	$setting( 'contact_map_url', '', 'corbuilder_sanitize_map_url' );
	$wp_customize->add_control( 'contact_map_url', array(
		'label'       => __( 'Carte : adresse d’intégration', 'corbuilder' ),
		'description' => __( 'Colle l’adresse « src » du code d’intégration (Google Maps ou OpenStreetMap, en https). La carte ne se charge qu’au clic du visiteur, qui est prévenu que son adresse IP est transmise au site de cartes.', 'corbuilder' ),
		'section'     => 'corbuilder_contact',
		'type'        => 'url',
	) );

	$wp_customize->add_section( 'corbuilder_hours', array(
		'title'       => __( 'Horaires d’ouverture', 'corbuilder' ),
		'description' => __( 'Un jour laissé vide s’affiche « Fermé ». Si aucun jour n’est renseigné, les horaires ne s’affichent pas.', 'corbuilder' ),
		'panel'       => 'corbuilder_contact_panel',
	) );
	foreach ( corbuilder_day_labels() as $i => $day ) {
		$setting( 'hours_' . ( $i + 1 ), '', 'sanitize_text_field' );
		$wp_customize->add_control( 'hours_' . ( $i + 1 ), array( 'label' => $day, 'section' => 'corbuilder_hours', 'type' => 'text', 'input_attrs' => array( 'placeholder' => '9h00–12h30, 14h00–18h00' ) ) );
	}

	$wp_customize->add_section( 'corbuilder_social', array(
		'title'       => __( 'Réseaux sociaux', 'corbuilder' ),
		'description' => __( 'Adresse de ta page sur chaque réseau (https://…). Seuls les réseaux renseignés s’affichent.', 'corbuilder' ),
		'panel'       => 'corbuilder_contact_panel',
	) );
	foreach ( corbuilder_social_networks() as $slug => $label ) {
		$setting( 'social_' . $slug, '', 'corbuilder_sanitize_url' );
		$wp_customize->add_control( 'social_' . $slug, array( 'label' => $label, 'section' => 'corbuilder_social', 'type' => 'url' ) );
	}

	/* ---------- Panneau : sections des pages (une entrée par page) ---------- */
	$wp_customize->add_panel( 'corbuilder_pages_panel', array(
		'title'       => __( 'Sections des pages', 'corbuilder' ),
		'description' => __( 'Une entrée par page (les brouillons aussi). Ajoute, réordonne et personnalise les sections de chaque page.', 'corbuilder' ),
		'priority'    => 26,
		'capability'  => 'corbuilder_edit_content', // l'éditeur de contenu y accède, en mode restreint (textes, images, liens)
	) );

	/* Modèle des articles : une seule liste de sections, appliquée à tous les articles */
	$wp_customize->add_section( 'corbuilder_post_template', array(
		'title'       => __( 'Modèle des articles', 'corbuilder' ),
		'description' => __( 'Ce modèle s’applique à tous les articles. Garde la section « Contenu de l’article » : sans elle, le texte des articles ne s’affiche pas. Si tu vides la liste, une mise en page simple est utilisée.', 'corbuilder' ),
		'panel'       => 'corbuilder_pages_panel',
		'priority'    => 5,
	) );
	$setting( 'corbuilder_post_template_sections', corbuilder_default_post_template(), 'corbuilder_sanitize_post_template_sections' );
	add_filter( 'theme_mod_corbuilder_post_template_sections', 'corbuilder_migrate_sections_json' );
	$wp_customize->add_control( new Corbuilder_Sections_Control( $wp_customize, 'corbuilder_post_template_sections', array(
		'label'   => __( 'Sections du modèle des articles', 'corbuilder' ),
		'section' => 'corbuilder_post_template',
		'context' => 'post',
	) ) );

	foreach ( corbuilder_get_pages() as $page ) {
		$pid = (int) $page->ID;
		$sid = 'corbuilder_page_' . $pid;
		$key = 'corbuilder_p' . $pid . '_sections';

		$wp_customize->add_section( $sid, array(
			'title' => ( $page->post_title ? $page->post_title : __( '(sans titre)', 'corbuilder' ) ) . ( 'publish' === $page->post_status ? '' : ' ' . __( '(brouillon)', 'corbuilder' ) ),
			'panel' => 'corbuilder_pages_panel',
			'capability' => 'corbuilder_edit_content',
		) );
		$setting( $key, '[]', 'corbuilder_sanitize_sections', 'corbuilder_edit_content' );
		add_filter( 'theme_mod_' . $key, 'corbuilder_migrate_sections_json' );
		$wp_customize->add_control( new Corbuilder_Sections_Control( $wp_customize, $key, array(
			'label'      => __( 'Sections de la page', 'corbuilder' ),
			'section'    => $sid,
			'capability' => 'corbuilder_edit_content',
		) ) );
	}
}
add_action( 'customize_register', 'corbuilder_customize_register' );

/* Schéma des sections transmis au JavaScript du Customizer */
function corbuilder_export_fields( $fields ) {
	$out = array();
	foreach ( $fields as $key => $def ) {
		if ( isset( $def['choices'] ) ) {
			$def['choices'] = corbuilder_field_choices( $def );
		}
		$def['default'] = corbuilder_field_default( $def );
		if ( 'repeater' === $def['type'] ) {
			$def['item_defaults'] = corbuilder_field_defaults( $def['fields'] );
			$def['fields']        = corbuilder_export_fields( $def['fields'] );
		}
		$out[ $key ] = $def;
	}
	return $out;
}

function corbuilder_js_schema() {
	$out = array();
	foreach ( corbuilder_get_sections() as $id => $def ) {
		$common     = corbuilder_common_fields( $def );
		$out[ $id ] = array(
			'label'       => $def['label'],
			'description' => $def['description'],
			'preview'     => $def['preview'],
			'contexts'    => $def['contexts'],
			'unique'      => ! empty( $def['unique'] ),
			'fields'      => corbuilder_export_fields( $def['fields'] ),
			'common'      => corbuilder_export_fields( $common ),
			'defaults'    => array_merge( corbuilder_field_defaults( $def['fields'] ), corbuilder_field_defaults( $common ) ),
		);
	}
	return $out;
}

function corbuilder_customizer_assets() {
	wp_enqueue_media();
	wp_enqueue_style( 'corbuilder-customizer', get_template_directory_uri() . '/assets/customizer.css', array(), CORBUILDER_VERSION );
	wp_enqueue_script( 'corbuilder-customizer', get_template_directory_uri() . '/assets/customizer.js', array( 'jquery', 'customize-controls' ), CORBUILDER_VERSION, true );

	$pages = array();
	foreach ( corbuilder_get_pages() as $page ) {
		$pages[ 'corbuilder_page_' . $page->ID ] = esc_url_raw( corbuilder_page_preview_url( $page ) );
	}
	// L'aperçu du modèle des articles affiche l'article le plus récent.
	$latest = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'date', 'order' => 'DESC' ) );
	if ( $latest ) {
		$pages['corbuilder_post_template'] = esc_url_raw( get_permalink( $latest[0] ) );
	}
	$icons = array();
	foreach ( corbuilder_icon_library() as $icon ) {
		$icons[] = array( 'slug' => $icon['slug'], 'url' => $icon['url'] );
	}

	wp_localize_script( 'corbuilder-customizer', 'corbuilderData', array(
		'restricted' => ! current_user_can( 'edit_theme_options' ), // éditeur de contenu : textes, images et liens seulement
		'allowLists' => (bool) corbuilder_mod( 'editor_allow_lists' ),
		'schema' => corbuilder_js_schema(),
		'pages'  => $pages,
		'icons'  => $icons,
		'i18n'   => array(
			'item'          => __( 'Élément', 'corbuilder' ),
			'add'           => __( 'Ajouter', 'corbuilder' ),
			'content'       => __( 'Contenu', 'corbuilder' ),
			'background'    => __( 'Arrière-plan et style', 'corbuilder' ),
			'btnVariant'    => __( 'Variante du bouton', 'corbuilder' ),
			'variantDefault' => __( 'Selon le réglage du site', 'corbuilder' ),
			'variantSolid'  => __( 'Plein', 'corbuilder' ),
			'variantOutline' => __( 'Contour', 'corbuilder' ),
			'variantText'   => __( 'Texte uniquement', 'corbuilder' ),
			'chooseFile'    => __( 'Choisir un fichier', 'corbuilder' ),
			'changeFile'    => __( 'Changer le fichier', 'corbuilder' ),
			'removeFile'    => __( 'Retirer le fichier', 'corbuilder' ),
			'mediaFileTitle'  => __( 'Choisir un fichier', 'corbuilder' ),
			'mediaFileButton' => __( 'Utiliser ce fichier', 'corbuilder' ),
			'choose'        => __( 'Choisir une image', 'corbuilder' ),
			'change'        => __( 'Changer l’image', 'corbuilder' ),
			'removeImg'     => __( 'Retirer l’image', 'corbuilder' ),
			'remove'        => __( 'Supprimer', 'corbuilder' ),
			'duplicate'     => __( 'Dupliquer', 'corbuilder' ),
			'up'            => __( 'Monter', 'corbuilder' ),
			'down'          => __( 'Descendre', 'corbuilder' ),
			'confirmDelete' => __( 'Supprimer cet élément ?', 'corbuilder' ),
			'mediaTitle'    => __( 'Choisir une image', 'corbuilder' ),
			'mediaButton'   => __( 'Utiliser cette image', 'corbuilder' ),
			'btnLabel'      => __( 'Texte du bouton', 'corbuilder' ),
			'btnUrl'        => __( 'Lien (https://…)', 'corbuilder' ),
			'newTab'        => __( 'Ouvrir dans un nouvel onglet', 'corbuilder' ),
			'icon'          => __( 'Icône du bouton (après le texte)', 'corbuilder' ),
			'iconNone'      => __( 'Aucune', 'corbuilder' ),
			'iconLibrary'   => __( 'Bibliothèque d’icônes', 'corbuilder' ),
			'iconMedia'     => __( 'Image de la médiathèque', 'corbuilder' ),
			'iconImage'     => __( 'Image de l’icône', 'corbuilder' ),
			'tint'          => __( 'Colorer comme le texte du bouton', 'corbuilder' ),
			'searchIcon'    => __( 'Rechercher une icône…', 'corbuilder' ),
			'addPhotos'     => __( 'Ajouter des photos', 'corbuilder' ),
			'clearPhotos'   => __( 'Tout retirer', 'corbuilder' ),
			'photos'        => __( 'photo(s)', 'corbuilder' ),
		),
	) );
}
add_action( 'customize_controls_enqueue_scripts', 'corbuilder_customizer_assets' );
