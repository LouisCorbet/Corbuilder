<?php
/**
 * Section « Image Head » : bandeau avec titre H1, paragraphe et un ou deux boutons.
 * L'image se règle dans « Image de fond » (commun à toutes les sections).
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Image Head', 'corbuilder' ),
	'description' => __( 'Bandeau d’en-tête. Choisis l’image dans « Image de fond » (plus bas) ; la couleur se superpose par-dessus.', 'corbuilder' ),
	'order'       => 10,
	'h1'          => true,
	'head_align'  => 'left', // alignement du titre, du sous-titre, du texte et des boutons
	'animate'     => false, // pas d'animation : elle retarderait l'affichage du haut de page
	'bg'          => array( 'color' => 'black', 'opacity' => 45 ),
	'fields'      => array(
		'title'    => array( 'type' => 'text', 'label' => __( 'Titre (H1)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'text', 'label' => __( 'Sous-titre', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'button'  => array( 'type' => 'button', 'label' => __( 'Bouton (facultatif)', 'corbuilder' ) ),
		'button2' => array( 'type' => 'button', 'label' => __( 'Second bouton (facultatif)', 'corbuilder' ) ),
		'height' => array(
			'type'    => 'select',
			'label'   => __( 'Hauteur du bandeau', 'corbuilder' ),
			'choices' => array(
				'medium'  => __( 'Moyenne', 'corbuilder' ),
				'compact' => __( 'Compacte', 'corbuilder' ),
				'tall'    => __( 'Grande', 'corbuilder' ),
				'full'    => __( 'Plein écran', 'corbuilder' ),
			),
		),
	),
	'classes'     => function ( $d ) {
		return array( 'hero--h-' . $d['height'], 'hero--align-' . ( in_array( $d['head_align'], array( 'left', 'center', 'right' ), true ) ? $d['head_align'] : 'left' ) );
	},
	'render'      => function ( $d, $ctx ) {
		$tag   = $ctx->h1 ? 'h2' : 'h1'; // un seul H1 par page
		$title = (string) $d['title'];
		if ( '' === $title && ! $ctx->h1 ) {
			$title = get_the_title( $ctx->pid );
		}
		$ctx->h1 = true;

		if ( '' !== $title ) {
			echo '<' . $tag . ' class="hero__title' . ( '' !== $d['subtitle'] ? ' hero__title--sub' : '' ) . '">' . esc_html( $title ) . '</' . $tag . '>';
		}
		if ( '' !== $d['subtitle'] ) {
			echo '<p class="section__subtitle hero__subtitle">' . esc_html( $d['subtitle'] ) . '</p>';
		}
		if ( '' !== trim( (string) $d['text'] ) ) {
			echo '<div class="hero__text">' . corbuilder_text( $d['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- filtré par wp_kses
		}
		$btn = corbuilder_button( $d['button'] ) . corbuilder_button( $d['button2'], 'btn--secondary' );
		if ( '' !== $btn ) {
			echo '<div class="hero__actions">' . $btn . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	},
);
