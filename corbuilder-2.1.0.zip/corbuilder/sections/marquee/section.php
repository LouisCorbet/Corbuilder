<?php
/**
 * Section « Bandeau défilant » : des images (logos, partenaires, photos…) qui défilent en continu et en boucle.
 * Pas de colonne centrale : le bandeau prend toute la largeur de l'écran, l'en-tête reste dans la colonne du site.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Bandeau défilant', 'corbuilder' ),
	'description' => __( 'Des images qui défilent en continu et en boucle (logos de partenaires ou de clients, photos…). Chaque image peut avoir un lien.', 'corbuilder' ),
	'order'       => 32,
	'wrap'        => false,
	'fields'      => array(
		'title'     => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'  => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'      => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'items'     => array(
			'type'       => 'repeater',
			'label'      => __( 'Images du bandeau', 'corbuilder' ),
			'item_label' => __( 'Image', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une image', 'corbuilder' ),
			'max'        => 40,
			'fields'     => array(
				'image' => array( 'type' => 'image', 'label' => __( 'Image', 'corbuilder' ) ),
				'link'  => array( 'type' => 'url', 'label' => __( 'Lien (facultatif, https://…)', 'corbuilder' ) ),
			),
		),
		'direction' => array(
			'type'    => 'select',
			'label'   => __( 'Sens du défilement', 'corbuilder' ),
			'choices' => array(
				'left'  => __( 'Vers la gauche', 'corbuilder' ),
				'right' => __( 'Vers la droite', 'corbuilder' ),
			),
			'default' => 'left',
		),
		'speed'     => array(
			'type'    => 'select',
			'label'   => __( 'Vitesse', 'corbuilder' ),
			'choices' => array(
				'slow'   => __( 'Lente', 'corbuilder' ),
				'normal' => __( 'Normale', 'corbuilder' ),
				'fast'   => __( 'Rapide', 'corbuilder' ),
			),
			'default' => 'normal',
		),
		'height'    => array( 'type' => 'range', 'label' => __( 'Hauteur des images (px)', 'corbuilder' ), 'min' => 30, 'max' => 300, 'step' => 5, 'default' => 80 ),
		'gap'       => array( 'type' => 'range', 'label' => __( 'Espace entre les images (px)', 'corbuilder' ), 'min' => 0, 'max' => 120, 'step' => 4, 'default' => 48 ),
		'round'     => array( 'type' => 'checkbox', 'label' => __( 'Images rondes', 'corbuilder' ) ),
		'pause'     => array( 'type' => 'checkbox', 'label' => __( 'Mettre en pause au survol de la souris', 'corbuilder' ), 'default' => true ),
	),
	'skip'        => function ( $d ) {
		return empty( $d['items'] ) || ! is_array( $d['items'] );
	},
	'render'      => function ( $d ) {
		$head = corbuilder_section_head_html( $d );
		if ( '' !== $head ) {
			echo '<div class="wrap section__inner">' . $head . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}

		$items = array();
		foreach ( (array) $d['items'] as $it ) {
			$id = is_array( $it ) ? absint( isset( $it['image'] ) ? $it['image'] : 0 ) : 0;
			if ( $id ) {
				$items[] = array( 'id' => $id, 'link' => isset( $it['link'] ) ? (string) $it['link'] : '' );
			}
		}
		if ( ! $items ) {
			return;
		}

		// Chaque moitié de la bande doit dépasser la largeur de l'écran pour que la boucle n'ait pas de trou : on répète les images au besoin.
		$n      = count( $items );
		$copies = (int) ceil( 12 / $n );
		$secs   = array( 'slow' => 8, 'normal' => 5, 'fast' => 3 ); // secondes par image : la vitesse reste la même quel que soit le nombre d'images
		$dur    = $n * $copies * ( isset( $secs[ $d['speed'] ] ) ? $secs[ $d['speed'] ] : 5 );

		$list = function ( $dup ) use ( $items, $copies ) {
			$html = '<ul class="marquee__list' . ( $dup ? ' marquee__list--dup' : '' ) . '"' . ( $dup ? ' aria-hidden="true"' : '' ) . '>';
			for ( $c = 0; $c < $copies; $c++ ) {
				$hidden = $dup || $c > 0; // les copies ne sont ni lues par les lecteurs d'écran ni atteignables au clavier
				foreach ( $items as $it ) {
					$img = corbuilder_image( $it['id'], 'medium_large', array( 'class' => 'marquee__img' ) );
					if ( '' === $img ) {
						continue;
					}
					if ( '' !== $it['link'] && '' !== esc_url( $it['link'] ) ) {
						$img = '<a href="' . esc_url( $it['link'] ) . '"' . ( $hidden ? ' tabindex="-1"' : '' ) . '>' . $img . '</a>';
					}
					$html .= '<li class="marquee__item"' . ( $hidden && ! $dup ? ' aria-hidden="true"' : '' ) . '>' . $img . '</li>';
				}
			}
			return $html . '</ul>';
		};

		$class = 'marquee' . ( 'right' === $d['direction'] ? ' marquee--reverse' : '' ) . ( ! empty( $d['pause'] ) ? ' marquee--pause' : '' ) . ( ! empty( $d['round'] ) ? ' marquee--round' : '' );
		$style = sprintf( '--marquee-h:%dpx;--marquee-gap:%dpx;--marquee-dur:%ds', max( 30, min( 300, (int) $d['height'] ) ), max( 0, min( 120, (int) $d['gap'] ) ), $dur );

		echo '<div class="' . esc_attr( $class ) . '" style="' . esc_attr( $style ) . '"><div class="marquee__track">' . $list( false ) . $list( true ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
