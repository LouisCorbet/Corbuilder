<?php
/**
 * Section « En-tête de l'article » : titre (H1), informations et image à la une.
 * Réservée au modèle des articles : elle lit l'article en cours.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'En-tête de l’article', 'corbuilder' ),
	'description' => __( 'Titre de l’article (H1), informations et image à la une. En mode « bandeau », sans couleur choisie, un voile noir à 45 % rend le titre lisible ; sans image à la une, le bandeau prend la couleur principale.', 'corbuilder' ),
	'order'       => 1,
	'contexts'    => array( 'post' ),
	'unique'      => true,
	'end_button'  => false,
	'h1'          => true,
	'animate'     => false,
	'fields'      => array(
		'layout'          => array(
			'type'    => 'select',
			'label'   => __( 'Présentation', 'corbuilder' ),
			'choices' => array(
				'simple' => __( 'Titre, puis image à la une', 'corbuilder' ),
				'banner' => __( 'Bandeau : image à la une en fond', 'corbuilder' ),
				'title'  => __( 'Titre seul', 'corbuilder' ),
			),
		),
		'show_date'       => array( 'type' => 'checkbox', 'label' => __( 'Afficher la date', 'corbuilder' ), 'default' => true ),
		'show_author'     => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’auteur', 'corbuilder' ) ),
		'show_categories' => array( 'type' => 'checkbox', 'label' => __( 'Afficher les catégories', 'corbuilder' ) ),
		'show_tags'       => array( 'type' => 'checkbox', 'label' => __( 'Afficher les étiquettes', 'corbuilder' ) ),
	),
	// Mode bandeau : l'image à la une devient l'image de fond de la section.
	'prepare'     => function ( $d, $ctx ) {
		if ( 'banner' !== $d['layout'] ) {
			return $d;
		}
		if ( ! $d['bg_image'] ) {
			$d['bg_image'] = (int) get_post_thumbnail_id( $ctx->pid );
		}
		if ( 'none' === $d['bg_color'] ) {
			$d['bg_color']   = $d['bg_image'] ? 'black' : 'primary';
			$d['bg_opacity'] = $d['bg_image'] ? 45 : 100;
		}
		return $d;
	},
	'render'      => function ( $d, $ctx ) {
		$pid = $ctx->pid;
		$tag = $ctx->h1 ? 'h2' : 'h1'; // un seul H1 par page
		$ctx->h1 = true;

		$bits = array();
		if ( $d['show_date'] ) {
			$bits[] = '<time datetime="' . esc_attr( get_the_date( 'c', $pid ) ) . '">' . esc_html( get_the_date( '', $pid ) ) . '</time>';
		}
		if ( $d['show_author'] ) {
			$bits[] = esc_html( get_the_author_meta( 'display_name', get_post_field( 'post_author', $pid ) ) );
		}
		if ( $d['show_categories'] ) {
			$cats = get_the_category_list( ', ', '', $pid );
			if ( $cats ) {
				$bits[] = $cats;
			}
		}
		if ( $d['show_tags'] ) {
			$tags = get_the_tag_list( '', ', ', '', $pid );
			if ( is_string( $tags ) && '' !== $tags ) {
				$bits[] = $tags;
			}
		}

		echo '<header class="post-header post-header--' . esc_attr( $d['layout'] ) . '">';
		echo '<' . $tag . ' class="post-header__title">' . esc_html( get_the_title( $pid ) ) . '</' . $tag . '>';
		if ( $bits ) {
			echo '<p class="post-meta"><span class="post-meta__item">' . implode( '</span><span class="post-meta__item">', $bits ) . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- éléments échappés ci-dessus
		}
		if ( 'simple' === $d['layout'] && has_post_thumbnail( $pid ) ) {
			echo '<div class="post-header__image">' . get_the_post_thumbnail( $pid, 'large' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</header>';
	},
);
