<?php
/**
 * Section « Image + texte » : image d'un côté, H2 / H3 / paragraphe / bouton de l'autre.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'  => __( 'Image + texte', 'corbuilder' ),
	'order'  => 20,
	'head_align' => false, // il a son propre réglage d'alignement du texte (« text_align »)
	'fields' => array(
		'image'      => array( 'type' => 'image', 'label' => __( 'Image', 'corbuilder' ) ),
		'image_side' => array(
			'type'    => 'select',
			'label'   => __( 'Position de l’image', 'corbuilder' ),
			'choices' => array(
				'left'  => __( 'À gauche', 'corbuilder' ),
				'right' => __( 'À droite', 'corbuilder' ),
			),
		),
		'image_shadow' => array(
			'type'    => 'select',
			'label'   => __( 'Ombre de l’image', 'corbuilder' ),
			'choices' => array(
				'none'   => __( 'Aucune', 'corbuilder' ),
				'soft'   => __( 'Légère', 'corbuilder' ),
				'strong' => __( 'Prononcée', 'corbuilder' ),
			),
			'default' => 'none',
		),
		'text_align' => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du texte', 'corbuilder' ),
			'choices' => array(
				'left'    => __( 'À gauche', 'corbuilder' ),
				'right'   => __( 'À droite', 'corbuilder' ),
				'justify' => __( 'Justifié', 'corbuilder' ),
				'center'  => __( 'Centré', 'corbuilder' ),
			),
		),
		'title'      => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'   => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'       => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'button'     => array( 'type' => 'button', 'label' => __( 'Bouton (facultatif)', 'corbuilder' ) ),
	),
	'render' => function ( $d ) {
		$img = corbuilder_image( $d['image'], 'large' );

		echo '<div class="single__grid' . ( $img ? '' : ' single__grid--noimg' ) . ( 'right' === $d['image_side'] ? ' single__grid--right' : '' ) . '">';
		if ( $img ) {
			echo '<div class="single__img' . ( in_array( $d['image_shadow'], array( 'soft', 'strong' ), true ) ? ' single__img--shadow-' . $d['image_shadow'] : '' ) . ' anim">' . $img . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<div class="single__body single__body--align-' . esc_attr( $d['text_align'] ) . ' anim">';
		if ( '' !== $d['title'] ) {
			echo '<h2 class="section__title">' . esc_html( $d['title'] ) . '</h2>';
		}
		if ( '' !== $d['subtitle'] ) {
			echo '<h3 class="section__subtitle">' . esc_html( $d['subtitle'] ) . '</h3>';
		}
		if ( '' !== trim( (string) $d['text'] ) ) {
			echo '<div class="section__text">' . corbuilder_text( $d['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		$btn = corbuilder_button( $d['button'] );
		if ( '' !== $btn ) {
			echo '<div class="section__actions">' . $btn . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	},
);
