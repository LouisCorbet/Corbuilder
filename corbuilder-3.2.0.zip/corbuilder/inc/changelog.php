<?php
defined( 'ABSPATH' ) || exit;

/* Types de modification, avec la pastille affichée devant chaque point de l'historique */
function corbuilder_changelog_types() {
	return array(
		'upgrade' => __( 'Upgrade', 'corbuilder' ), // nouvelle fonctionnalité ou nouvelle section
		'update'  => __( 'Update', 'corbuilder' ),  // amélioration d'une fonctionnalité existante
		'patch'   => __( 'Patch', 'corbuilder' ),   // petit ajustement (réglage, style, détail)
		'fix'     => __( 'Fix', 'corbuilder' ),     // correction d'un défaut
	);
}

/* Historique des versions affiché dans Personnaliser → Réglages du thème → À propos.
   Une entrée par version (la plus récente en premier) ; chaque point : array( type, texte ). */
function corbuilder_changelog() {
	return array(
		'3.2.0'  => array(
			array( 'upgrade', 'Panneau latéral : comme on ajoute une section, on peut ajouter un panneau latéral à une page ou au modèle des articles (Sections des pages → « Ajouter un panneau latéral », vignettes de choix du type). Un seul type pour l’instant : « Liste d’articles ». Largeur réglable en pourcentage de l’écran (33 % par défaut), côté au choix (à droite par défaut). Sur mobile et tablette, le panneau devient un volet plein écran tiré par une languette au bord de l’écran : on la fait coulisser pour l’ouvrir, on fait glisser le panneau (ou on touche la languette, ou Échap) pour le masquer. Le panneau a un titre (H2), un sous-titre (H3) et un paragraphe comme les sections, et les réglages de fond des sections : couleur ou dégradé, opacité, image, flou, texte clair ou foncé, ombre du texte. Réservé à l’administrateur.' ),
			array( 'upgrade', 'Listes d’articles (section et panneau latéral) : filtre par étiquettes. Sans étiquette cochée, tous les articles sont listés ; sinon, ceux qui ont au moins l’une des étiquettes choisies.' ),
		),
		'3.1.0'  => array(
			array( 'update', 'Section « Texte de l’article » remplacée par « HTML personnalisé » : du HTML libre, disponible dans les pages comme dans les articles et réservé à l’administrateur (l’éditeur de contenu ne peut ni l’ajouter, ni modifier son contenu, ni la supprimer). L’administrateur peut la retirer du choix des sections d’article. Quand un article écrit dans l’éditeur WordPress passe à l’éditeur par sections, son texte y est placé même si elle est retirée du choix.' ),
			array( 'fix', 'Fond des sections : la couleur « Aucune » (transparent) n’est plus proposée et le blanc devient la couleur par défaut. Une section qui avait « Aucune » passe en blanc ; si elle a une image de fond, son opacité passe à 0 % pour que l’image reste visible comme avant. Quand on ajoute une image de fond, l’opacité de la couleur choisie passe à 50 % (au lieu de cacher l’image). Dans le bandeau de l’en-tête d’un article, le blanc par défaut garde le comportement précédent (noir à 45 % sur l’image, ou couleur principale).' ),
			array( 'update', 'Menu « Identité » de chaque section : quatre sous-menus repliables (Texte, Chips, Boutons, Style avec les options de fond et de séparateur) au lieu d’une longue liste. Dans Image Head et Image + texte, les boutons passent dans « Contenu » : ils font partie du contenu de la section, et non de son identité.' ),
			array( 'upgrade', 'Articles : l’administrateur choisit les sections disponibles pour composer le corps d’un article (Réglages du thème → Articles → « Sections disponibles dans les articles » : les mêmes vignettes que « Ajouter une section », qu’on active ou retire d’un clic, toutes actives par défaut). Le choix vaut pour les administrateurs comme pour les éditeurs de contenu : une section retirée n’est plus proposée à l’ajout ni à la duplication, et le serveur refuse de l’enregistrer. Dans les articles qui l’ont déjà, elle reste affichée et modifiable.' ),
		),
		'3.0.0'  => array(
			array( 'update', 'En-tête : nouveau réglage « Couleur des boutons de l’en-tête » (une couleur de la palette, le blanc ou le noir), proposé seulement avec les styles d’en-tête dont le menu comporte des boutons (Appel à l’action, Boutons, Menu centré + bouton…). Il s’applique aussi sur un en-tête de couleur, transparent ou fixe, et au style de boutons « contour ».' ),
			array( 'update', 'Sections des pages : en mode « éditeur par sections », un accordéon « Articles » (en dernier) liste tous les articles (publiés, brouillons, planifiés, privés), avec un champ de recherche. Un clic ouvre les sections de l’article juste sous la liste, avec l’article dans l’aperçu.' ),
			array( 'update', 'Bouton de fin de section : s’il n’y a rien d’autre au-dessus de lui dans la section, il n’a plus de marge haute.' ),
			array( 'update', 'Une section sans titre, sans sous-titre ni paragraphe (Paragraphe, Appel à l’action, Galerie, Équipe, Tableau, Liste d’articles, Coordonnées, Formulaire) reste affichée sur le site, même sans contenu : fond, espacement et transition de fin sont visibles. Les messages d’aide (« Ajoute des photos… ») ne s’affichent que dans l’aperçu de Personnaliser.' ),
			array( 'update', 'Liste des articles : lien « Dupliquer » dans les actions de chaque ligne. La copie est un brouillon (titre suivi de « (copie) ») qui reprend le texte, l’extrait, les catégories, les étiquettes, l’image à la une, les champs personnalisés et les sections de l’article.' ),
			array( 'update', 'Sections : un titre, un sous-titre ou un paragraphe non renseigné ne prend plus aucune place (le dernier élément de l’en-tête n’a plus de marge basse, et un titre fait seulement d’espaces ou de retours à la ligne compte comme vide).' ),
			array( 'upgrade', 'Articles composés par sections : nouveau réglage réservé à l’administrateur (Réglages du thème → Articles → « Éditeur des articles ») qui bascule entre l’éditeur WordPress (comportement habituel) et l’éditeur par sections. Dans ce second mode, l’écran de l’article n’a plus d’éditeur de texte : un bouton « Composer l’article » (aussi dans la liste des articles et la barre d’administration) ouvre Personnaliser sur les sections de l’article, avec l’aperçu en direct.' ),
			array( 'update', 'Le modèle des articles devient le cadre commun : en-tête, boutons, navigation et commentaires viennent du modèle, et sa section « Contenu de l’article » est l’emplacement du corps de chaque article (sans elle, le corps suit l’en-tête). En mode « éditeur WordPress », rien ne change.' ),
			array( 'update', 'À chaque enregistrement d’un article composé par sections, un texte brut (titres, paragraphes, listes, liens, images) en est tiré et écrit dans le contenu de l’article WordPress : recherche du site, flux RSS, extraits et référencement fonctionnent normalement, et le texte se retrouve dans l’éditeur WordPress si on y revient.' ),
			array( 'upgrade', 'Nouvelle section « Texte de l’article » (corps des articles seulement) : un texte mis en forme en HTML. Un article écrit dans l’éditeur WordPress arrive dans cette section, avec son texte repris tel quel, dès qu’on passe en éditeur par sections (aucune conversion à lancer).' ),
			array( 'update', 'Éditeur de contenu : peut composer le corps d’un article (ajouter, déplacer et supprimer des sections, modifier textes, images et liens), sans accès au style ni aux couleurs.' ),
		),
		'2.9.0'  => array(
			array( 'upgrade', 'Nouvelle section « Boutons de l’article » (modèle des articles) : deux boutons facultatifs, avec les mêmes réglages que les autres boutons du site (texte, icône, style, nouvel onglet). L’adresse de chaque bouton peut être lue dans un champ personnalisé de l’article, au choix dans un menu déroulant (lien, fichier ou e-mail) ; si le champ est vide, l’adresse saisie dans le bouton sert de secours, et sans adresse le bouton disparaît.' ),
			array( 'upgrade', 'En-tête de l’article : six dispositions toutes faites, choisies sur des cases imagées (titre puis image, image puis titre, texte à gauche et image à droite, image à gauche et texte à droite, bandeau, titre seul) au lieu d’une liste déroulante. Les articles déjà réglés gardent leur disposition.' ),
			array( 'update', 'En-tête de l’article : ombre sous l’image à la une (aucune, normale, beaucoup). Case « Afficher l’extrait » (le résumé saisi dans l’article, placé sous le titre dans toutes les dispositions) ; les cases date, auteur, catégories et étiquettes sont conservées.' ),
		),
		'2.8.0'  => array(
			array( 'upgrade', 'Chips dans chaque section : une liste de pastilles (autant qu’on veut, ajout et suppression libres) affichée les unes à la suite des autres sous le paragraphe. Chaque chip a son texte, sa couleur (palette du site) et une icône facultative en préfixe.' ),
			array( 'update', 'Image Head : titre et sous-titre se règlent séparément, chacun dans un menu avec des choix imagés : police (automatique, sans-serif, serif, serif italique, machine à écrire, affiche ; le sous-titre peut aussi reprendre la police du titre), taille (3 niveaux), épaisseur (3 niveaux) et couleur (palette du site).' ),
			array( 'update', 'Image Head : disposition du titre et du sous-titre au choix (sous-titre sous le titre, au-dessus, côte à côte).' ),
			array( 'upgrade', 'Nouveau style global « Éditorial + Moderne » : H1 et H2 en Playfair Display (comme Éditorial), H3, sous-titres, texte, cartes et texte animé en Poppins (comme Moderne).' ),
			array( 'update', 'Image Head : choix du style du texte animé (automatique, serif, serif italique fin, sans-serif extra-gras, machine à écrire, fin et grand) : police, taille et épaisseur.' ),
			array( 'update', 'Cartes et Liste : le contenu des cartes est réparti verticalement (en-tête, contenu et bas de carte en space-between ; le contenu occupe l’espace restant et y est centré verticalement) ; réglage « Répartition verticale dans les cartes » pour revenir à un empilement depuis le haut.' ),
			array( 'update', 'Image Head : le sous-titre est un H2 (et non plus un paragraphe).' ),
			array( 'update', 'Case « Regrouper le titre et le sous-titre en un seul titre » (menu Identité de chaque section ayant un titre et un sous-titre) : un seul H1 (Image Head) ou H2 en deux parties, rendu identique.' ),
		),
		'2.7.0'  => array(
			array( 'update', 'Titres et sous-titres des sections modifiables dans une zone de texte : un saut de ligne saisi (touche Entrée) est repris sur le site.' ),
		),
		'2.6.1'  => array(
			array( 'update', 'Ajout de l’image du thème.' ),
		),
		'2.6.0'  => array(
			array( 'upgrade', 'Mises à jour dans WordPress : la plus récente version du fichier versions.json est annoncée dans Apparence → Thèmes et Tableau de bord → Mises à jour, avec le bouton « Mettre à jour maintenant ». L’empreinte SHA-256 et la structure du zip sont vérifiées avant l’installation et les réglages sont sauvegardés (comme dans le menu Versions).' ),
		),
		'2.5.0'  => array(
			array( 'upgrade', 'Nouveau menu Apparence → Versions (administrateurs, invisible pour l’éditeur de contenu) : liste des versions disponibles lue dans un fichier versions.json dont l’adresse se règle dans la page, et installation de n’importe quelle version, qui remplace la version actuelle.' ),
			array( 'update', 'Installation sécurisée : empreinte SHA-256 et structure du zip vérifiées, réglages sauvegardés avant chaque installation (restauration possible dans la page), ancien dossier conservé si l’installation échoue.' ),
		),
		'2.4.0'  => array(
			array( 'upgrade', 'Palette de 5 couleurs (principale, secondaire, accent, fond clair, fond sombre) réglée dans Style → Couleurs : les sections, l’en-tête, le pied de page, les cartes, les compteurs et les icônes n’utilisent plus que ces couleurs, plus le blanc et le noir. Les anciennes couleurs personnalisées sont converties vers la couleur de la palette la plus proche ; « Secondaire clair » devient « Fond clair ».' ),
			array( 'upgrade', 'Nouvelle section : Tableau (6 colonnes au plus, première ligne en en-têtes, défilement ou empilement sur mobile).' ),
			array( 'upgrade', 'Image Head : cinq variantes (classique, texte animé à la suite du titre, texte animé séparé à droite, texte + image, texte encadré).' ),
			array( 'upgrade', 'Nouvel en-tête « Menu centré + bouton » : logo et nom à gauche, menu au milieu, dernier lien du menu en bouton à droite.' ),
			array( 'update', 'Réglages des sections : deux menus, « Identité » (titres, paragraphe, boutons, fond, séparateur… communs à toutes les sections) et « Contenu » (les éléments propres à la section).' ),
			array( 'update', 'Interface simplifiée : « Appel à l’action » et « Boutons » deviennent des styles d’en-tête, et le choix « Style du menu » disparaît (un en-tête Classique avec ce style de menu est converti automatiquement).' ),
			array( 'upgrade', 'Formes de fin de section pour tout le site (Style → Formes de fin de section) : le choix est appliqué à toutes les sections, qui restent modifiables ensuite.' ),
			array( 'update', 'Éditeur de contenu : peut changer l’image de fond des sections (case décochable), les 5 couleurs de la palette et la forme de fin de section globale (cases dans Éditeur de contenu).' ),
			array( 'update', 'Second bouton possible dans Image + texte, Texte + éléments et en fin de section.' ),
			array( 'update', 'Case « Texte contrasté » dans chaque section : ombre sous les titres et sous-titres.' ),
			array( 'update', 'Couleur de fond d’une section : l’opacité n’est réglable (en dessous de 100 %) que s’il y a une image de fond ; sans image, la couleur est pleine.' ),
			array( 'update', 'Flou de l’image de fond des sections (faible, moyen, fort).' ),
			array( 'update', 'Hauteur de l’en-tête réglable (normale, réduite, très réduite).' ),
			array( 'update', 'Coordonnées : un faux plan s’affiche derrière le bouton « Afficher la carte » avant son chargement.' ),
			array( 'update', 'Logo seul : quand le nom du site est caché, il reste dans la page pour les lecteurs d’écran.' ),
			array( 'fix', 'Image + texte et Texte + éléments : la barre sous le titre suit l’alignement du texte.' ),
			array( 'fix', 'Image Head : la hauteur « Compacte » est maintenant plus basse que « Moyenne ».' ),
		),
		'2.3.2'  => array(
			array( 'update', 'Import : quand l’archive n’a pas pu être envoyée, le message donne la vraie cause (limite dépassée, envoi interrompu, dossier temporaire absent ou plein…) au lieu de supposer une taille trop grande.' ),
		),
		'2.3.1'  => array(
			array( 'update', 'Section Coordonnées : ombre de la carte (aucune, légère ou prononcée).' ),
		),
		'2.3.0'  => array(
			array( 'update', 'Section Coordonnées : choix de la disposition, sur 2 lignes (informations puis carte, comme avant) ou sur 2 colonnes (informations à gauche, carte à droite).' ),
			array( 'fix', 'Section Coordonnées : le bouton « Afficher la carte » ne faisait rien ; la carte s’affiche de nouveau au clic.' ),
		),
		'2.2.0'  => array(
			array( 'upgrade', 'Éditeur de contenu : l’administrateur choisit les zones du site qu’il peut modifier (Réglages du thème → Éditeur de contenu) : logo, titre et slogan ; icône du site ; coordonnées (adresse, téléphone, e-mail, horaires, réseaux sociaux) ; barre d’annonce ; texte et titres de colonnes du pied de page.' ),
		),
		'2.1.1'  => array(
			array( 'fix', 'Éditeur de contenu : les boutons qui n’ont pas de texte ne sont plus proposés (il ne peut plus en créer un), et il ne peut plus en supprimer un en vidant son texte.' ),
		),
		'2.1.0'  => array(
			array( 'upgrade', 'Nouveau rôle « Éditeur de contenu » : un compte qui modifie les textes, les images et les liens des pages dans Personnaliser, sans pouvoir changer la structure (sections), le style ni les réglages du site.' ),
			array( 'update', 'Éditeur de contenu : réglage pour lui permettre d’ajouter, de supprimer et de déplacer des éléments dans les listes (cartes, équipe, compteurs…).' ),
		),
		'2.0.0'  => array(
			array( 'upgrade', 'Le thème s’appelle désormais Corbuilder. Il a un nouveau dossier : il s’installe comme un nouveau thème à activer, et reprend automatiquement les réglages, les menus et les sections de toutes les pages de Léger.' ),
			array( 'upgrade', 'En-tête fixe au choix : il se masque quand on descend et réapparaît dès qu’on remonte, même au milieu de la page.' ),
			array( 'update', 'Mobile : une icône à trois lignes remplace le bouton « Menu » (elle devient une croix quand le menu est ouvert).' ),
			array( 'update', 'Mobile : option pour cacher le nom du site et ne garder que le logo.' ),
			array( 'update', 'Reprise des réglages de Léger : automatique à l’activation, et bouton dans Apparence → Export / import. Les anciens exports restent importables.' ),
			array( 'patch', 'Mobile : tailles du logo et de la seconde image de l’en-tête mieux adaptées.' ),
		),
		'1.0.17' => array(
			array( 'upgrade', 'Paragraphe : liste de paragraphes titrés (numérotation au choix), pour les textes longs ; une ligne qui commence par « - » devient une puce.' ),
			array( 'upgrade', 'Pages légales créées avec la section Paragraphe : elles se modifient dans Personnaliser, pas dans l’éditeur WordPress.' ),
			array( 'update', 'Personnaliser : les pages en brouillon apparaissent aussi dans « Sections des pages ».' ),
			array( 'fix', 'Brouillons disponibles : un modèle est proposé tant qu’aucune page n’a exactement le même titre ou la même adresse (la page « Privacy Policy » de WordPress ne le bloque plus) ; le brouillon créé n’est plus relié automatiquement à un emplacement.' ),
		),
		'1.0.16' => array(
			array( 'update', 'Équipe : téléphone et e-mail pour chaque personne.' ),
			array( 'patch', 'Équipe : plus d’espace en hauteur entre les membres.' ),
			array( 'patch', 'Texte + éléments : légendes centrées sous chaque image.' ),
			array( 'fix', 'Équipe et Liste d’articles : l’alignement du titre, du sous-titre et du paragraphe s’applique bien.' ),
		),
		'1.0.15' => array(
			array( 'upgrade', 'Nouvelle section : Texte + éléments (la disposition d’« Image + texte » avec une grille de 4 images, chacune avec sa légende).' ),
		),
		'1.0.14' => array(
			array( 'upgrade', 'Variante de bouton (plein, contour, texte uniquement) au choix, bouton par bouton.' ),
			array( 'upgrade', 'Couleur de l’en-tête et du pied de page, dans leurs menus de réglages.' ),
			array( 'update', 'Menu : petite flèche à côté des liens qui ont des sous-éléments.' ),
			array( 'update', 'Historique des versions : pastille indiquant le type de chaque modification.' ),
			array( 'update', 'Dégradé : une opacité propre à chaque couleur.' ),
			array( 'update', 'Cartes : bordure avec couleur et côtés au choix (haut, droite, bas, gauche) ; le liséré par défaut est supprimé.' ),
		),
		'1.0.13' => array(
			array( 'upgrade', 'Nouvelles sections : Paragraphe (texte seul bien présenté) et Téléchargement (documents, avec aperçu des PDF).' ),
			array( 'upgrade', 'Dégradé de couleur par-dessus l’image de fond, dans toutes les sections.' ),
			array( 'upgrade', 'Alignement du titre, du sous-titre et du paragraphe réglable section par section.' ),
			array( 'upgrade', 'Appel à l’action : quatre mises en page (centrée, sur une ligne, encadré, bandeau).' ),
			array( 'upgrade', 'Historique des versions dans « À propos ».' ),
			array( 'update', 'Sous-titre dans Image Head et Appel à l’action ; titre, sous-titre et paragraphe dans Composant ; paragraphe dans Plan du site.' ),
			array( 'update', 'Image + texte : ombre de l’image.' ),
			array( 'update', 'Cartes : densité normale ou aérée, couleur de l’icône, points de liste avec icône et couleur propres à chaque point.' ),
			array( 'update', 'Coordonnées : couleur des icônes.' ),
			array( 'update', 'Pied de page : lien « Plan du site » parmi les pages légales.' ),
			array( 'patch', 'Coordonnées : horaires plus aérés.' ),
			array( 'fix', 'Espace avant le bouton de fin de section : plus large et lié à la densité du site.' ),
		),
		'1.0.12' => array(
			array( 'upgrade', 'Export / import du site (Apparence → Export / import) : pages, articles, médias, menus et réglages, avec reconnexion des images et des pages.' ),
		),
		'1.0.11' => array(
			array( 'upgrade', 'En-tête « Deux images » : seconde image à gauche, logo et titre au centre, menu à droite.' ),
		),
		'1.0.10' => array(
			array( 'upgrade', 'Nouvelles sections : Compteurs (animation et couleur par compteur) et Vidéo (YouTube, Vimeo ou fichier).' ),
		),
		'1.0.9'  => array(
			array( 'update', 'Les écarts entre titre, sous-titre, description et contenu des sections suivent la densité du site.' ),
		),
		'1.0.8'  => array(
			array( 'update', 'Bandeau défilant : arrondi des images, images rondes et léger zoom au survol des images avec lien.' ),
		),
		'1.0.7'  => array(
			array( 'upgrade', 'Nouvelle section : Bandeau défilant.' ),
			array( 'upgrade', 'Styles de menu : classique, appel à l’action, boutons (Réglages du thème → En-tête).' ),
			array( 'update', 'Image Head : second bouton.' ),
			array( 'update', 'Style des cartes : ombre prononcée.' ),
			array( 'update', 'Cartes mises en avant : bordure et taille augmentée, au choix et cumulables.' ),
			array( 'fix', 'Nombre de colonnes des cartes : les choix 2, 4 et 5 colonnes fonctionnent.' ),
		),
		'1.0.6'  => array(
			array( 'update', 'Liste : image à gauche, à droite ou en fond de carte.' ),
			array( 'fix', 'Mise en avant : la bordure passe par-dessus l’image.' ),
		),
		'1.0.5'  => array(
			array( 'fix', 'Liste : l’image s’adapte à la hauteur de la carte.' ),
		),
		'1.0.4'  => array(
			array( 'upgrade', 'Nouvelle section : Liste (les cartes, une par ligne).' ),
		),
		'1.0.3'  => array(
			array( 'update', 'Cartes : réglages en quatre groupes (en-tête, contenu, pied, style), alignements, image en fond avec couleur par-dessus.' ),
			array( 'update', 'Coordonnées : horaires et informations en deux colonnes.' ),
			array( 'update', 'Section Tarifs supprimée (utiliser Cartes avec un prix).' ),
			array( 'patch', 'Numéro de version affiché dans « À propos ».' ),
		),
	);
}
