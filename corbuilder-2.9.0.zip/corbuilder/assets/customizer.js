( function ( $, api ) {
	'use strict';

	var data   = window.corbuilderData || {};
	var i18n   = data.i18n || {};
	var schema = data.schema || {};

	/* ---------- Outils ---------- */
	function el( tag, cls, text ) {
		var $e = $( document.createElement( tag ) );
		if ( cls ) { $e.addClass( cls ); }
		if ( undefined !== text ) { $e.text( text ); }
		return $e;
	}
	function uid() { return Math.random().toString( 36 ).slice( 2, 8 ); }
	function replacer( k, v ) { return ( 'string' === typeof k && 0 === k.indexOf( '__' ) ) ? undefined : v; } // retire __open, etc.
	function clone( o ) { return JSON.parse( JSON.stringify( o, replacer ) ); }
	var restricted = !! data.restricted;                        // éditeur de contenu
	var editable   = { text: 1, multiline: 1, textarea: 1, url: 1, image: 1, gallery: 1, file: 1, button: 1, repeater: 1 }; // types de champs qu'il peut modifier
	function labelled( $f, label, $control ) {
		$( '<label/>' ).append( el( 'span', 'corbuilder-label', label ) ).append( $control ).appendTo( $f );
	}
	function checkbox( label, checked, onToggle ) {
		var $in = $( '<input type="checkbox"/>' ).prop( 'checked', !! checked ).on( 'change', function () { onToggle( $( this ).is( ':checked' ) ); } );
		return $( '<label class="corbuilder-check"/>' ).append( $in ).append( document.createTextNode( ' ' + label ) );
	}

	/* Aperçu d'un élément : premier champ texte rempli */
	function preview( fields, obj ) {
		var out = '';
		$.each( fields, function ( k, def ) {
			if ( ( 'text' === def.type || 'multiline' === def.type ) && obj[ k ] ) { out = ' — ' + String( obj[ k ] ).replace( /\s*[\r\n]+\s*/g, ' ' ).slice( 0, 40 ); return false; }
		} );
		return out;
	}

	/* ---------- Champ image (médiathèque) ---------- */
	/* Fichier de la médiathèque (document, PDF…) : on retient son numéro, on affiche son nom */
	function buildFile( def, obj, key, onChange ) {
		var $w      = el( 'div', 'corbuilder-image corbuilder-file' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $w );
		var $name   = el( 'p', 'corbuilder-file__name' ).hide().appendTo( $w );
		var $act    = el( 'div' ).appendTo( $w );
		var $choose = el( 'button', 'button' ).attr( 'type', 'button' ).appendTo( $act );
		var $remove = el( 'button', 'button-link corbuilder-remove-img', i18n.removeFile ).attr( 'type', 'button' ).appendTo( $act );

		function refresh() {
			var id = parseInt( obj[ key ], 10 ) || 0;
			if ( id ) {
				var att  = wp.media.attachment( id );
				var show = function () { $name.text( att.get( 'filename' ) || att.get( 'title' ) || ( '#' + id ) ).show(); };
				if ( att.get( 'filename' ) || att.get( 'title' ) ) { show(); } else { att.fetch().done( show ); }
			} else {
				$name.hide().text( '' );
			}
			$choose.text( id ? i18n.changeFile : i18n.chooseFile );
			$remove.toggle( !! id );
		}

		$choose.on( 'click', function () {
			var frame = wp.media( { title: i18n.mediaFileTitle, multiple: false, button: { text: i18n.mediaFileButton } } );
			frame.on( 'select', function () {
				obj[ key ] = frame.state().get( 'selection' ).first().toJSON().id;
				refresh(); onChange();
			} );
			frame.open();
		} );
		$remove.on( 'click', function () { obj[ key ] = 0; refresh(); onChange(); } );

		refresh();
		return $w;
	}

	function buildImage( def, obj, key, onChange ) {
		var $w   = el( 'div', 'corbuilder-image' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $w );
		var $img = $( '<img alt=""/>' ).hide().appendTo( $w );
		var $act = el( 'div' ).appendTo( $w );
		var $choose = el( 'button', 'button' ).attr( 'type', 'button' ).appendTo( $act );
		var $remove = el( 'button', 'button-link corbuilder-remove-img', i18n.removeImg ).attr( 'type', 'button' ).appendTo( $act );

		function refresh() {
			var id = parseInt( obj[ key ], 10 ) || 0;
			if ( id ) {
				var att  = wp.media.attachment( id );
				var show = function () {
					var s   = att.get( 'sizes' );
					var url = ( s && s.thumbnail ) ? s.thumbnail.url : att.get( 'url' );
					if ( url ) { $img.attr( 'src', url ).show(); }
				};
				if ( att.get( 'url' ) ) { show(); } else { att.fetch().done( show ); }
			} else {
				$img.hide().removeAttr( 'src' );
			}
			$choose.text( id ? i18n.change : i18n.choose );
			$remove.toggle( !! id );
		}

		$choose.on( 'click', function () {
			var frame = wp.media( { title: i18n.mediaTitle, library: { type: 'image' }, multiple: false, button: { text: i18n.mediaButton } } );
			frame.on( 'select', function () {
				obj[ key ] = frame.state().get( 'selection' ).first().toJSON().id;
				refresh(); onChange();
			} );
			frame.open();
		} );
		$remove.on( 'click', function () { obj[ key ] = 0; refresh(); onChange(); } );

		refresh();
		return $w;
	}

	/* ---------- Bibliothèque d'icônes : grille avec recherche ---------- */
	function buildIconPicker( b, key, onChange ) {
		var $p    = el( 'div', 'corbuilder-icons' );
		var $s    = $( '<input type="search"/>' ).attr( 'placeholder', i18n.searchIcon ).appendTo( $p );
		var $grid = el( 'div', 'corbuilder-icons__grid' ).appendTo( $p );
		$.each( data.icons || [], function ( i, ic ) {
			$( '<button type="button" class="corbuilder-icon"/>' )
				.attr( { title: ic.slug, 'data-slug': ic.slug } )
				.toggleClass( 'is-on', b[ key ] === ic.slug )
				.append( $( '<img alt="" loading="lazy"/>' ).attr( 'src', ic.url ) )
				.on( 'click', function () {
					b[ key ] = ic.slug;
					$grid.find( '.is-on' ).removeClass( 'is-on' );
					$( this ).addClass( 'is-on' );
					onChange();
				} )
				.appendTo( $grid );
		} );
		$s.on( 'input', function () {
			var q = $( this ).val().toLowerCase();
			$grid.children().each( function () { $( this ).toggle( -1 !== $( this ).attr( 'data-slug' ).indexOf( q ) ); } );
		} );
		return $p;
	}

	/* ---------- Champ icône : aperçu de l'icône choisie + grille de la bibliothèque ---------- */
	function buildIconField( def, key, obj, onChange ) {
		var urls = {};
		$.each( data.icons || [], function ( i, ic ) { urls[ ic.slug ] = ic.url; } );
		var $w   = el( 'div', 'corbuilder-icon-field' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $w );
		var $cur = el( 'div', 'corbuilder-icon-field__current' ).appendTo( $w );
		var $img = $( '<img alt=""/>' ).appendTo( $cur );
		var $name = el( 'span', 'corbuilder-icon-field__name' ).appendTo( $cur );
		var $none = el( 'button', 'button-link corbuilder-remove-img', i18n.iconNone ).attr( 'type', 'button' ).appendTo( $cur );
		function refresh() {
			var slug = obj[ key ];
			$img.toggle( !! slug ).attr( 'src', slug && urls[ slug ] ? urls[ slug ] : '' );
			$name.text( slug || i18n.iconNone );
			$none.toggle( !! slug );
			$w.find( '.corbuilder-icon' ).each( function () { $( this ).toggleClass( 'is-on', $( this ).attr( 'data-slug' ) === slug ); } );
		}
		$w.append( buildIconPicker( obj, key, function () { refresh(); onChange(); } ) );
		$none.on( 'click', function () { obj[ key ] = ''; refresh(); onChange(); } );
		refresh();
		return $w;
	}

	/* ---------- Champ galerie : plusieurs photos de la médiathèque, réordonnables ---------- */
	function buildGallery( def, key, obj, onChange ) {
		if ( ! Array.isArray( obj[ key ] ) ) { obj[ key ] = []; }
		var ids   = obj[ key ];
		var $w    = el( 'div', 'corbuilder-gallery' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $w );
		var $grid = el( 'div', 'corbuilder-gallery__grid' ).appendTo( $w );
		var $act  = el( 'div', 'corbuilder-gallery__actions' ).appendTo( $w );

		function draw() {
			$grid.empty();
			$.each( ids, function ( idx, id ) {
				var $t   = el( 'div', 'corbuilder-gallery__thumb' ).attr( 'data-id', id ).appendTo( $grid );
				var $img = $( '<img alt=""/>' ).appendTo( $t );
				var att  = wp.media.attachment( id );
				var show = function () {
					var s   = att.get( 'sizes' );
					var url = ( s && s.thumbnail ) ? s.thumbnail.url : att.get( 'url' );
					if ( url ) { $img.attr( 'src', url ); }
				};
				if ( att.get( 'url' ) ) { show(); } else { att.fetch().done( show ); }
				var $tools = el( 'span', 'corbuilder-gallery__tools' ).appendTo( $t );
				function tool( text, title, cls, disabled, fn ) {
					el( 'button', 'corbuilder-btn ' + cls, text ).attr( { type: 'button', title: title } ).prop( 'disabled', disabled ).appendTo( $tools ).on( 'click', fn );
				}
				function move( dir ) {
					var to = idx + dir, tmp = ids[ idx ];
					ids[ idx ] = ids[ to ]; ids[ to ] = tmp;
					onChange(); draw();
				}
				tool( '←', i18n.up, '', 0 === idx, function () { move( -1 ); } );
				tool( '→', i18n.down, '', idx === ids.length - 1, function () { move( 1 ); } );
				tool( '✕', i18n.remove, 'corbuilder-btn--danger', false, function () { ids.splice( idx, 1 ); onChange(); draw(); } );
			} );
			$count.text( ids.length ? ids.length + ' ' + i18n.photos : '' );
		}

		el( 'button', 'button', i18n.addPhotos ).attr( 'type', 'button' ).appendTo( $act ).on( 'click', function () {
			var frame = wp.media( { title: i18n.mediaTitle, library: { type: 'image' }, multiple: true, button: { text: i18n.mediaButton } } );
			frame.on( 'select', function () {
				var picked = frame.state().get( 'selection' ).toJSON();
				$.each( picked, function ( i, att ) {
					if ( att && att.id && -1 === ids.indexOf( att.id ) ) { ids.push( att.id ); }
				} );
				onChange(); draw();
			} );
			frame.open();
		} );
		el( 'button', 'button-link corbuilder-remove-img', i18n.clearPhotos ).attr( 'type', 'button' ).appendTo( $act ).on( 'click', function () {
			if ( ids.length && window.confirm( i18n.confirmDelete ) ) { ids.length = 0; onChange(); draw(); }
		} );
		var $count = el( 'span', 'corbuilder-gallery__count' ).appendTo( $act );
		draw();
		return $w;
	}

	/* ---------- Champ bouton : texte, lien, nouvel onglet, icône ---------- */
	function buildButton( def, key, obj, onChange ) {
		var b  = obj[ key ];
		var $w = el( 'div', 'corbuilder-button' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $w );

		function input( prop, placeholder, type ) {
			$( '<input/>' ).attr( { type: type, placeholder: placeholder } ).val( b[ prop ] )
				.on( 'input', function () { b[ prop ] = $( this ).val(); onChange(); } ).appendTo( $w );
		}
		input( 'label', i18n.btnLabel, 'text' );
		input( 'url', i18n.btnUrl, 'url' );
		checkbox( i18n.newTab, b.new_tab, function ( v ) { b.new_tab = v; onChange(); } ).appendTo( $w );
		if ( restricted ) { return $w; } // éditeur de contenu : texte et lien seulement (pas la variante ni l'icône)

		var $variant = $( '<select/>' );
		$.each( { 'default': i18n.variantDefault, solid: i18n.variantSolid, outline: i18n.variantOutline, text: i18n.variantText }, function ( v, l ) {
			$variant.append( $( '<option/>' ).val( v ).text( l ) );
		} );
		$variant.val( b.variant || 'default' ).on( 'change', function () { b.variant = $( this ).val(); onChange(); } );
		labelled( $w, i18n.btnVariant, $variant );

		var $type = $( '<select/>' );
		$.each( { none: i18n.iconNone, library: i18n.iconLibrary, media: i18n.iconMedia }, function ( v, l ) {
			$type.append( $( '<option/>' ).val( v ).text( l ) );
		} );
		$type.val( b.icon_type );
		labelled( $w, i18n.icon, $type );

		var $area = el( 'div', 'corbuilder-button__icon' ).appendTo( $w );
		function draw() {
			$area.empty();
			if ( 'library' === b.icon_type ) {
				$area.append( buildIconPicker( b, 'icon', onChange ) );
			} else if ( 'media' === b.icon_type ) {
				$area.append( buildImage( { label: i18n.iconImage }, b, 'icon_media', onChange ) );
				$area.append( checkbox( i18n.tint, b.icon_tint, function ( v ) { b.icon_tint = v; onChange(); } ) );
			}
		}
		$type.on( 'change', function () { b.icon_type = $( this ).val(); onChange(); draw(); } );
		draw();
		return $w;
	}

	/* ---------- Champs ---------- */
	function buildField( def, key, obj, onChange ) {
		var $f = el( 'div', 'corbuilder-field corbuilder-field--' + def.type );
		var $in, $out;

		if ( undefined === obj[ key ] ) { obj[ key ] = clone( def.default ); }

		switch ( def.type ) {
			case 'checkbox':
				$f.append( checkbox( def.label, obj[ key ], function ( v ) { obj[ key ] = v; onChange(); } ) );
				break;

			case 'select':
				$in = $( '<select/>' );
				$.each( def.choices, function ( v, l ) { $in.append( $( '<option/>' ).val( v ).text( l ) ); } );
				if ( ! Object.prototype.hasOwnProperty.call( def.choices, obj[ key ] ) && undefined !== def.default ) { obj[ key ] = def.default; } // valeur qui n'existe plus : on affiche le choix par défaut
				$in.val( obj[ key ] ).on( 'change', function () { obj[ key ] = $( this ).val(); onChange(); } );
				labelled( $f, def.label, $in );
				break;

			case 'choice':
				el( 'span', 'corbuilder-label', def.label ).appendTo( $f );
				$out = el( 'div', 'corbuilder-picker is-open' ).appendTo( $f );
				$.each( def.choices, function ( v, c ) {
					var $b = el( 'button', 'corbuilder-pick' ).attr( { type: 'button', title: c.label } ).toggleClass( 'is-on', obj[ key ] === v );
					if ( c.preview ) {
						$( '<img alt="" loading="lazy"/>' ).attr( 'src', c.preview ).appendTo( $b );
					} else {
						el( 'span', 'corbuilder-pick__ph', c.label.charAt( 0 ) ).appendTo( $b );
					}
					el( 'span', 'corbuilder-pick__label', c.label ).appendTo( $b );
					$b.on( 'click', function () {
						obj[ key ] = v;
						$out.children().removeClass( 'is-on' );
						$b.addClass( 'is-on' );
						onChange();
					} ).appendTo( $out );
				} );
				break;

			case 'multiselect':
				if ( ! Array.isArray( obj[ key ] ) ) { obj[ key ] = []; }
				el( 'span', 'corbuilder-label', def.label ).appendTo( $f );
				$out = el( 'div', 'corbuilder-multi' ).appendTo( $f );
				$.each( def.choices, function ( v, l ) {
					checkbox( l, -1 !== obj[ key ].indexOf( v ), function ( on ) {
						var i = obj[ key ].indexOf( v );
						if ( on && -1 === i ) { obj[ key ].push( v ); }
						if ( ! on && -1 !== i ) { obj[ key ].splice( i, 1 ); }
						onChange();
					} ).appendTo( $out );
				} );
				break;

			case 'multiline': // titre / sous-titre : zone de texte courte, Entrée = saut de ligne
				$in = $( '<textarea rows="2"/>' ).val( obj[ key ] ).on( 'input', function () { obj[ key ] = $( this ).val(); onChange(); } );
				labelled( $f, def.label, $in );
				break;

			case 'textarea':
				$in = $( '<textarea rows="4"/>' ).val( obj[ key ] ).on( 'input', function () { obj[ key ] = $( this ).val(); onChange(); } );
				labelled( $f, def.label, $in );
				break;

			case 'range':
				$out = $( '<output/>' ).text( obj[ key ] );
				$in  = $( '<input type="range"/>' ).attr( { min: def.min, max: def.max, step: def.step || 1 } ).val( obj[ key ] ).on( 'input', function () {
					obj[ key ] = parseFloat( $( this ).val() ); $out.text( obj[ key ] ); onChange();
				} );
				labelled( $f, def.label, $( '<div class="corbuilder-range"/>' ).append( $in, $out ) );
				break;

			case 'number':
				$in = $( '<input type="number"/>' ).attr( { min: def.min, max: def.max, step: def.step || 1 } ).val( obj[ key ] ).on( 'input', function () {
					obj[ key ] = parseFloat( $( this ).val() ) || 0; onChange();
				} );
				labelled( $f, def.label, $in );
				break;

			case 'color':
				$in = $( '<input type="color"/>' ).val( /^#[0-9a-f]{6}$/i.test( obj[ key ] ) ? obj[ key ] : '#888888' ).on( 'input change', function () {
					obj[ key ] = $( this ).val(); onChange();
				} );
				labelled( $f, def.label, $in );
				break;

			case 'image':
				$f.append( buildImage( def, obj, key, onChange ) );
				break;

			case 'file':
				$f.append( buildFile( def, obj, key, onChange ) );
				break;

			case 'icon':
				$f.append( buildIconField( def, key, obj, onChange ) );
				break;

			case 'gallery':
				$f.append( buildGallery( def, key, obj, onChange ) );
				break;

			case 'button':
				obj[ key ] = $.extend( {}, def.default, obj[ key ] );
				$f.append( buildButton( def, key, obj, onChange ) );
				break;

			case 'repeater':
				$f.append( buildRepeater( def, key, obj, onChange ) );
				break;

			default: // text, url, slug
				$in = $( '<input/>' ).attr( 'type', 'url' === def.type ? 'url' : 'text' ).val( obj[ key ] ).on( 'input', function () {
					obj[ key ] = $( this ).val(); onChange();
				} );
				labelled( $f, def.label, $in );
		}
		return $f;
	}

	/* Groupe de champs, avec champs conditionnels (show_if) */
	function hasValue( v ) {
		if ( Array.isArray( v ) ) { return v.length > 0; }
		if ( v && 'object' === typeof v ) { return !! v.label; }
		return !! v && 0 !== v;
	}
	function buildFields( fields, obj, onChange ) {
		var $c = el( 'div', 'corbuilder-fields' ), els = {}, groups = {}, passive = { select: 1, choice: 1, range: 1, color: 1, number: 1 };
		function visible( def ) { // show_if : [ champ, valeur ] ou, pour plusieurs conditions, [ [ champ, valeur ], … ]
			var c = def.show_if;
			if ( def.requires_image && ! obj.bg_image ) { return false; } // opacité : seulement avec une image de fond
			if ( ! c ) { return true; }
			if ( ! Array.isArray( c[ 0 ] ) ) { c = [ c ]; }
			return c.every( function ( p ) { return Array.isArray( p[ 1 ] ) ? -1 !== p[ 1 ].indexOf( obj[ p[ 0 ] ] ) : obj[ p[ 0 ] ] === p[ 1 ]; } ); // valeur unique ou liste de valeurs
		}
		function conditions() {
			$.each( fields, function ( k, def ) {
				if ( ( def.show_if || def.requires_image ) && els[ k ] ) { els[ k ].toggle( visible( def ) ); }
			} );
		}
		function change() { conditions(); onChange(); }
		$.each( fields, function ( k, def ) {
			if ( restricted && ! editable[ def.type ] ) { return; } // éditeur de contenu : ni style, ni couleur, ni réglage
			if ( restricted && 'button' === def.type && ! ( obj[ k ] && String( obj[ k ].label || '' ).trim() ) ) { return; } // bouton sans texte : non proposé (l'éditeur ne peut pas en créer)
			els[ k ] = buildField( def, k, obj, change );
			if ( def.group ) {
				if ( ! groups[ def.group ] ) { groups[ def.group ] = { $inner: el( 'div', 'corbuilder-fields__inner' ), filled: false }; }
				groups[ def.group ].$inner.append( els[ k ] );
				// Menu ouvert d'office (group_open) ou si un champ « de contenu » est rempli (les listes, curseurs et couleurs ont toujours une valeur : ignorés)
				if ( def.group_open || ( ! passive[ def.type ] && hasValue( obj[ k ] ) ) ) { groups[ def.group ].filled = true; }
			} else {
				els[ k ].appendTo( $c );
			}
		} );
		// Les champs rangés dans un menu dépliant (fermé, sauf si l'un d'eux est déjà rempli)
		$.each( groups, function ( name, g ) {
			$c.append( buildGroup( name, g.$inner, obj, '__grp_' + name, g.filled ) );
		} );
		conditions();
		return $c;
	}

	/* ---------- Liste ordonnable (sections et répéteurs) ---------- */
	function renderList( $list, items, opts ) {
		$list.empty();
		function again() { renderList( $list, items, opts ); }

		$.each( items, function ( idx, item ) {
			var $item   = el( 'div', 'corbuilder-item' + ( item.__open ? ' is-open' : '' ) );
			var $head   = el( 'div', 'corbuilder-item__head' ).appendTo( $item );
			var $toggle = el( 'button', 'corbuilder-item__toggle', opts.label( item, idx ) ).attr( 'type', 'button' ).appendTo( $head );
			var $tools  = el( 'span', 'corbuilder-item__tools' ).appendTo( $head );

			function tool( text, title, cls, disabled, fn ) {
				el( 'button', 'corbuilder-btn ' + cls, text ).attr( { type: 'button', title: title } ).prop( 'disabled', disabled ).appendTo( $tools ).on( 'click', fn );
			}
			function move( dir ) {
				var to = idx + dir, tmp = items[ idx ];
				items[ idx ] = items[ to ]; items[ to ] = tmp;
				opts.onChange(); again();
			}

			if ( ! opts.locked ) {
			tool( '↑', i18n.up, '', 0 === idx, function () { move( -1 ); } );
			tool( '↓', i18n.down, '', idx === items.length - 1, function () { move( 1 ); } );
			}
			if ( ! opts.locked && opts.duplicate && ( ! opts.canDuplicate || opts.canDuplicate( item ) ) ) {
				tool( '⧉', i18n.duplicate, '', items.length >= opts.max, function () {
					var copy = opts.duplicate( item ); copy.__open = true;
					items.splice( idx + 1, 0, copy ); opts.onChange(); again();
				} );
			}
			if ( ! opts.locked ) {
			tool( '✕', i18n.remove, 'corbuilder-btn--danger', false, function () {
				if ( window.confirm( i18n.confirmDelete ) ) { items.splice( idx, 1 ); opts.onChange(); again(); }
			} );
			}

			$toggle.on( 'click', function () {
				item.__open = ! item.__open;
				$item.toggleClass( 'is-open', item.__open );
			} );

			el( 'div', 'corbuilder-item__body' ).append(
				opts.body( item, function () { $toggle.text( opts.label( item, idx ) ); opts.onChange(); } )
			).appendTo( $item );

			$list.append( $item );
		} );
	}

	/* ---------- Répéteur (liste d'éléments d'un champ) ---------- */
	function buildRepeater( def, key, obj, onChange ) {
		if ( ! Array.isArray( obj[ key ] ) ) { obj[ key ] = []; }
		var list = obj[ key ];
		var max  = def.max || 24;
		var $r   = el( 'div', 'corbuilder-repeater' );
		el( 'span', 'corbuilder-label', def.label ).appendTo( $r );
		var $list = el( 'div', 'corbuilder-list' ).appendTo( $r );

		var locked = restricted && ! data.allowLists; // éditeur de contenu : listes figées, sauf réglage contraire
		var opts = {
			locked: locked,
			max: max,
			label: function ( item, idx ) { return ( def.item_label || i18n.item ) + ' ' + ( idx + 1 ) + preview( def.fields, item ); },
			body: function ( item, change ) { return buildFields( def.fields, item, change ); },
			duplicate: function ( item ) { return clone( item ); },
			onChange: onChange
		};
		function draw() { renderList( $list, list, opts ); }

		if ( ! locked ) el( 'button', 'button corbuilder-add', '+ ' + ( def.add_label || i18n.add ) ).attr( 'type', 'button' ).appendTo( $r ).on( 'click', function () {
			if ( list.length >= max ) { return; }
			var item = clone( def.item_defaults || {} );
			item.__open = true;
			list.push( item ); onChange(); draw();
		} );

		draw();
		return $r;
	}

	/* ---------- Menu dépliant (Identité, Contenu) ; l'état ouvert/fermé est gardé dans l'élément ---------- */
	function buildGroup( title, $content, state, key, openByDefault ) {
		if ( undefined === state[ key ] ) { state[ key ] = openByDefault; }
		var $g = el( 'div', 'corbuilder-group' ).toggleClass( 'is-open', !! state[ key ] );
		var $h = el( 'button', 'corbuilder-group__head' ).attr( { type: 'button', 'aria-expanded': String( !! state[ key ] ) } ).appendTo( $g );
		el( 'span', 'corbuilder-group__title', title ).appendTo( $h );
		el( 'span', 'corbuilder-group__caret' ).attr( 'aria-hidden', 'true' ).appendTo( $h );
		$h.on( 'click', function () {
			state[ key ] = ! state[ key ];
			$g.toggleClass( 'is-open', state[ key ] );
			$h.attr( 'aria-expanded', String( state[ key ] ) );
		} );
		el( 'div', 'corbuilder-group__body' ).append( $content ).appendTo( $g );
		return $g;
	}

	/* ---------- Contrôle « sections d'une page » ---------- */
	function initSections( control ) {
		var $root   = control.container.find( '.corbuilder-sections' );
		var $list   = $root.find( '.corbuilder-sections__list' );
		var $picker = $root.find( '.corbuilder-picker' );
		var items   = [];
		var picks   = {};
		var context = control.params.context || 'page';
		var allowed = function ( type ) { return schema[ type ] && ( ! schema[ type ].contexts || -1 !== schema[ type ].contexts.indexOf( context ) ); };

		try { items = JSON.parse( control.setting.get() || '[]' ); } catch ( e ) { items = []; }
		items = ( Array.isArray( items ) ? items : [] )
			.filter( function ( i ) { return i && allowed( i.type ); } )
			.map( function ( i ) { return { id: i.id || uid(), type: i.type, data: ( i.data && ! Array.isArray( i.data ) ) ? i.data : {}, __open: false }; } );

		// Une section « unique » (ex. contenu de l'article) ne peut être ajoutée qu'une fois.
		function isUsed( type ) { return !! schema[ type ].unique && items.some( function ( i ) { return i.type === type; } ); }
		function refreshPicks() {
			$.each( picks, function ( type, $b ) { $b.prop( 'disabled', isUsed( type ) ).toggleClass( 'is-disabled', isUsed( type ) ); } );
		}
		var lastSaved = null;
		function save() { lastSaved = JSON.stringify( items, replacer ); control.setting.set( lastSaved ); refreshPicks(); }

		var opts = {
			locked: restricted, // éditeur de contenu : ni ajout, ni déplacement, ni duplication, ni suppression de section
			max: 40,
			label: function ( item ) {
				var s = schema[ item.type ];
				return s.label + preview( s.fields, item.data );
			},
			body: function ( item, change ) {
				var s          = schema[ item.type ];
				var $b         = el( 'div' );
				if ( s.description ) { el( 'p', 'description', s.description ).appendTo( $b ); }
				// « Identité » : ce que toutes les sections ont en commun (titres, paragraphe, boutons, fond, séparateur…) ; « Contenu » : les éléments propres à la section
				var identityKeys = [ 'title', 'subtitle', 'merge_heading', 'text', 'chips', 'head_align', 'button', 'button2', 'end_button', 'end_button2', 'end_button_align' ];
				var identity = {}, content = {};
				$.each( identityKeys, function ( i, k ) { if ( s.fields[ k ] ) { identity[ k ] = s.fields[ k ]; } } );
				$.each( s.fields, function ( k, def ) { if ( ! identity[ k ] ) { content[ k ] = def; } } );
				if ( ! restricted ) { // le fond, l'espacement et la visibilité restent réservés à l'administrateur
					$.extend( identity, s.common );
				} else if ( data.allowBgImage && s.common && s.common.bg_image ) { // éditeur de contenu : l'image de fond seulement (si l'administrateur l'autorise)
					identity.bg_image = s.common.bg_image;
				}
				if ( ! $.isEmptyObject( identity ) ) {
					$b.append( buildGroup( i18n.identity, buildFields( identity, item.data, change ), item, '__grp_identity', true ) );
				}
				if ( ! $.isEmptyObject( content ) ) {
					$b.append( buildGroup( i18n.content, buildFields( content, item.data, change ), item, '__grp_content', true ) );
				}
				return $b;
			},
			canDuplicate: function ( item ) { return ! schema[ item.type ].unique; },
			duplicate: function ( item ) {
				var copy = clone( item ); copy.id = uid(); return copy;
			},
			onChange: save
		};
		function draw() { renderList( $list, items, opts ); refreshPicks(); }

		// Le réglage peut être modifié de l'extérieur (forme de fin de section appliquée à tout le site) : la liste se met à jour
		control.setting.bind( function ( value ) {
			if ( value === lastSaved ) { return; }
			var fresh = [], open = {};
			try { fresh = JSON.parse( value || '[]' ); } catch ( e ) { fresh = []; }
			$.each( items, function ( i, it ) { open[ it.id ] = it.__open; } );
			items.length = 0;
			$.each( Array.isArray( fresh ) ? fresh : [], function ( i, it ) {
				if ( it && allowed( it.type ) ) {
					items.push( { id: it.id || uid(), type: it.type, data: ( it.data && ! Array.isArray( it.data ) ) ? it.data : {}, __open: !! open[ it.id ] } );
				}
			} );
			draw();
		} );

		function add( type ) {
			if ( ! allowed( type ) || items.length >= opts.max || isUsed( type ) ) { return; }
			items.push( { id: uid(), type: type, data: clone( schema[ type ].defaults ), __open: true } );
			save(); draw();
		}

		/* Choix du type de section par vignettes (image preview.* du dossier de la section) */
		$.each( schema, function ( type, s ) {
			if ( ! allowed( type ) ) { return; }
			var $b = el( 'button', 'corbuilder-pick' ).attr( { type: 'button', title: s.description || '' } );
			if ( s.preview ) {
				$( '<img alt="" loading="lazy"/>' ).attr( 'src', s.preview ).appendTo( $b );
			} else {
				el( 'span', 'corbuilder-pick__ph', s.label.charAt( 0 ) ).appendTo( $b );
			}
			el( 'span', 'corbuilder-pick__label', s.label ).appendTo( $b );
			picks[ type ] = $b;
			$b.on( 'click', function () { add( type ); $picker.removeClass( 'is-open' ); } ).appendTo( $picker );
		} );
		$root.find( '.corbuilder-sections__toggle' ).on( 'click', function () { $picker.toggleClass( 'is-open' ); } );
		if ( restricted ) { $root.find( '.corbuilder-sections__toggle' ).hide(); $picker.hide(); }

		draw();
	}

	/* ---------- Forme de fin de section pour tout le site ---------- */
	function initDivider( control ) {
		var $root  = control.container.find( '.corbuilder-divider' );
		var $shape = $root.find( '.corbuilder-divider__shape' );
		var $done  = $root.find( '.corbuilder-divider__done' );
		try { // dernière forme appliquée
			var last = JSON.parse( control.setting.get() || '{}' );
			if ( last && last.shape ) { $shape.val( last.shape ); }
		} catch ( e ) {}

		$root.find( '.corbuilder-divider__apply' ).on( 'click', function () {
			if ( ! window.confirm( i18n.confirmDividerAll ) ) { return; }
			var shape = $shape.val(), count = 0;
			api.each( function ( setting ) { // pages et modèle des articles accessibles à cet utilisateur
				if ( ! /^corbuilder_p\d+_sections$/.test( setting.id ) && 'corbuilder_post_template_sections' !== setting.id ) { return; }
				var list;
				try { list = JSON.parse( setting.get() || '[]' ); } catch ( e ) { return; }
				if ( ! Array.isArray( list ) ) { return; }
				var changed = false;
				$.each( list, function ( i, it ) {
					if ( ! it || 'object' !== typeof it ) { return; }
					if ( ! it.data || Array.isArray( it.data ) ) { it.data = {}; }
					count++;
					if ( it.data.divider !== shape ) { it.data.divider = shape; changed = true; }
				} );
				if ( changed ) { setting.set( JSON.stringify( list ) ); }
			} );
			// L'action est notée dans le réglage : le serveur ne laisse l'éditeur de contenu changer la forme que par ce choix global
			control.setting.set( JSON.stringify( { shape: shape, t: Date.now() } ) );
			$done.text( ( i18n.dividerDone || '%d' ).replace( '%d', count ) ).prop( 'hidden', false );
		} );
	}

	api.bind( 'ready', function () {
		/* Ouvrir la section d'une page affiche cette page dans l'aperçu */
		$.each( data.pages || {}, function ( sectionId, url ) {
			api.section( sectionId, function ( section ) {
				section.expanded.bind( function ( open ) {
					if ( open ) { api.previewer.previewUrl.set( url ); }
				} );
			} );
		} );

		/* Les contrôles sont construits à l'ouverture de leur section */
		api.control.each( function ( control ) {
			if ( 'corbuilder_sections' === control.params.type ) {
				control.deferred.embedded.done( function () { initSections( control ); } );
			}
			if ( 'corbuilder_divider' === control.params.type ) {
				control.deferred.embedded.done( function () { initDivider( control ); } );
			}
		} );
	} );
} )( jQuery, wp.customize );
