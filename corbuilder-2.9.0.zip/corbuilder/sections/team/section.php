<?php
/**
 * Section « Équipe » : liste de personnes (photo, nom, poste, diplôme, description, téléphone, e-mail).
 * Tous les champs sont facultatifs : seuls ceux remplis s'affichent.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Équipe', 'corbuilder' ),
	'description' => __( 'Présente les membres de l’équipe : photo, nom, poste, diplôme, description, téléphone et e-mail (tous facultatifs).', 'corbuilder' ),
	'order'       => 35,
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'columns'  => array(
			'type'    => 'select',
			'label'   => __( 'Nombre de colonnes', 'corbuilder' ),
			'choices' => array(
				'2' => __( '2 colonnes', 'corbuilder' ),
				'3' => __( '3 colonnes', 'corbuilder' ),
				'4' => __( '4 colonnes', 'corbuilder' ),
				'5' => __( '5 colonnes', 'corbuilder' ),
			),
			'default' => '3',
		),
		'round'    => array( 'type' => 'checkbox', 'label' => __( 'Photos en rond', 'corbuilder' ) ),
		'members'  => array(
			'type'       => 'repeater',
			'label'      => __( 'Personnes', 'corbuilder' ),
			'item_label' => __( 'Personne', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une personne', 'corbuilder' ),
			'max'        => 30,
			'fields'     => array(
				'photo'  => array( 'type' => 'image', 'label' => __( 'Photo', 'corbuilder' ) ),
				'name'   => array( 'type' => 'text', 'label' => __( 'Nom', 'corbuilder' ) ),
				'role'   => array( 'type' => 'text', 'label' => __( 'Poste', 'corbuilder' ) ),
				'degree' => array( 'type' => 'text', 'label' => __( 'Diplôme', 'corbuilder' ) ),
				'text'   => array( 'type' => 'textarea', 'label' => __( 'Description', 'corbuilder' ) ),
				'phone'  => array( 'type' => 'text', 'label' => __( 'Téléphone', 'corbuilder' ) ),
				'email'  => array( 'type' => 'text', 'label' => __( 'E-mail', 'corbuilder' ) ),
			),
		),
	),
	// Rien à montrer : la section est masquée pour les visiteurs (visible dans l'aperçu du Customizer).
	'skip'        => function ( $d ) {
		return '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && empty( $d['members'] );
	},
	'render'      => function ( $d ) {
		if ( '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && empty( $d['members'] ) ) {
			echo '<p class="reusable__empty">' . esc_html__( 'Ajoute des personnes dans cette section.', 'corbuilder' ) . '</p>'; // visible seulement dans l'aperçu
			return;
		}

		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		if ( empty( $d['members'] ) || ! is_array( $d['members'] ) ) {
			return;
		}
		$cols = max( 2, min( 5, (int) $d['columns'] ) );
		echo '<div class="team__grid team__grid--cols-' . (int) $cols . ( $d['round'] ? ' team__grid--round' : '' ) . '">';
		foreach ( array_values( $d['members'] ) as $i => $m ) {
			$photo = corbuilder_image( isset( $m['photo'] ) ? $m['photo'] : 0, 'medium_large' );
			echo '<article class="team__member anim" style="--i:' . (int) $i . '">';
			if ( $photo ) {
				echo '<div class="team__photo">' . $photo . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			if ( ! empty( $m['name'] ) ) {
				echo '<h3 class="team__name">' . esc_html( $m['name'] ) . '</h3>';
			}
			if ( ! empty( $m['role'] ) ) {
				echo '<p class="team__role">' . esc_html( $m['role'] ) . '</p>';
			}
			if ( ! empty( $m['degree'] ) ) {
				echo '<p class="team__degree">' . esc_html( $m['degree'] ) . '</p>';
			}
			if ( ! empty( $m['text'] ) ) {
				echo '<div class="team__text">' . corbuilder_text( $m['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			// Contact : numéro cliquable (tel:) et adresse protégée contre les robots
			$phone = isset( $m['phone'] ) ? trim( (string) $m['phone'] ) : '';
			$email = isset( $m['email'] ) ? trim( (string) $m['email'] ) : '';
			$lines = '';
			if ( '' !== corbuilder_tel_href( $phone ) ) {
				$lines .= '<li><span class="team__contact-icon" aria-hidden="true">' . corbuilder_icon_svg( 'phone', 'team__contact-svg' ) . '</span><a href="' . esc_url( corbuilder_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a></li>';
			}
			if ( '' !== $email && is_email( $email ) ) {
				$lines .= '<li><span class="team__contact-icon" aria-hidden="true">' . corbuilder_icon_svg( 'mail', 'team__contact-svg' ) . '</span><a href="mailto:' . esc_attr( antispambot( $email, 1 ) ) . '">' . antispambot( esc_html( $email ) ) . '</a></li>';
			}
			if ( '' !== $lines ) {
				echo '<ul class="team__contact">' . $lines . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</article>';
		}
		echo '</div>';
	},
);
