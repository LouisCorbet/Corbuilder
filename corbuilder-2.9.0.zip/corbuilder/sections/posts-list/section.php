<?php
/**
 * Section « Liste d'articles » : les derniers articles, en cartes ou en liste.
 * Pas de filtre pour l'instant (tous les articles, du plus récent au plus ancien) ;
 * dans le modèle des articles, l'article en cours est exclu.
 */
defined( 'ABSPATH' ) || exit;

// Articles à afficher.
$corbuilder_posts_query = function ( $d ) {
	$args = array(
		'post_type'   => 'post',
		'post_status' => 'publish',
		'numberposts' => max( 1, min( 24, (int) $d['count'] ) ),
		'orderby'     => 'date',
		'order'       => 'DESC',
	);
	if ( is_singular( 'post' ) ) {
		$args['exclude'] = array( get_queried_object_id() );
	}
	return get_posts( $args );
};

return array(
	'label'       => __( 'Liste d’articles', 'corbuilder' ),
	'description' => __( 'Les derniers articles du blog, en cartes ou en liste.', 'corbuilder' ),
	'order'       => 38,
	'fields'      => array(
		'title'        => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'     => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'         => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'layout'       => array(
			'type'    => 'choice',
			'label'   => __( 'Disposition', 'corbuilder' ),
			'choices' => function () {
				return array(
					'cards' => array( 'label' => __( 'Cartes', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/layout-cards.svg' ) ),
					'list'  => array( 'label' => __( 'Liste', 'corbuilder' ), 'preview' => corbuilder_path_to_url( __DIR__ . '/layout-list.svg' ) ),
				);
			},
		),
		'columns'      => array(
			'type'    => 'select',
			'label'   => __( 'Colonnes', 'corbuilder' ),
			'choices' => array(
				'2' => __( '2 colonnes', 'corbuilder' ),
				'3' => __( '3 colonnes', 'corbuilder' ),
				'4' => __( '4 colonnes', 'corbuilder' ),
			),
			'default' => '3',
			'show_if' => array( 'layout', 'cards' ),
		),
		'count'        => array( 'type' => 'number', 'label' => __( 'Nombre d’articles', 'corbuilder' ), 'min' => 1, 'max' => 24, 'default' => 6 ),
		'show_image'   => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’image', 'corbuilder' ), 'default' => true ),
		'show_date'    => array( 'type' => 'checkbox', 'label' => __( 'Afficher la date', 'corbuilder' ), 'default' => true ),
		'show_excerpt' => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’extrait', 'corbuilder' ), 'default' => true ),
		'show_category' => array( 'type' => 'checkbox', 'label' => __( 'Afficher la catégorie', 'corbuilder' ) ),
	),
	'skip'        => function ( $d ) use ( $corbuilder_posts_query ) {
		return '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && ! $corbuilder_posts_query( $d );
	},
	'render'      => function ( $d ) use ( $corbuilder_posts_query ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$posts = $corbuilder_posts_query( $d );
		if ( ! $posts ) {
			// Sans titre, la section est masquée pour les visiteurs (skip) ; avec un titre, ce message s'affiche aussi pour eux.
			echo '<p class="reusable__empty">' . esc_html__( 'Aucun article pour l’instant.', 'corbuilder' ) . '</p>';
			return;
		}

		$is_list = ( 'list' === $d['layout'] );
		$cols    = max( 2, min( 4, (int) $d['columns'] ) );
		echo $is_list ? '<div class="posts__list">' : '<div class="posts__grid posts__grid--cols-' . (int) $cols . '">';

		foreach ( array_values( $posts ) as $i => $p ) {
			$img  = $d['show_image'] ? get_the_post_thumbnail( $p->ID, 'medium_large' ) : '';
			$url  = esc_url( get_permalink( $p ) );
			$bits = array();
			if ( $d['show_date'] ) {
				$bits[] = '<time datetime="' . esc_attr( get_the_date( 'c', $p ) ) . '">' . esc_html( get_the_date( '', $p ) ) . '</time>';
			}
			if ( $d['show_category'] ) {
				$cats = get_the_category( $p->ID );
				if ( $cats ) {
					$bits[] = esc_html( $cats[0]->name );
				}
			}
			$meta    = $bits ? implode( ' · ', $bits ) : '';
			$excerpt = $d['show_excerpt'] ? trim( (string) get_the_excerpt( $p ) ) : '';
			$title   = '<a href="' . $url . '">' . esc_html( get_the_title( $p ) ) . '</a>';
			$style   = ' style="--i:' . (int) $i . '"';

			if ( $is_list ) {
				echo '<article class="post-row anim' . ( $img ? ' post-row--has-image' : '' ) . '"' . $style . '>';
				if ( $img ) {
					echo '<a class="post-row__img" href="' . $url . '" tabindex="-1" aria-hidden="true">' . $img . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				echo '<div class="post-row__body">';
				if ( '' !== $meta ) {
					echo '<p class="post-row__meta">' . $meta . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				echo '<h3 class="post-row__title">' . $title . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
				if ( '' !== $excerpt ) {
					echo '<div class="post-row__excerpt"><p>' . esc_html( $excerpt ) . '</p></div>';
				}
				echo '</div></article>';
			} else {
				echo '<article class="card post-card anim"' . $style . '>';
				if ( $img ) {
					echo '<a class="card__img" href="' . $url . '" tabindex="-1" aria-hidden="true">' . $img . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				echo '<div class="card__body">';
				if ( '' !== $meta ) {
					echo '<p class="post-card__meta">' . $meta . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				echo '<h3 class="card__title">' . $title . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
				if ( '' !== $excerpt ) {
					echo '<div class="card__text"><p>' . esc_html( $excerpt ) . '</p></div>';
				}
				echo '</div></article>';
			}
		}
		echo '</div>';
	},
);
