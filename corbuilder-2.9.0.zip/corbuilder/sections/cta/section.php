<?php
/**
 * Section « Appel à l'action » : un titre, un sous-titre, une phrase et un ou deux boutons, en quatre mises en page :
 * centrée, texte et boutons sur une ligne, encadré, bandeau.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Appel à l’action', 'corbuilder' ),
	'description' => __( 'Un titre, une phrase et jusqu’à deux boutons, en quatre mises en page. Le fond (couleur principale par défaut) se règle dans « Identité ».', 'corbuilder' ),
	'order'       => 33,
	'end_button'  => false, // ses boutons sont déjà dans la section
	'head_align'  => false, // il a son propre réglage d'alignement (« align »), qui vaut aussi pour les boutons
	'bg'          => array( 'color' => 'primary', 'opacity' => 100 ),
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'button'   => array( 'type' => 'button', 'label' => __( 'Bouton principal', 'corbuilder' ) ),
		'button2'  => array( 'type' => 'button', 'label' => __( 'Second bouton (facultatif)', 'corbuilder' ) ),
		'layout'   => array(
			'type'    => 'select',
			'label'   => __( 'Mise en page', 'corbuilder' ),
			'choices' => array(
				'center' => __( 'Centrée (texte au-dessus des boutons)', 'corbuilder' ),
				'split'  => __( 'Sur une ligne (texte d’un côté, boutons de l’autre)', 'corbuilder' ),
				'card'   => __( 'Encadré (carte arrondie avec ombre)', 'corbuilder' ),
				'band'   => __( 'Bandeau (panneau teinté sur une ligne)', 'corbuilder' ),
			),
			'default' => 'center',
		),
		'align'    => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du texte et des boutons', 'corbuilder' ),
			'choices' => array(
				'center' => __( 'Centré', 'corbuilder' ),
				'left'   => __( 'À gauche', 'corbuilder' ),
				'right'  => __( 'À droite', 'corbuilder' ),
			),
			'default' => 'center',
		),
	),
	'skip'        => function ( $d ) {
		return '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && '' === corbuilder_button( $d['button'] ) && '' === corbuilder_button( $d['button2'] );
	},
	'render'      => function ( $d ) {
		$layout = in_array( $d['layout'], array( 'center', 'split', 'card', 'band' ), true ) ? $d['layout'] : 'center';
		$align  = in_array( $d['align'], array( 'left', 'center', 'right' ), true ) ? $d['align'] : 'center';
		echo '<div class="cta cta--' . esc_attr( $layout ) . ' cta--align-' . esc_attr( $align ) . ' anim"><div class="cta__main">';
		echo corbuilder_heading_html( $d, array( 'sub_tag' => 'p', 'title_class' => 'cta__title', 'sub_class' => 'section__subtitle cta__subtitle', 'title_sub_class' => 'cta__title--sub' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( '' !== trim( (string) $d['text'] ) ) {
			echo '<div class="cta__text">' . corbuilder_text( $d['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo corbuilder_chips_html( $d, $align ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div>';
		$b1 = corbuilder_button( $d['button'] );
		$b2 = corbuilder_button( $d['button2'], 'btn--secondary' );
		if ( '' !== $b1 || '' !== $b2 ) {
			echo '<div class="cta__actions">' . $b1 . $b2 . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	},
);
