<?php
defined( 'ABSPATH' ) || exit;

/* Types de modification, avec la pastille affichée devant chaque point de l'historique */
function corbuilder_changelog_types() {
	return array(
		'upgrade' => __( 'Upgrade', 'corbuilder' ), // nouvelle fonctionnalité ou nouvelle section
		'update'  => __( 'Update', 'corbuilder' ),  // amélioration d'une fonctionnalité existante
		'patch'   => __( 'Patch', 'corbuilder' ),   // petit ajustement (réglage, style, détail)
		'fix'     => __( 'Fix', 'corbuilder' ),     // correction d'un défaut
	);
}

/* Historique des versions affiché dans Personnaliser → Réglages du thème → À propos.
   Une entrée par version (la plus récente en premier) ; chaque point : array( type, texte ). */
function corbuilder_changelog() {
	return array(
		'2.3.1'  => array(
			array( 'update', 'Section Coordonnées : ombre de la carte (aucune, légère ou prononcée).' ),
		),
		'2.3.0'  => array(
			array( 'update', 'Section Coordonnées : choix de la disposition, sur 2 lignes (informations puis carte, comme avant) ou sur 2 colonnes (informations à gauche, carte à droite).' ),
			array( 'fix', 'Section Coordonnées : le bouton « Afficher la carte » ne faisait rien ; la carte s’affiche de nouveau au clic.' ),
		),
		'2.2.0'  => array(
			array( 'upgrade', 'Éditeur de contenu : l’administrateur choisit les zones du site qu’il peut modifier (Réglages du thème → Éditeur de contenu) : logo, titre et slogan ; icône du site ; coordonnées (adresse, téléphone, e-mail, horaires, réseaux sociaux) ; barre d’annonce ; texte et titres de colonnes du pied de page.' ),
		),
		'2.1.1'  => array(
			array( 'fix', 'Éditeur de contenu : les boutons qui n’ont pas de texte ne sont plus proposés (il ne peut plus en créer un), et il ne peut plus en supprimer un en vidant son texte.' ),
		),
		'2.1.0'  => array(
			array( 'upgrade', 'Nouveau rôle « Éditeur de contenu » : un compte qui modifie les textes, les images et les liens des pages dans Personnaliser, sans pouvoir changer la structure (sections), le style ni les réglages du site.' ),
			array( 'update', 'Éditeur de contenu : réglage pour lui permettre d’ajouter, de supprimer et de déplacer des éléments dans les listes (cartes, équipe, compteurs…).' ),
		),
		'2.0.0'  => array(
			array( 'upgrade', 'Le thème s’appelle désormais Corbuilder. Il a un nouveau dossier : il s’installe comme un nouveau thème à activer, et reprend automatiquement les réglages, les menus et les sections de toutes les pages de Léger.' ),
			array( 'upgrade', 'En-tête fixe au choix : il se masque quand on descend et réapparaît dès qu’on remonte, même au milieu de la page.' ),
			array( 'update', 'Mobile : une icône à trois lignes remplace le bouton « Menu » (elle devient une croix quand le menu est ouvert).' ),
			array( 'update', 'Mobile : option pour cacher le nom du site et ne garder que le logo.' ),
			array( 'update', 'Reprise des réglages de Léger : automatique à l’activation, et bouton dans Apparence → Export / import. Les anciens exports restent importables.' ),
			array( 'patch', 'Mobile : tailles du logo et de la seconde image de l’en-tête mieux adaptées.' ),
		),
		'1.0.17' => array(
			array( 'upgrade', 'Paragraphe : liste de paragraphes titrés (numérotation au choix), pour les textes longs ; une ligne qui commence par « - » devient une puce.' ),
			array( 'upgrade', 'Pages légales créées avec la section Paragraphe : elles se modifient dans Personnaliser, pas dans l’éditeur WordPress.' ),
			array( 'update', 'Personnaliser : les pages en brouillon apparaissent aussi dans « Sections des pages ».' ),
			array( 'fix', 'Brouillons disponibles : un modèle est proposé tant qu’aucune page n’a exactement le même titre ou la même adresse (la page « Privacy Policy » de WordPress ne le bloque plus) ; le brouillon créé n’est plus relié automatiquement à un emplacement.' ),
		),
		'1.0.16' => array(
			array( 'update', 'Équipe : téléphone et e-mail pour chaque personne.' ),
			array( 'patch', 'Équipe : plus d’espace en hauteur entre les membres.' ),
			array( 'patch', 'Texte + éléments : légendes centrées sous chaque image.' ),
			array( 'fix', 'Équipe et Liste d’articles : l’alignement du titre, du sous-titre et du paragraphe s’applique bien.' ),
		),
		'1.0.15' => array(
			array( 'upgrade', 'Nouvelle section : Texte + éléments (la disposition d’« Image + texte » avec une grille de 4 images, chacune avec sa légende).' ),
		),
		'1.0.14' => array(
			array( 'upgrade', 'Variante de bouton (plein, contour, texte uniquement) au choix, bouton par bouton.' ),
			array( 'upgrade', 'Couleur de l’en-tête et du pied de page, dans leurs menus de réglages.' ),
			array( 'update', 'Menu : petite flèche à côté des liens qui ont des sous-éléments.' ),
			array( 'update', 'Historique des versions : pastille indiquant le type de chaque modification.' ),
			array( 'update', 'Dégradé : une opacité propre à chaque couleur.' ),
			array( 'update', 'Cartes : bordure avec couleur et côtés au choix (haut, droite, bas, gauche) ; le liséré par défaut est supprimé.' ),
		),
		'1.0.13' => array(
			array( 'upgrade', 'Nouvelles sections : Paragraphe (texte seul bien présenté) et Téléchargement (documents, avec aperçu des PDF).' ),
			array( 'upgrade', 'Dégradé de couleur par-dessus l’image de fond, dans toutes les sections.' ),
			array( 'upgrade', 'Alignement du titre, du sous-titre et du paragraphe réglable section par section.' ),
			array( 'upgrade', 'Appel à l’action : quatre mises en page (centrée, sur une ligne, encadré, bandeau).' ),
			array( 'upgrade', 'Historique des versions dans « À propos ».' ),
			array( 'update', 'Sous-titre dans Image Head et Appel à l’action ; titre, sous-titre et paragraphe dans Composant ; paragraphe dans Plan du site.' ),
			array( 'update', 'Image + texte : ombre de l’image.' ),
			array( 'update', 'Cartes : densité normale ou aérée, couleur de l’icône, points de liste avec icône et couleur propres à chaque point.' ),
			array( 'update', 'Coordonnées : couleur des icônes.' ),
			array( 'update', 'Pied de page : lien « Plan du site » parmi les pages légales.' ),
			array( 'patch', 'Coordonnées : horaires plus aérés.' ),
			array( 'fix', 'Espace avant le bouton de fin de section : plus large et lié à la densité du site.' ),
		),
		'1.0.12' => array(
			array( 'upgrade', 'Export / import du site (Apparence → Export / import) : pages, articles, médias, menus et réglages, avec reconnexion des images et des pages.' ),
		),
		'1.0.11' => array(
			array( 'upgrade', 'En-tête « Deux images » : seconde image à gauche, logo et titre au centre, menu à droite.' ),
		),
		'1.0.10' => array(
			array( 'upgrade', 'Nouvelles sections : Compteurs (animation et couleur par compteur) et Vidéo (YouTube, Vimeo ou fichier).' ),
		),
		'1.0.9'  => array(
			array( 'update', 'Les écarts entre titre, sous-titre, description et contenu des sections suivent la densité du site.' ),
		),
		'1.0.8'  => array(
			array( 'update', 'Bandeau défilant : arrondi des images, images rondes et léger zoom au survol des images avec lien.' ),
		),
		'1.0.7'  => array(
			array( 'upgrade', 'Nouvelle section : Bandeau défilant.' ),
			array( 'upgrade', 'Styles de menu : classique, appel à l’action, boutons (Réglages du thème → En-tête).' ),
			array( 'update', 'Image Head : second bouton.' ),
			array( 'update', 'Style des cartes : ombre prononcée.' ),
			array( 'update', 'Cartes mises en avant : bordure et taille augmentée, au choix et cumulables.' ),
			array( 'fix', 'Nombre de colonnes des cartes : les choix 2, 4 et 5 colonnes fonctionnent.' ),
		),
		'1.0.6'  => array(
			array( 'update', 'Liste : image à gauche, à droite ou en fond de carte.' ),
			array( 'fix', 'Mise en avant : la bordure passe par-dessus l’image.' ),
		),
		'1.0.5'  => array(
			array( 'fix', 'Liste : l’image s’adapte à la hauteur de la carte.' ),
		),
		'1.0.4'  => array(
			array( 'upgrade', 'Nouvelle section : Liste (les cartes, une par ligne).' ),
		),
		'1.0.3'  => array(
			array( 'update', 'Cartes : réglages en quatre groupes (en-tête, contenu, pied, style), alignements, image en fond avec couleur par-dessus.' ),
			array( 'update', 'Coordonnées : horaires et informations en deux colonnes.' ),
			array( 'update', 'Section Tarifs supprimée (utiliser Cartes avec un prix).' ),
			array( 'patch', 'Numéro de version affiché dans « À propos ».' ),
		),
	);
}
