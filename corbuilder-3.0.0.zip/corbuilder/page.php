<?php get_header(); ?>
<?php
while ( have_posts() ) :
	the_post();
	$pid      = get_the_ID();
	$sections = corbuilder_get_page_sections( $pid );

	if ( ! $sections ) : ?>
		<div class="wrap content-area">
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
				</div>
			</article>
		</div>
	<?php else :
		// Sans section portant le H1, le titre de la page reste présent pour l'accessibilité et le SEO.
		if ( ! corbuilder_sections_have_h1( $sections ) ) {
			echo '<h1 class="screen-reader-text">' . esc_html( get_the_title() ) . '</h1>';
		}
		$has_content = '' !== trim( get_the_content() );
		corbuilder_render_sections( $pid, $has_content ? 'page' : 'footer' );
		if ( $has_content ) : ?>
			<div class="wrap content-area">
				<div class="entry-content"><?php the_content(); ?></div>
			</div>
		<?php endif;
	endif;
endwhile;
?>
<?php get_footer(); ?>
