<?php
/**
 * Section « En-tête de l'article » : titre (H1), informations et image à la une.
 * Réservée au modèle des articles : elle lit l'article en cours.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'En-tête de l’article', 'corbuilder' ),
	'description' => __( 'Titre de l’article (H1), extrait, informations et image à la une, en six dispositions. En mode « bandeau », sans couleur choisie, un voile noir à 45 % rend le titre lisible ; sans image à la une, le bandeau prend la couleur principale.', 'corbuilder' ),
	'order'       => 1,
	'contexts'    => array( 'post' ),
	'unique'      => true,
	'end_button'  => false,
	'h1'          => true,
	'animate'     => false,
	'fields'      => array(
		'layout'          => array(
			'type'    => 'choice',
			'label'   => __( 'Disposition', 'corbuilder' ),
			'choices' => function () {
				$p = function ( $file ) {
					return corbuilder_path_to_url( __DIR__ . '/layout-' . $file . '.svg' );
				};
				return array(
					'simple'    => array( 'label' => __( 'Titre, puis image', 'corbuilder' ), 'preview' => $p( 'simple' ) ),
					'above'     => array( 'label' => __( 'Image, puis titre', 'corbuilder' ), 'preview' => $p( 'above' ) ),
					'side'      => array( 'label' => __( 'Texte à gauche, image à droite', 'corbuilder' ), 'preview' => $p( 'side' ) ),
					'side_left' => array( 'label' => __( 'Image à gauche, texte à droite', 'corbuilder' ), 'preview' => $p( 'side-left' ) ),
					'banner'    => array( 'label' => __( 'Bandeau : image en fond', 'corbuilder' ), 'preview' => $p( 'banner' ) ),
					'title'     => array( 'label' => __( 'Titre seul', 'corbuilder' ), 'preview' => $p( 'title' ) ),
				);
			},
		),
		'image_shadow'    => array(
			'type'    => 'select',
			'label'   => __( 'Ombre sous l’image', 'corbuilder' ),
			'choices' => array(
				'none'   => __( 'Aucune', 'corbuilder' ),
				'soft'   => __( 'Normale', 'corbuilder' ),
				'strong' => __( 'Beaucoup', 'corbuilder' ),
			),
			'default' => 'none',
			'show_if' => array( 'layout', array( 'simple', 'above', 'side', 'side_left' ) ), // pas d'ombre pour le bandeau (image en fond) ni sans image
		),
		'show_excerpt'    => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’extrait (le résumé saisi dans l’article)', 'corbuilder' ) ),
		'show_date'       => array( 'type' => 'checkbox', 'label' => __( 'Afficher la date', 'corbuilder' ), 'default' => true ),
		'show_author'     => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’auteur', 'corbuilder' ) ),
		'show_categories' => array( 'type' => 'checkbox', 'label' => __( 'Afficher les catégories', 'corbuilder' ) ),
		'show_tags'       => array( 'type' => 'checkbox', 'label' => __( 'Afficher les étiquettes', 'corbuilder' ) ),
	),
	// Mode bandeau : l'image à la une devient l'image de fond de la section.
	'prepare'     => function ( $d, $ctx ) {
		if ( 'banner' !== $d['layout'] ) {
			return $d;
		}
		if ( ! $d['bg_image'] ) {
			$d['bg_image'] = (int) get_post_thumbnail_id( $ctx->pid );
		}
		if ( 'none' === $d['bg_color'] ) {
			$d['bg_color']   = $d['bg_image'] ? 'black' : 'primary';
			$d['bg_opacity'] = $d['bg_image'] ? 45 : 100;
		}
		return $d;
	},
	'render'      => function ( $d, $ctx ) {
		$pid = $ctx->pid;
		$tag = $ctx->h1 ? 'h2' : 'h1'; // un seul H1 par page
		$ctx->h1 = true;

		$bits = array();
		if ( $d['show_date'] ) {
			$bits[] = '<time datetime="' . esc_attr( get_the_date( 'c', $pid ) ) . '">' . esc_html( get_the_date( '', $pid ) ) . '</time>';
		}
		if ( $d['show_author'] ) {
			$bits[] = esc_html( get_the_author_meta( 'display_name', get_post_field( 'post_author', $pid ) ) );
		}
		if ( $d['show_categories'] ) {
			$cats = get_the_category_list( ', ', '', $pid );
			if ( $cats ) {
				$bits[] = $cats;
			}
		}
		if ( $d['show_tags'] ) {
			$tags = get_the_tag_list( '', ', ', '', $pid );
			if ( is_string( $tags ) && '' !== $tags ) {
				$bits[] = $tags;
			}
		}

		$layout   = $d['layout'];
		$side     = in_array( $layout, array( 'side', 'side_left' ), true );
		$has_img  = has_post_thumbnail( $pid );
		$show_img = $has_img && in_array( $layout, array( 'simple', 'above', 'side', 'side_left' ), true );

		$head = '<' . $tag . ' class="post-header__title">' . esc_html( get_the_title( $pid ) ) . '</' . $tag . '>';
		if ( $d['show_excerpt'] ) {
			$excerpt = trim( (string) get_post_field( 'post_excerpt', $pid ) ); // seulement l'extrait saisi à la main : pas de résumé généré
			if ( '' !== $excerpt ) {
				$head .= '<p class="post-header__excerpt">' . nl2br( esc_html( $excerpt ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- échappé ci-dessus
			}
		}
		if ( $bits ) {
			$head .= '<p class="post-meta"><span class="post-meta__item">' . implode( '</span><span class="post-meta__item">', $bits ) . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- éléments échappés ci-dessus
		}

		$image = '';
		if ( $show_img ) {
			$shadow = in_array( $d['image_shadow'], array( 'soft', 'strong' ), true ) ? ' post-header__image--shadow-' . $d['image_shadow'] : '';
			$image  = '<div class="post-header__image' . $shadow . '">' . get_the_post_thumbnail( $pid, 'large' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}

		$class = 'post-header post-header--' . str_replace( '_', '-', $layout );
		if ( $side && ! $show_img ) {
			$class .= ' post-header--noimg';
		}

		echo '<header class="' . esc_attr( $class ) . '">';
		if ( $side ) {
			$text = '<div class="post-header__text">' . $head . '</div>';
			echo 'side_left' === $layout ? $image . $text : $text . $image; // phpcs:ignore WordPress.Security.EscapeOutput
		} elseif ( 'above' === $layout ) {
			echo $image . $head; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo $head . $image; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</header>';
	},
);
