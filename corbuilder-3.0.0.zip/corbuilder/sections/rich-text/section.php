<?php
/**
 * Section « Texte de l'article » : un texte mis en forme (HTML : titres, listes, images, citations, vidéos…), tel qu'il était écrit dans
 * l'éditeur WordPress. Réservée au corps des articles composés par sections : un article écrit avant le passage à l'éditeur par sections
 * y arrive tout seul, avec son texte.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Texte de l’article', 'corbuilder' ),
	'description' => __( 'Un texte mis en forme (HTML : titres, listes, images, citations, vidéos, blocs…), tel qu’il a été écrit dans l’éditeur WordPress. Les articles écrits avant le passage à l’éditeur par sections arrivent ici, avec leur texte.', 'corbuilder' ),
	'order'       => 16,
	'contexts'    => array( 'body' ),
	'head_align'  => false,
	'end_button'  => false,
	'fields'      => array(
		'html'  => array( 'type' => 'richtext', 'label' => __( 'Texte (HTML)', 'corbuilder' ) ),
		'width' => array(
			'type'    => 'select',
			'label'   => __( 'Largeur du texte', 'corbuilder' ),
			'choices' => array(
				'narrow' => __( 'Étroite (confort de lecture)', 'corbuilder' ),
				'medium' => __( 'Moyenne', 'corbuilder' ),
				'wide'   => __( 'Large', 'corbuilder' ),
			),
			'default' => 'medium',
		),
	),
	'skip'        => function ( $d ) {
		return '' === trim( (string) $d['html'] );
	},
	'render'      => function ( $d ) {
		// Même rendu que le texte de l'éditeur WordPress : blocs, shortcodes, vidéos intégrées et mise en paragraphes
		echo '<div class="post-content post-content--' . esc_attr( $d['width'] ) . ' entry-content">' . apply_filters( 'the_content', (string) $d['html'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- rendu natif de WordPress
	},
);
