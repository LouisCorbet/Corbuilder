<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * COORDONNÉES : adresse, téléphone, e-mail, horaires, réseaux sociaux, carte.
 * Saisies une seule fois (Personnaliser → Coordonnées), utilisées par la section
 * « Coordonnées » et par le pied de page.
 * ========================================================================= */

function corbuilder_contact_value( $key ) {
	return trim( (string) get_theme_mod( $key, '' ) );
}

/* Numéro prêt pour un lien tel: (chiffres et +) */
function corbuilder_tel_href( $phone ) {
	$number = preg_replace( '/[^\d+]/', '', (string) $phone );
	return '' === $number ? '' : 'tel:' . $number;
}

function corbuilder_day_labels() {
	return array(
		__( 'Lundi', 'corbuilder' ),
		__( 'Mardi', 'corbuilder' ),
		__( 'Mercredi', 'corbuilder' ),
		__( 'Jeudi', 'corbuilder' ),
		__( 'Vendredi', 'corbuilder' ),
		__( 'Samedi', 'corbuilder' ),
		__( 'Dimanche', 'corbuilder' ),
	);
}

/* Horaires : 7 textes (lundi à dimanche) ; un jour vide = fermé */
function corbuilder_hours() {
	$out = array();
	for ( $i = 1; $i <= 7; $i++ ) {
		$out[] = corbuilder_contact_value( 'hours_' . $i );
	}
	return $out;
}

function corbuilder_hours_html() {
	$hours = corbuilder_hours();
	if ( ! array_filter( $hours ) ) { // aucun horaire saisi : rien à afficher
		return '';
	}
	$html = '<dl class="hours">';
	foreach ( corbuilder_day_labels() as $i => $day ) {
		$value = $hours[ $i ];
		$html .= '<div class="hours__row' . ( '' === $value ? ' is-closed' : '' ) . '"><dt>' . esc_html( $day ) . '</dt><dd>'
			. ( '' === $value ? esc_html__( 'Fermé', 'corbuilder' ) : esc_html( $value ) ) . '</dd></div>';
	}
	return $html . '</dl>';
}

/* ---------- Réseaux sociaux ---------- */
function corbuilder_social_networks() {
	return array(
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'linkedin'  => 'LinkedIn',
		'x'         => 'X',
		'youtube'   => 'YouTube',
		'tiktok'    => 'TikTok',
		'pinterest' => 'Pinterest',
		'whatsapp'  => 'WhatsApp',
	);
}

/* Liens renseignés : slug => URL (http ou https uniquement) */
function corbuilder_social_links() {
	$links = array();
	foreach ( corbuilder_social_networks() as $slug => $label ) {
		$url = esc_url_raw( corbuilder_contact_value( 'social_' . $slug ), array( 'http', 'https' ) );
		if ( '' !== $url ) {
			$links[ $slug ] = $url;
		}
	}
	return $links;
}

/* Logo d'un réseau (dossier icons/social), nettoyé : couleur du texte, taille en em */
function corbuilder_social_icon_svg( $slug ) {
	static $cache = array();
	if ( isset( $cache[ $slug ] ) ) {
		return $cache[ $slug ];
	}
	$file = '';
	foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $dir ) {
		if ( preg_match( '/^[a-z0-9-]+$/', $slug ) && is_readable( $dir . '/icons/social/' . $slug . '.svg' ) ) {
			$file = $dir . '/icons/social/' . $slug . '.svg';
			break;
		}
	}
	if ( '' === $file ) {
		return '';
	}
	$svg = (string) file_get_contents( $file );
	$svg = preg_replace( '/<!--.*?-->|<title>.*?<\/title>/s', '', $svg );
	$svg = preg_replace_callback( '/<svg\b[^>]*>/s', function ( $m ) {
		$tag = preg_replace( '/\s(width|height|class|role|fill)="[^"]*"/', '', $m[0] );
		return preg_replace( '/<svg/', '<svg class="social__icon" aria-hidden="true" focusable="false" fill="currentColor"', $tag, 1 );
	}, $svg, 1 );
	$svg = trim( preg_replace( '/\s+/', ' ', $svg ) );
	$svg = str_replace( '> <', '><', preg_replace( '/\s+>/', '>', $svg ) );
	return $cache[ $slug ] = ( false !== strpos( $svg, '<svg' ) ) ? $svg : '';
}

function corbuilder_social_html( $class = '' ) {
	$links = corbuilder_social_links();
	if ( ! $links ) {
		return '';
	}
	$labels = corbuilder_social_networks();
	$html   = '<ul class="social' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '">';
	foreach ( $links as $slug => $url ) {
		$html .= '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( $labels[ $slug ] ) . '">' . corbuilder_social_icon_svg( $slug ) . '</a></li>';
	}
	return $html . '</ul>';
}

/* ---------- Carte : chargée seulement après un clic (aucune requête avant) ---------- */
function corbuilder_map_hosts() {
	return apply_filters( 'corbuilder_map_hosts', array( 'www.google.com', 'maps.google.com', 'www.openstreetmap.org', 'umap.openstreetmap.fr' ) );
}

/* Adresse d'intégration (https, sites de cartes connus) ou chaîne vide */
function corbuilder_sanitize_map_url( $url ) {
	$url  = esc_url_raw( trim( (string) $url ), array( 'https' ) );
	$host = $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
	return ( $host && in_array( strtolower( $host ), corbuilder_map_hosts(), true ) ) ? $url : '';
}

/* Faux plan (SVG léger, sans aucune image ni requête) affiché derrière le bouton, pour que la zone ressemble déjà à une carte */
function corbuilder_fake_map_svg() {
	$roads_main  = 'M-20 150H820M-20 262H820M258 -20V420M536 -20V420M-20 392L820 36';
	$roads_small = 'M-20 70H820M-20 206H820M-20 322H820M120 -20V420M392 -20V420M668 -20V420M-20 250L300 420M520 -20L820 160';
	$blocks      = array(
		array( 128, 78, 120, 62 ), array( 266, 78, 120, 62 ), array( 400, 78, 128, 62 ), array( 544, 78, 116, 62 ), array( 676, 78, 100, 62 ),
		array( 128, 158, 120, 40 ), array( 266, 158, 120, 40 ), array( 400, 158, 128, 40 ), array( 544, 158, 116, 40 ), array( 676, 158, 100, 40 ),
		array( 128, 214, 120, 40 ), array( 266, 214, 120, 40 ), array( 544, 214, 116, 40 ), array( 676, 214, 100, 40 ),
		array( 28, 214, 84, 40 ), array( 28, 158, 84, 40 ), array( 28, 78, 84, 62 ),
	);
	$svg  = '<svg class="map__fake" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">';
	$svg .= '<rect width="800" height="400" fill="#eef1ee"/>';
	foreach ( $blocks as $b ) {
		$svg .= '<rect x="' . $b[0] . '" y="' . $b[1] . '" width="' . $b[2] . '" height="' . $b[3] . '" rx="4" fill="#e3e8e4"/>';
	}
	$svg .= '<rect x="560" y="272" width="190" height="96" rx="16" fill="#d8ebd3"/><rect x="40" y="272" width="160" height="90" rx="16" fill="#d8ebd3"/>';
	$svg .= '<path d="M-20 352C140 300 250 392 420 346S690 290 820 330" fill="none" stroke="#cde2f2" stroke-width="40" stroke-linecap="round"/>';
	$svg .= '<path d="' . $roads_small . '" fill="none" stroke="#d9dedb" stroke-width="9"/><path d="' . $roads_small . '" fill="none" stroke="#fff" stroke-width="6"/>';
	$svg .= '<path d="' . $roads_main . '" fill="none" stroke="#e1d3a3" stroke-width="20"/><path d="' . $roads_main . '" fill="none" stroke="#fbeab6" stroke-width="15"/>';
	$svg .= '<ellipse cx="400" cy="176" rx="17" ry="5" fill="rgba(0,0,0,.2)"/>';
	$svg .= '<path d="M400 176c-24-32-40-50-40-74a40 40 0 1 1 80 0c0 24-16 42-40 74z" fill="var(--c-primary,#2563eb)"/><circle cx="400" cy="102" r="14" fill="#fff"/>';
	return $svg . '</svg>';
}

function corbuilder_map_html( $shadow = '' ) {
	$url = corbuilder_sanitize_map_url( corbuilder_contact_value( 'contact_map_url' ) );
	if ( '' === $url ) {
		return '';
	}
	// Le script du clic est un fichier à part : il ne dépend plus du nombre d'appels à cette fonction
	wp_enqueue_script( 'corbuilder-map', get_template_directory_uri() . '/assets/map.js', array(), CORBUILDER_VERSION, true );
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$class = in_array( $shadow, array( 'soft', 'strong' ), true ) ? ' map--shadow-' . $shadow : '';
	return '<div class="map' . $class . '" data-src="' . esc_url( $url ) . '" data-title="' . esc_attr__( 'Carte', 'corbuilder' ) . '"><div class="map__placeholder">'
		. corbuilder_fake_map_svg() // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fixe écrit dans le thème
		. '<div class="map__consent">'
		/* translators: %s : nom du site de cartes */
		. '<p>' . esc_html( sprintf( __( 'La carte est fournie par %s. En l’affichant, votre adresse IP lui est transmise.', 'corbuilder' ), $host ) ) . '</p>'
		. '<button type="button" class="btn map__load">' . esc_html__( 'Afficher la carte', 'corbuilder' ) . '</button></div></div></div>';
}

/* ---------- Section « Coordonnées » ---------- */
function corbuilder_contact_item_html( $icon, $title, $inner ) {
	return '<div class="contact-item"><span class="contact-item__icon">' . corbuilder_icon_svg( $icon, 'contact-item__svg' ) . '</span><div class="contact-item__body"><h3 class="contact-item__title">' . esc_html( $title ) . '</h3>' . $inner . '</div></div>';
}

/* Contenu de la section selon les cases cochées ; vide si rien n'est renseigné */
function corbuilder_contact_info_html( $d ) {
	$items   = '';
	$address = corbuilder_contact_value( 'contact_address' );
	$phone   = corbuilder_contact_value( 'contact_phone' );
	$email   = corbuilder_contact_value( 'contact_email' );

	if ( ! empty( $d['show_address'] ) && '' !== $address ) {
		$route  = 'https://www.openstreetmap.org/search?query=' . rawurlencode( preg_replace( '/\s*\R\s*/', ', ', $address ) );
		$items .= corbuilder_contact_item_html( 'map-pin', __( 'Adresse', 'corbuilder' ),
			'<p>' . nl2br( esc_html( $address ) ) . '</p><a class="contact-item__link" href="' . esc_url( $route ) . '" target="_blank" rel="noopener">' . esc_html__( 'Voir l’itinéraire', 'corbuilder' ) . '</a>' );
	}
	if ( ! empty( $d['show_phone'] ) && '' !== corbuilder_tel_href( $phone ) ) {
		$items .= corbuilder_contact_item_html( 'phone', __( 'Téléphone', 'corbuilder' ), '<p><a href="' . esc_url( corbuilder_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a></p>' );
	}
	if ( ! empty( $d['show_email'] ) && is_email( $email ) ) {
		$items .= corbuilder_contact_item_html( 'mail', __( 'E-mail', 'corbuilder' ), '<p><a href="mailto:' . esc_attr( antispambot( $email, 1 ) ) . '">' . antispambot( esc_html( $email ) ) . '</a></p>' );
	}
	$hours  = ( ! empty( $d['show_hours'] ) && '' !== corbuilder_hours_html() ) ? corbuilder_contact_item_html( 'clock', __( 'Horaires', 'corbuilder' ), corbuilder_hours_html() ) : '';
	$social = ( ! empty( $d['show_social'] ) && '' !== corbuilder_social_html() ) ? corbuilder_social_html( 'social--section' ) : '';

	if ( '' !== $hours && ( '' !== $items || '' !== $social ) ) {
		// Deux colonnes : les horaires d'un côté, le reste (adresse, téléphone, e-mail, réseaux sociaux) de l'autre
		$rest  = '' === $items ? '' : '<div class="contact-grid">' . $items . '</div>';
		$rest .= '' === $social ? '' : '<div class="contact-social">' . $social . '</div>';
		$html  = '<div class="contact-cols anim"><div class="contact-col contact-col--hours"><div class="contact-grid">' . $hours . '</div></div>'
			. '<div class="contact-col contact-col--info">' . $rest . '</div></div>';
	} else { // une seule colonne : mise en page habituelle
		$items .= $hours;
		$html   = '' === $items ? '' : '<div class="contact-grid anim">' . $items . '</div>';
		if ( '' !== $social ) {
			$html .= '<div class="contact-social anim">' . $social . '</div>';
		}
	}
	$map = ! empty( $d['show_map'] ) ? corbuilder_map_html( isset( $d['map_shadow'] ) ? $d['map_shadow'] : '' ) : '';
	if ( '' === $map ) {
		return $html;
	}
	if ( isset( $d['layout'] ) && 'cols' === $d['layout'] && '' !== $html ) {
		// Deux colonnes : les informations à gauche, la carte à droite
		return '<div class="contact-split"><div class="contact-split__info">' . $html . '</div><div class="contact-split__map anim">' . $map . '</div></div>';
	}
	// Deux lignes : les informations, puis la carte en dessous
	return $html . '<div class="contact-map anim">' . $map . '</div>';
}

/* ---------- Pied de page ---------- */
function corbuilder_footer_contact_html() {
	if ( ! corbuilder_mod( 'footer_show_contact' ) ) {
		return '';
	}
	$lines   = '';
	$address = corbuilder_contact_value( 'contact_address' );
	$phone   = corbuilder_contact_value( 'contact_phone' );
	$email   = corbuilder_contact_value( 'contact_email' );
	if ( '' !== $address ) {
		$lines .= '<li>' . nl2br( esc_html( $address ) ) . '</li>';
	}
	if ( '' !== corbuilder_tel_href( $phone ) ) {
		$lines .= '<li><a href="' . esc_url( corbuilder_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a></li>';
	}
	if ( is_email( $email ) ) {
		$lines .= '<li><a href="mailto:' . esc_attr( antispambot( $email, 1 ) ) . '">' . antispambot( esc_html( $email ) ) . '</a></li>';
	}
	return '' === $lines ? '' : '<ul class="footer-contact">' . $lines . '</ul>';
}

function corbuilder_footer_social_html() {
	return corbuilder_mod( 'footer_show_social' ) ? corbuilder_social_html( 'social--footer' ) : '';
}
