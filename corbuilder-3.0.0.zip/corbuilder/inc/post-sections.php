<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * ARTICLES COMPOSÉS PAR SECTIONS
 * Réglage réservé à l'administrateur (Réglages du thème → Articles → « Éditeur des articles ») :
 *  - « wordpress » : le texte des articles s'écrit dans l'éditeur WordPress (comportement habituel) ;
 *  - « sections »  : le corps de chaque article est une liste de sections, composée dans Personnaliser. Le modèle des articles reste le
 *    cadre commun (en-tête, boutons, navigation, commentaires) et sa section « Contenu de l'article » est l'emplacement du corps.
 * Les sections d'un article sont rangées dans son champ personnalisé _corbuilder_sections. À chaque enregistrement, un texte brut en est
 * tiré et écrit dans le contenu de l'article WordPress (recherche, flux RSS, extraits, référencement, retour à l'éditeur WordPress).
 * ========================================================================= */

define( 'CORBUILDER_BODY_META', '_corbuilder_sections' );

function corbuilder_posts_use_sections() {
	return 'sections' === corbuilder_mod( 'post_editor_mode' );
}

/* ---------- Lecture ---------- */

/* Article jamais composé par sections : son texte WordPress est repris tel quel dans une section « Texte de l'article » */
function corbuilder_legacy_body_json( $pid ) {
	$post = get_post( (int) $pid );
	$html = $post ? (string) $post->post_content : '';
	if ( '' === trim( $html ) ) {
		return '[]';
	}
	return wp_json_encode( array( array( 'id' => 'texte', 'type' => 'rich-text', 'data' => array( 'html' => $html ) ) ) );
}

/* JSON enregistré des sections d'un article (sans tenir compte de l'aperçu) */
function corbuilder_post_body_json( $pid ) {
	$raw = get_post_meta( (int) $pid, CORBUILDER_BODY_META, true );
	if ( is_string( $raw ) && '' !== $raw ) {
		return corbuilder_migrate_sections_json( $raw );
	}
	return corbuilder_legacy_body_json( $pid );
}

/* Sections du corps d'un article, avec l'aperçu du Customizer quand il y en a un */
function corbuilder_get_post_body_sections( $pid ) {
	$pid  = (int) $pid;
	$json = null;
	if ( is_customize_preview() ) {
		global $wp_customize;
		$setting = $wp_customize ? $wp_customize->get_setting( 'corbuilder_post_' . $pid . '_sections' ) : null;
		if ( $setting ) {
			$json = (string) $setting->value();
		}
	}
	if ( null === $json ) {
		$json = corbuilder_post_body_json( $pid );
	}
	return corbuilder_filter_section_items( json_decode( $json, true ), 'body' );
}

/* ---------- Enregistrement ---------- */

/* Restriction de l'éditeur de contenu sur le corps d'un article : il peut ajouter, supprimer et déplacer des sections (sinon il ne pourrait
   pas écrire un article) mais ne règle que le contenu : textes, images, liens (et l'image de fond si l'administrateur l'autorise).
   Pas de style, de couleur ni de nouveau bouton. */
function corbuilder_restrict_body_sections( $new, $old, $extra = array() ) {
	$registry  = corbuilder_get_sections();
	$old_by_id = array();
	foreach ( (array) $old as $section ) {
		if ( is_array( $section ) && isset( $section['id'] ) && is_scalar( $section['id'] ) ) {
			$old_by_id[ (string) $section['id'] ] = $section;
		}
	}
	$out = array();
	foreach ( (array) $new as $sent ) {
		if ( ! is_array( $sent ) || empty( $sent['type'] ) || ! is_string( $sent['type'] ) ) {
			continue;
		}
		$type = sanitize_key( $sent['type'] );
		if ( ! isset( $registry[ $type ] ) ) {
			continue;
		}
		$id        = ( isset( $sent['id'] ) && is_scalar( $sent['id'] ) ) ? (string) $sent['id'] : '';
		$sent_data = ( isset( $sent['data'] ) && is_array( $sent['data'] ) ) ? $sent['data'] : array();
		$base      = ( isset( $old_by_id[ $id ]['type'] ) && $old_by_id[ $id ]['type'] === $type ) ? $old_by_id[ $id ] : array( 'id' => $id, 'type' => $type, 'data' => array() );
		$base['data'] = corbuilder_merge_editable(
			$registry[ $type ]['fields'],
			( isset( $base['data'] ) && is_array( $base['data'] ) ) ? $base['data'] : array(),
			$sent_data,
			true
		);
		if ( ! empty( $extra['bg_image'] ) && array_key_exists( 'bg_image', $sent_data ) ) {
			$base['data']['bg_image'] = absint( is_scalar( $sent_data['bg_image'] ) ? $sent_data['bg_image'] : 0 );
		}
		$out[] = $base;
	}
	return $out;
}

/* Fonction de nettoyage du réglage (le Customizer lui transmet aussi l'objet du réglage) */
function corbuilder_sanitize_post_body_sections( $value, $setting = null ) {
	if ( ! current_user_can( 'edit_theme_options' ) ) { // éditeur de contenu
		$pid   = ( $setting && ! empty( $setting->post_id ) ) ? (int) $setting->post_id : 0;
		$old   = json_decode( corbuilder_post_body_json( $pid ), true );
		$new   = json_decode( is_string( $value ) ? $value : '[]', true );
		$value = wp_json_encode( corbuilder_restrict_body_sections(
			is_array( $new ) ? $new : array(),
			is_array( $old ) ? $old : array(),
			array( 'bg_image' => (bool) corbuilder_mod( 'editor_allow_bgimage' ) )
		) );
	}
	return corbuilder_sanitize_sections_for( $value, 'body' );
}

function corbuilder_save_post_body( $pid, $json ) {
	$pid = (int) $pid;
	update_post_meta( $pid, CORBUILDER_BODY_META, wp_slash( $json ) );
	corbuilder_regenerate_post_content( $pid, $json );
	return true;
}

/* ---------- Texte brut tiré des sections ---------- */

/* Parcourt les champs d'une section (ou d'un élément de liste) : titres, textes, liens et images, dans l'ordre */
function corbuilder_fields_to_html( $fields, $data, $in_list = false ) {
	$html = '';
	foreach ( $fields as $key => $def ) {
		if ( ! isset( $data[ $key ] ) ) {
			continue;
		}
		$value = $data[ $key ];
		switch ( $def['type'] ) {
			case 'text':
			case 'multiline':
				$text = trim( is_scalar( $value ) ? (string) $value : '' );
				if ( '' === $text ) {
					break;
				}
				$text = 'multiline' === $def['type'] ? corbuilder_multiline_html( $text ) : esc_html( $text );
				if ( 'title' === $key ) {
					$tag = $in_list ? 'h3' : 'h2';
				} elseif ( 'subtitle' === $key || 'heading' === $key || ( $in_list && 'name' === $key ) ) {
					$tag = 'h3';
				} else {
					$tag = 'p';
				}
				$html .= '<' . $tag . '>' . $text . '</' . $tag . '>' . "\n";
				break;
			case 'textarea':
				if ( '' !== trim( is_scalar( $value ) ? (string) $value : '' ) ) {
					$html .= corbuilder_text( $value ) . "\n";
				}
				break;
			case 'richtext':
				if ( '' !== trim( is_scalar( $value ) ? (string) $value : '' ) ) {
					$html .= (string) $value . "\n";
				}
				break;
			case 'button':
				$btn = is_array( $value ) ? $value : array();
				if ( ! empty( $btn['label'] ) && ! empty( $btn['url'] ) ) {
					$html .= '<p><a href="' . esc_url( $btn['url'] ) . '">' . esc_html( $btn['label'] ) . '</a></p>' . "\n";
				}
				break;
			case 'image':
				$img = corbuilder_image( $value, 'large' );
				if ( $img ) {
					$html .= '<p>' . $img . '</p>' . "\n";
				}
				break;
			case 'gallery':
				foreach ( is_array( $value ) ? $value : array() as $id ) {
					$img = corbuilder_image( $id, 'large' );
					if ( $img ) {
						$html .= '<p>' . $img . '</p>' . "\n";
					}
				}
				break;
			case 'repeater':
				foreach ( is_array( $value ) ? $value : array() as $item ) {
					if ( is_array( $item ) && ! empty( $def['fields'] ) ) {
						$html .= corbuilder_fields_to_html( $def['fields'], $item, true );
					}
				}
				break;
		}
	}
	return $html;
}

/* Texte brut (HTML simple) de toutes les sections d'un article */
function corbuilder_body_text_html( $items ) {
	$registry = corbuilder_get_sections();
	$html     = '';
	foreach ( (array) $items as $item ) {
		if ( ! is_array( $item ) || empty( $item['type'] ) || ! isset( $registry[ $item['type'] ] ) ) {
			continue;
		}
		$def  = $registry[ $item['type'] ];
		$data = corbuilder_section_data( $def, ( isset( $item['data'] ) && is_array( $item['data'] ) ) ? $item['data'] : array() );
		$html .= corbuilder_fields_to_html( $def['fields'], $data );
	}
	return trim( $html );
}

/* Écrit ce texte dans le contenu de l'article WordPress : recherche, flux RSS, extraits, référencement, retour à l'éditeur WordPress */
function corbuilder_regenerate_post_content( $pid, $json ) {
	$items = json_decode( (string) $json, true );
	$post  = get_post( (int) $pid );
	if ( ! is_array( $items ) || ! $post || 'post' !== $post->post_type ) {
		return;
	}
	$html = corbuilder_body_text_html( $items );
	if ( $html === $post->post_content ) {
		return;
	}
	wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => $html ) ) );
}

/* ---------- Réglage dynamique du Customizer ---------- */

/* Un réglage par article, créé seulement quand il est demandé (ouverture depuis « Composer l'article », aperçu, enregistrement) */
function corbuilder_dynamic_post_setting_args( $args, $id ) {
	if ( preg_match( '/^corbuilder_post_(\d+)_sections$/', (string) $id, $m ) && current_user_can( 'edit_post', (int) $m[1] ) ) {
		return array(
			'type'              => 'corbuilder_post_sections',
			'capability'        => 'edit_posts',
			'default'           => '[]',
			'sanitize_callback' => 'corbuilder_sanitize_post_body_sections',
		);
	}
	return $args;
}
add_filter( 'customize_dynamic_setting_args', 'corbuilder_dynamic_post_setting_args', 10, 2 );

function corbuilder_dynamic_post_setting_class( $class, $id, $args ) {
	if ( isset( $args['type'] ) && 'corbuilder_post_sections' === $args['type'] ) {
		require_once get_template_directory() . '/inc/controls.php';
		return 'Corbuilder_Post_Sections_Setting';
	}
	return $class;
}
add_filter( 'customize_dynamic_setting_class', 'corbuilder_dynamic_post_setting_class', 10, 3 );

/* ---------- Écran d'édition de l'article ---------- */

/* Adresse de Personnaliser, ouvert sur les sections de l'article */
function corbuilder_compose_url( $post ) {
	$preview = corbuilder_compose_preview_url( $post );
	return add_query_arg( array(
		'corbuilder_post'    => (int) $post->ID,
		'autofocus[section]' => 'corbuilder_articles',
		'url'                => rawurlencode( $preview ),
		'return'             => rawurlencode( (string) get_edit_post_link( $post->ID, 'raw' ) ),
	), admin_url( 'customize.php' ) );
}

/* Article en cours de composition. Il est connu par le paramètre « corbuilder_post » de l'adresse de Personnaliser ET de celle de l'aperçu
   (WordPress désactive dans le panneau toute section que l'aperçu ne déclare pas : l'aperçu doit donc connaître l'article, lui aussi).
   Si l'aperçu change de page (clic sur un lien), le dernier article ouvert par ce compte sert de secours. */
function corbuilder_compose_post() {
	$id = isset( $_GET['corbuilder_post'] ) ? absint( $_GET['corbuilder_post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- simple ouverture d'un article ; le droit de le modifier est vérifié ci-dessous
	if ( $id ) {
		if ( is_user_logged_in() && (int) get_user_meta( get_current_user_id(), 'corbuilder_composing', true ) !== $id ) {
			update_user_meta( get_current_user_id(), 'corbuilder_composing', $id );
		}
	} elseif ( is_user_logged_in() && ( is_customize_preview() || isset( $_GET['customize_messenger_channel'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$id = (int) get_user_meta( get_current_user_id(), 'corbuilder_composing', true );
	}
	if ( ! $id ) {
		return null;
	}
	$post = get_post( $id );
	return corbuilder_can_compose( $post ) ? $post : null;
}

/* Adresse de l'article dans l'aperçu (avec le paramètre qui le désigne, voir ci-dessus) */
function corbuilder_compose_preview_url( $post ) {
	$url = ( 'publish' === $post->post_status ) ? get_permalink( $post ) : get_preview_post_link( $post );
	return add_query_arg( 'corbuilder_post', (int) $post->ID, $url );
}

function corbuilder_can_compose( $post ) {
	return $post && 'post' === $post->post_type && corbuilder_posts_use_sections() && current_user_can( 'edit_post', $post->ID ) && current_user_can( 'customize' );
}

/* Mode « éditeur par sections » : plus d'éditeur de texte (ni classique, ni blocs) pour les articles */
function corbuilder_hide_post_editor() {
	if ( corbuilder_posts_use_sections() ) {
		remove_post_type_support( 'post', 'editor' );
	}
}
add_action( 'init', 'corbuilder_hide_post_editor', 20 );

/* À la place de l'éditeur de texte : le bouton qui ouvre l'éditeur par sections */
function corbuilder_compose_panel( $post ) {
	if ( ! $post || 'post' !== $post->post_type || ! corbuilder_posts_use_sections() ) {
		return;
	}
	echo '<div class="postbox" style="margin-top:20px"><div class="postbox-header"><h2 class="hndle">' . esc_html__( 'Contenu de l’article', 'corbuilder' ) . '</h2></div><div class="inside">';
	if ( ! corbuilder_can_compose( $post ) ) {
		echo '<p>' . esc_html__( 'Le contenu de cet article se compose par sections dans Personnaliser, avec un compte qui y a accès.', 'corbuilder' ) . '</p>';
	} elseif ( 'auto-draft' === $post->post_status ) {
		echo '<p>' . esc_html__( 'Le contenu de cet article se compose par sections (texte, images, cartes, boutons…). Donne un titre à l’article et enregistre le brouillon : le bouton « Composer l’article » apparaîtra ici.', 'corbuilder' ) . '</p>';
	} else {
		echo '<p>' . esc_html__( 'Le contenu de cet article se compose par sections, avec l’aperçu en direct. Le texte pour la recherche et le référencement en est tiré automatiquement.', 'corbuilder' ) . '</p>';
		if ( '' === (string) get_post_meta( $post->ID, CORBUILDER_BODY_META, true ) && '' !== trim( (string) $post->post_content ) ) {
			echo '<p class="description">' . esc_html__( 'Le texte actuel de l’article sera repris tel quel dans une section « Texte de l’article », que tu pourras ensuite découper en sections.', 'corbuilder' ) . '</p>';
		}
		echo '<p><a class="button button-primary button-hero" href="' . esc_url( corbuilder_compose_url( $post ) ) . '">' . esc_html__( 'Composer l’article', 'corbuilder' ) . '</a></p>';
	}
	echo '</div></div>';
}
add_action( 'edit_form_after_title', 'corbuilder_compose_panel' );

/* Raccourcis : liste des articles et barre d'administration */
function corbuilder_compose_row_action( $actions, $post ) {
	if ( corbuilder_can_compose( $post ) && 'auto-draft' !== $post->post_status ) {
		$actions['corbuilder_compose'] = '<a href="' . esc_url( corbuilder_compose_url( $post ) ) . '">' . esc_html__( 'Composer', 'corbuilder' ) . '</a>';
	}
	return $actions;
}
add_filter( 'post_row_actions', 'corbuilder_compose_row_action', 10, 2 );

function corbuilder_compose_admin_bar( $bar ) {
	if ( is_admin() || ! is_singular( 'post' ) ) {
		return;
	}
	$post = get_queried_object();
	if ( corbuilder_can_compose( $post ) ) {
		$bar->add_node( array( 'id' => 'corbuilder-compose', 'title' => __( 'Composer l’article', 'corbuilder' ), 'href' => corbuilder_compose_url( $post ) ) );
	}
}
add_action( 'admin_bar_menu', 'corbuilder_compose_admin_bar', 81 );
