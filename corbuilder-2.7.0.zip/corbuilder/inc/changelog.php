<?php
defined( 'ABSPATH' ) || exit;

/* Types de modification, avec la pastille affichée devant chaque point de l'historique */
function corbuilder_changelog_types() {
	return array(
		'upgrade' => __( 'Upgrade', 'corbuilder' ), // nouvelle fonctionnalité ou nouvelle section
		'update'  => __( 'Update', 'corbuilder' ),  // amélioration d'une fonctionnalité existante
		'patch'   => __( 'Patch', 'corbuilder' ),   // petit ajustement (réglage, style, détail)
		'fix'     => __( 'Fix', 'corbuilder' ),     // correction d'un défaut
	);
}

/* Historique des versions affiché dans Personnaliser → Réglages du thème → À propos.
   Une entrée par version (la plus récente en premier) ; chaque point : array( type, texte ). */
function corbuilder_changelog() {
	return array(
		'2.7.0'  => array(
			array( 'update', 'Titres et sous-titres des sections modifiables dans une zone de texte : un saut de ligne saisi (touche Entrée) est repris sur le site.' ),
		),
		'2.6.1'  => array(
			array( 'update', 'Ajout de l’image du thème.' ),
		),
		'2.6.0'  => array(
			array( 'upgrade', 'Mises à jour dans WordPress : la plus récente version du fichier versions.json est annoncée dans Apparence → Thèmes et Tableau de bord → Mises à jour, avec le bouton « Mettre à jour maintenant ». L’empreinte SHA-256 et la structure du zip sont vérifiées avant l’installation et les réglages sont sauvegardés (comme dans le menu Versions).' ),
		),
		'2.5.0'  => array(
			array( 'upgrade', 'Nouveau menu Apparence → Versions (administrateurs, invisible pour l’éditeur de contenu) : liste des versions disponibles lue dans un fichier versions.json dont l’adresse se règle dans la page, et installation de n’importe quelle version, qui remplace la version actuelle.' ),
			array( 'update', 'Installation sécurisée : empreinte SHA-256 et structure du zip vérifiées, réglages sauvegardés avant chaque installation (restauration possible dans la page), ancien dossier conservé si l’installation échoue.' ),
		),
		'2.4.0'  => array(
			array( 'upgrade', 'Palette de 5 couleurs (principale, secondaire, accent, fond clair, fond sombre) réglée dans Style → Couleurs : les sections, l’en-tête, le pied de page, les cartes, les compteurs et les icônes n’utilisent plus que ces couleurs, plus le blanc et le noir. Les anciennes couleurs personnalisées sont converties vers la couleur de la palette la plus proche ; « Secondaire clair » devient « Fond clair ».' ),
			array( 'upgrade', 'Nouvelle section : Tableau (6 colonnes au plus, première ligne en en-têtes, défilement ou empilement sur mobile).' ),
			array( 'upgrade', 'Image Head : cinq variantes (classique, texte animé à la suite du titre, texte animé séparé à droite, texte + image, texte encadré).' ),
			array( 'upgrade', 'Nouvel en-tête « Menu centré + bouton » : logo et nom à gauche, menu au milieu, dernier lien du menu en bouton à droite.' ),
			array( 'update', 'Réglages des sections : deux menus, « Identité » (titres, paragraphe, boutons, fond, séparateur… communs à toutes les sections) et « Contenu » (les éléments propres à la section).' ),
			array( 'update', 'Interface simplifiée : « Appel à l’action » et « Boutons » deviennent des styles d’en-tête, et le choix « Style du menu » disparaît (un en-tête Classique avec ce style de menu est converti automatiquement).' ),
			array( 'upgrade', 'Formes de fin de section pour tout le site (Style → Formes de fin de section) : le choix est appliqué à toutes les sections, qui restent modifiables ensuite.' ),
			array( 'update', 'Éditeur de contenu : peut changer l’image de fond des sections (case décochable), les 5 couleurs de la palette et la forme de fin de section globale (cases dans Éditeur de contenu).' ),
			array( 'update', 'Second bouton possible dans Image + texte, Texte + éléments et en fin de section.' ),
			array( 'update', 'Case « Texte contrasté » dans chaque section : ombre sous les titres et sous-titres.' ),
			array( 'update', 'Couleur de fond d’une section : l’opacité n’est réglable (en dessous de 100 %) que s’il y a une image de fond ; sans image, la couleur est pleine.' ),
			array( 'update', 'Flou de l’image de fond des sections (faible, moyen, fort).' ),
			array( 'update', 'Hauteur de l’en-tête réglable (normale, réduite, très réduite).' ),
			array( 'update', 'Coordonnées : un faux plan s’affiche derrière le bouton « Afficher la carte » avant son chargement.' ),
			array( 'update', 'Logo seul : quand le nom du site est caché, il reste dans la page pour les lecteurs d’écran.' ),
			array( 'fix', 'Image + texte et Texte + éléments : la barre sous le titre suit l’alignement du texte.' ),
			array( 'fix', 'Image Head : la hauteur « Compacte » est maintenant plus basse que « Moyenne ».' ),
		),
		'2.3.2'  => array(
			array( 'update', 'Import : quand l’archive n’a pas pu être envoyée, le message donne la vraie cause (limite dépassée, envoi interrompu, dossier temporaire absent ou plein…) au lieu de supposer une taille trop grande.' ),
		),
		'2.3.1'  => array(
			array( 'update', 'Section Coordonnées : ombre de la carte (aucune, légère ou prononcée).' ),
		),
		'2.3.0'  => array(
			array( 'update', 'Section Coordonnées : choix de la disposition, sur 2 lignes (informations puis carte, comme avant) ou sur 2 colonnes (informations à gauche, carte à droite).' ),
			array( 'fix', 'Section Coordonnées : le bouton « Afficher la carte » ne faisait rien ; la carte s’affiche de nouveau au clic.' ),
		),
		'2.2.0'  => array(
			array( 'upgrade', 'Éditeur de contenu : l’administrateur choisit les zones du site qu’il peut modifier (Réglages du thème → Éditeur de contenu) : logo, titre et slogan ; icône du site ; coordonnées (adresse, téléphone, e-mail, horaires, réseaux sociaux) ; barre d’annonce ; texte et titres de colonnes du pied de page.' ),
		),
		'2.1.1'  => array(
			array( 'fix', 'Éditeur de contenu : les boutons qui n’ont pas de texte ne sont plus proposés (il ne peut plus en créer un), et il ne peut plus en supprimer un en vidant son texte.' ),
		),
		'2.1.0'  => array(
			array( 'upgrade', 'Nouveau rôle « Éditeur de contenu » : un compte qui modifie les textes, les images et les liens des pages dans Personnaliser, sans pouvoir changer la structure (sections), le style ni les réglages du site.' ),
			array( 'update', 'Éditeur de contenu : réglage pour lui permettre d’ajouter, de supprimer et de déplacer des éléments dans les listes (cartes, équipe, compteurs…).' ),
		),
		'2.0.0'  => array(
			array( 'upgrade', 'Le thème s’appelle désormais Corbuilder. Il a un nouveau dossier : il s’installe comme un nouveau thème à activer, et reprend automatiquement les réglages, les menus et les sections de toutes les pages de Léger.' ),
			array( 'upgrade', 'En-tête fixe au choix : il se masque quand on descend et réapparaît dès qu’on remonte, même au milieu de la page.' ),
			array( 'update', 'Mobile : une icône à trois lignes remplace le bouton « Menu » (elle devient une croix quand le menu est ouvert).' ),
			array( 'update', 'Mobile : option pour cacher le nom du site et ne garder que le logo.' ),
			array( 'update', 'Reprise des réglages de Léger : automatique à l’activation, et bouton dans Apparence → Export / import. Les anciens exports restent importables.' ),
			array( 'patch', 'Mobile : tailles du logo et de la seconde image de l’en-tête mieux adaptées.' ),
		),
		'1.0.17' => array(
			array( 'upgrade', 'Paragraphe : liste de paragraphes titrés (numérotation au choix), pour les textes longs ; une ligne qui commence par « - » devient une puce.' ),
			array( 'upgrade', 'Pages légales créées avec la section Paragraphe : elles se modifient dans Personnaliser, pas dans l’éditeur WordPress.' ),
			array( 'update', 'Personnaliser : les pages en brouillon apparaissent aussi dans « Sections des pages ».' ),
			array( 'fix', 'Brouillons disponibles : un modèle est proposé tant qu’aucune page n’a exactement le même titre ou la même adresse (la page « Privacy Policy » de WordPress ne le bloque plus) ; le brouillon créé n’est plus relié automatiquement à un emplacement.' ),
		),
		'1.0.16' => array(
			array( 'update', 'Équipe : téléphone et e-mail pour chaque personne.' ),
			array( 'patch', 'Équipe : plus d’espace en hauteur entre les membres.' ),
			array( 'patch', 'Texte + éléments : légendes centrées sous chaque image.' ),
			array( 'fix', 'Équipe et Liste d’articles : l’alignement du titre, du sous-titre et du paragraphe s’applique bien.' ),
		),
		'1.0.15' => array(
			array( 'upgrade', 'Nouvelle section : Texte + éléments (la disposition d’« Image + texte » avec une grille de 4 images, chacune avec sa légende).' ),
		),
		'1.0.14' => array(
			array( 'upgrade', 'Variante de bouton (plein, contour, texte uniquement) au choix, bouton par bouton.' ),
			array( 'upgrade', 'Couleur de l’en-tête et du pied de page, dans leurs menus de réglages.' ),
			array( 'update', 'Menu : petite flèche à côté des liens qui ont des sous-éléments.' ),
			array( 'update', 'Historique des versions : pastille indiquant le type de chaque modification.' ),
			array( 'update', 'Dégradé : une opacité propre à chaque couleur.' ),
			array( 'update', 'Cartes : bordure avec couleur et côtés au choix (haut, droite, bas, gauche) ; le liséré par défaut est supprimé.' ),
		),
		'1.0.13' => array(
			array( 'upgrade', 'Nouvelles sections : Paragraphe (texte seul bien présenté) et Téléchargement (documents, avec aperçu des PDF).' ),
			array( 'upgrade', 'Dégradé de couleur par-dessus l’image de fond, dans toutes les sections.' ),
			array( 'upgrade', 'Alignement du titre, du sous-titre et du paragraphe réglable section par section.' ),
			array( 'upgrade', 'Appel à l’action : quatre mises en page (centrée, sur une ligne, encadré, bandeau).' ),
			array( 'upgrade', 'Historique des versions dans « À propos ».' ),
			array( 'update', 'Sous-titre dans Image Head et Appel à l’action ; titre, sous-titre et paragraphe dans Composant ; paragraphe dans Plan du site.' ),
			array( 'update', 'Image + texte : ombre de l’image.' ),
			array( 'update', 'Cartes : densité normale ou aérée, couleur de l’icône, points de liste avec icône et couleur propres à chaque point.' ),
			array( 'update', 'Coordonnées : couleur des icônes.' ),
			array( 'update', 'Pied de page : lien « Plan du site » parmi les pages légales.' ),
			array( 'patch', 'Coordonnées : horaires plus aérés.' ),
			array( 'fix', 'Espace avant le bouton de fin de section : plus large et lié à la densité du site.' ),
		),
		'1.0.12' => array(
			array( 'upgrade', 'Export / import du site (Apparence → Export / import) : pages, articles, médias, menus et réglages, avec reconnexion des images et des pages.' ),
		),
		'1.0.11' => array(
			array( 'upgrade', 'En-tête « Deux images » : seconde image à gauche, logo et titre au centre, menu à droite.' ),
		),
		'1.0.10' => array(
			array( 'upgrade', 'Nouvelles sections : Compteurs (animation et couleur par compteur) et Vidéo (YouTube, Vimeo ou fichier).' ),
		),
		'1.0.9'  => array(
			array( 'update', 'Les écarts entre titre, sous-titre, description et contenu des sections suivent la densité du site.' ),
		),
		'1.0.8'  => array(
			array( 'update', 'Bandeau défilant : arrondi des images, images rondes et léger zoom au survol des images avec lien.' ),
		),
		'1.0.7'  => array(
			array( 'upgrade', 'Nouvelle section : Bandeau défilant.' ),
			array( 'upgrade', 'Styles de menu : classique, appel à l’action, boutons (Réglages du thème → En-tête).' ),
			array( 'update', 'Image Head : second bouton.' ),
			array( 'update', 'Style des cartes : ombre prononcée.' ),
			array( 'update', 'Cartes mises en avant : bordure et taille augmentée, au choix et cumulables.' ),
			array( 'fix', 'Nombre de colonnes des cartes : les choix 2, 4 et 5 colonnes fonctionnent.' ),
		),
		'1.0.6'  => array(
			array( 'update', 'Liste : image à gauche, à droite ou en fond de carte.' ),
			array( 'fix', 'Mise en avant : la bordure passe par-dessus l’image.' ),
		),
		'1.0.5'  => array(
			array( 'fix', 'Liste : l’image s’adapte à la hauteur de la carte.' ),
		),
		'1.0.4'  => array(
			array( 'upgrade', 'Nouvelle section : Liste (les cartes, une par ligne).' ),
		),
		'1.0.3'  => array(
			array( 'update', 'Cartes : réglages en quatre groupes (en-tête, contenu, pied, style), alignements, image en fond avec couleur par-dessus.' ),
			array( 'update', 'Coordonnées : horaires et informations en deux colonnes.' ),
			array( 'update', 'Section Tarifs supprimée (utiliser Cartes avec un prix).' ),
			array( 'patch', 'Numéro de version affiché dans « À propos ».' ),
		),
	);
}
