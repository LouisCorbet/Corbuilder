<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * SECTIONS : chaque dossier /sections/<id>/ contient section.php (+ preview.*).
 * section.php retourne : label, description, order, h1, wrap, animate, bg,
 *   fields (champs ; 'choices' d'un select peut être une fonction),
 *   render (affichage), skip (rien à afficher ?), classes (classes CSS ajoutées à la section),
 *   end_button (false = pas de « bouton de fin de section »),
 *   contexts (où l'utiliser : 'page', 'post' = modèle des articles), unique (une seule
 *   par liste), prepare (ajuste les données avant l'affichage, ex. image à la une),
 *   requires (plugins : slug => nom).
 * ========================================================================= */

function corbuilder_normalize_fields( $fields ) {
	$out = array();
	foreach ( (array) $fields as $key => $def ) {
		$def = wp_parse_args( (array) $def, array( 'type' => 'text', 'label' => $key ) );
		if ( 'repeater' === $def['type'] ) {
			$def['fields'] = corbuilder_normalize_fields( isset( $def['fields'] ) ? $def['fields'] : array() );
		}
		$out[ sanitize_key( $key ) ] = $def;
	}
	return $out;
}

function corbuilder_get_sections() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$sections = corbuilder_load_modules( 'sections', 'section.php', array( 'render' ), array(
		'h1'      => false,
		'wrap'    => true,
		'animate' => true,
		'skip'    => null,
		'classes' => null,
		'end_button' => true,
		'head_align' => 'center',
		'prepare' => null,
		'unique'  => false,
		'contexts' => array( 'page', 'post' ),
		'bg'      => array(),
		'fields'  => array(),
	) );
	foreach ( $sections as $id => $def ) {
		$fields = corbuilder_normalize_fields( $def['fields'] );
		// Alignement du titre, du sous-titre et du paragraphe : juste après le dernier de ces champs
		if ( false !== $def['head_align'] && ( isset( $fields['title'] ) || isset( $fields['subtitle'] ) || isset( $fields['text'] ) ) ) {
			$after  = isset( $fields['text'] ) ? 'text' : ( isset( $fields['subtitle'] ) ? 'subtitle' : 'title' );
			$fields = corbuilder_fields_insert_after( $fields, $after, corbuilder_normalize_fields( corbuilder_head_align_fields( $def['head_align'] ) ) );
		}
		if ( ! empty( $def['end_button'] ) ) { // « Bouton de fin de section » : dans le menu « Contenu » de chaque section
			$fields = array_merge( $fields, corbuilder_normalize_fields( corbuilder_end_button_fields() ) );
		}
		$sections[ $id ]['fields'] = $fields;
	}
	$sections = apply_filters( 'corbuilder_sections', $sections );
	uasort( $sections, function ( $a, $b ) {
		return $a['order'] <=> $b['order'];
	} );
	$cache = $sections;
	return $cache;
}

/* Insère des champs après le champ $after (à la fin si $after n'existe pas) */
function corbuilder_fields_insert_after( $fields, $after, $new ) {
	$out = array();
	foreach ( $fields as $key => $def ) {
		$out[ $key ] = $def;
		if ( $key === $after ) {
			foreach ( $new as $nk => $nd ) {
				$out[ $nk ] = $nd;
			}
		}
	}
	return array_key_exists( $after, $fields ) ? $out : array_merge( $fields, $new );
}

function corbuilder_head_align_fields( $default = 'center' ) {
	return array(
		'head_align' => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du titre, du sous-titre et du paragraphe', 'corbuilder' ),
			'choices' => array(
				'left'   => __( 'À gauche', 'corbuilder' ),
				'center' => __( 'Centré', 'corbuilder' ),
				'right'  => __( 'À droite', 'corbuilder' ),
			),
			'default' => in_array( $default, array( 'left', 'center', 'right' ), true ) ? $default : 'center',
		),
	);
}

/* Bouton de fin de section : ajouté à la fin du menu « Contenu » de chaque section */
function corbuilder_end_button_fields() {
	return array(
		'end_button'       => array( 'type' => 'button', 'label' => __( 'Bouton de fin de section (facultatif)', 'corbuilder' ) ),
		'end_button2'      => array( 'type' => 'button', 'label' => __( 'Second bouton de fin de section (facultatif)', 'corbuilder' ) ),
		'end_button_align' => array(
			'type'    => 'select',
			'label'   => __( 'Alignement du bouton de fin', 'corbuilder' ),
			'choices' => array(
				'center' => __( 'Centré', 'corbuilder' ),
				'left'   => __( 'À gauche', 'corbuilder' ),
				'right'  => __( 'À droite', 'corbuilder' ),
			),
		),
	);
}

function corbuilder_end_button_html( $data ) {
	$btn  = empty( $data['end_button'] ) ? '' : corbuilder_button( $data['end_button'] );
	$btn .= empty( $data['end_button2'] ) ? '' : corbuilder_button( $data['end_button2'], 'btn--secondary' ); // second bouton : à côté du premier
	if ( '' === $btn ) {
		return '';
	}
	$align = ( isset( $data['end_button_align'] ) && in_array( $data['end_button_align'], array( 'left', 'center', 'right' ), true ) ) ? $data['end_button_align'] : 'center';
	return '<div class="section__end-button section__end-button--' . $align . '">' . $btn . '</div>';
}

/* Formes de fin de section (séparateur en bas) */
function corbuilder_divider_choices() {
	return array(
		'none'     => __( 'Aucun', 'corbuilder' ),
		'wave'     => __( 'Vague', 'corbuilder' ),
		'curve'    => __( 'Courbe', 'corbuilder' ),
		'diagonal' => __( 'Diagonale', 'corbuilder' ),
	);
}

/* Niveaux de flou de l'image de fond : valeur CSS (px) de chaque niveau */
function corbuilder_blur_levels() {
	return array( 'low' => 3, 'medium' => 8, 'strong' => 16 );
}

function corbuilder_blur_choices() {
	return array(
		'none'   => __( 'Aucun', 'corbuilder' ),
		'low'    => __( 'Faible', 'corbuilder' ),
		'medium' => __( 'Moyen', 'corbuilder' ),
		'strong' => __( 'Fort', 'corbuilder' ),
	);
}

/* Champs de fond et de style communs à toutes les sections */
function corbuilder_common_fields( $section = array() ) {
	$bg = wp_parse_args( isset( $section['bg'] ) ? $section['bg'] : array(), array(
		'color'   => 'none',
		'opacity' => 100,
		'tone'    => 'auto',
	) );

	$colors  = corbuilder_palette_choices( true ); // la palette du site (Style → Couleurs), le blanc et le noir : pas de couleur libre
	$colors2 = corbuilder_palette_choices( false );

	return array(
		'bg_mode'    => array(
			'type'    => 'select',
			'label'   => __( 'Type de couleur par-dessus l’image', 'corbuilder' ),
			'choices' => array(
				'solid'    => __( 'Couleur unie', 'corbuilder' ),
				'gradient' => __( 'Dégradé', 'corbuilder' ),
			),
			'default' => 'solid',
		),
		'bg_color'   => array(
			'type'    => 'select',
			'label'   => __( 'Couleur de fond (ou 1re couleur du dégradé)', 'corbuilder' ),
			'choices' => $colors,
			'default' => $bg['color'],
		),
		'bg_color2'  => array(
			'type'    => 'select',
			'label'   => __( '2e couleur du dégradé', 'corbuilder' ),
			'choices' => $colors2,
			'default' => 'primary',
			'show_if' => array( 'bg_mode', 'gradient' ),
		),
		'bg_angle'   => array(
			'type'    => 'select',
			'label'   => __( 'Sens du dégradé', 'corbuilder' ),
			'choices' => array(
				'bottom' => __( 'De haut en bas', 'corbuilder' ),
				'top'    => __( 'De bas en haut', 'corbuilder' ),
				'right'  => __( 'De gauche à droite', 'corbuilder' ),
				'left'   => __( 'De droite à gauche', 'corbuilder' ),
				'diag'   => __( 'En diagonale', 'corbuilder' ),
			),
			'default' => 'bottom',
			'show_if' => array( 'bg_mode', 'gradient' ),
		),
		'bg_opacity' => array(
			'requires_image' => true, // curseur proposé seulement avec une image de fond
			'type'    => 'range',
			'label'   => __( 'Opacité de la couleur (ou de la 1re couleur du dégradé) (%)', 'corbuilder' ),
			'min'     => 0,
			'max'     => 100,
			'step'    => 5,
			'default' => (int) $bg['opacity'],
		),
		'bg_opacity2' => array(
			'requires_image' => true, // curseur proposé seulement avec une image de fond
			'type'    => 'range',
			'label'   => __( 'Opacité de la 2e couleur du dégradé (%)', 'corbuilder' ),
			'min'     => 0,
			'max'     => 100,
			'step'    => 5,
			'default' => (int) $bg['opacity'],
			'show_if' => array( 'bg_mode', 'gradient' ),
		),
		'bg_image'   => array(
			'type'  => 'image',
			'label' => __( 'Image de fond', 'corbuilder' ),
		),
		'bg_blur'    => array(
			'type'    => 'select',
			'label'   => __( 'Flou de l’image de fond', 'corbuilder' ),
			'choices' => corbuilder_blur_choices(),
			'default' => 'none',
		),
		'text_tone'  => array(
			'type'    => 'select',
			'label'   => __( 'Couleur du texte', 'corbuilder' ),
			'choices' => array(
				'auto'  => __( 'Automatique', 'corbuilder' ),
				'light' => __( 'Claire', 'corbuilder' ),
				'dark'  => __( 'Foncée', 'corbuilder' ),
			),
			'default' => $bg['tone'],
		),
		'text_shadow' => array(
			'type'  => 'checkbox',
			'label' => __( 'Texte contrasté (ombre sous les titres et sous-titres)', 'corbuilder' ),
		),
		'spacing'    => array(
			'type'    => 'select',
			'label'   => __( 'Marges haut et bas', 'corbuilder' ),
			'choices' => array(
				'default'  => __( 'Selon le réglage général', 'corbuilder' ),
				'none'     => __( 'Aucune', 'corbuilder' ),
				'compact'  => __( 'Compactes', 'corbuilder' ),
				'standard' => __( 'Standard', 'corbuilder' ),
				'spacious' => __( 'Aérées', 'corbuilder' ),
			),
		),
		'divider'    => array(
			'type'    => 'select',
			'label'   => __( 'Séparateur en bas de section', 'corbuilder' ),
			'choices' => corbuilder_divider_choices(),
		),
		'visibility' => array(
			'type'    => 'select',
			'label'   => __( 'Affichage', 'corbuilder' ),
			'choices' => array(
				'all'          => __( 'Partout', 'corbuilder' ),
				'hide-mobile'  => __( 'Masquer sur mobile', 'corbuilder' ),
				'hide-desktop' => __( 'Masquer sur ordinateur', 'corbuilder' ),
			),
		),
		'anim_off'   => array(
			'type'  => 'checkbox',
			'label' => __( 'Désactiver l’animation de cette section', 'corbuilder' ),
		),
		'anchor'     => array(
			'type'  => 'slug',
			'label' => __( 'Ancre (lien #nom dans un menu)', 'corbuilder' ),
		),
	);
}

/* =========================================================================
 * VALEURS PAR DÉFAUT ET NETTOYAGE (la source de vérité est le schéma PHP)
 * ========================================================================= */

/* Choix d'une liste : tableau, ou fonction évaluée à la demande */
function corbuilder_field_choices( $def ) {
	if ( empty( $def['choices'] ) ) {
		return array();
	}
	return is_callable( $def['choices'] ) ? (array) call_user_func( $def['choices'] ) : (array) $def['choices'];
}

function corbuilder_field_default( $def ) {
	if ( array_key_exists( 'default', $def ) ) {
		return $def['default'];
	}
	switch ( $def['type'] ) {
		case 'image':
		case 'file':
			return 0;
		case 'checkbox':
			return false;
		case 'repeater':
		case 'multiselect':
		case 'gallery':
			return array();
		case 'button':
			return corbuilder_button_default();
		case 'number':
		case 'range':
			return isset( $def['min'] ) ? $def['min'] : 0;
		case 'select':
		case 'choice':
			$keys = array_keys( corbuilder_field_choices( $def ) );
			return $keys ? $keys[0] : '';
		default:
			return '';
	}
}

function corbuilder_field_defaults( $fields ) {
	$out = array();
	foreach ( $fields as $key => $def ) {
		$out[ $key ] = corbuilder_field_default( $def );
	}
	return $out;
}

function corbuilder_sanitize_value( $def, $value ) {
	$default = corbuilder_field_default( $def );

	switch ( $def['type'] ) {
		case 'text':
			return sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );
		case 'multiline': // titre ou sous-titre : texte brut, sauts de ligne conservés
			return sanitize_textarea_field( is_scalar( $value ) ? str_replace( array( "\r\n", "\r" ), "\n", (string) $value ) : '' );
		case 'slug':
			return sanitize_title( is_scalar( $value ) ? (string) $value : '' );
		case 'url':
			return esc_url_raw( is_scalar( $value ) ? (string) $value : '' );
		case 'textarea':
			return corbuilder_sanitize_html( $value );
		case 'image':
		case 'file':
			return absint( is_scalar( $value ) ? $value : 0 );
		case 'checkbox':
			return (bool) $value;
		case 'button':
			return corbuilder_sanitize_button( $value );
		case 'icon':
			return corbuilder_sanitize_icon_slug( $value );
		case 'gallery':
			$ids = array();
			foreach ( is_array( $value ) ? $value : array() as $v ) {
				$id = is_scalar( $v ) ? absint( $v ) : 0;
				if ( $id && ! in_array( $id, $ids, true ) ) {
					$ids[] = $id;
				}
			}
			return array_slice( $ids, 0, 60 );
		case 'color':
			$c = sanitize_hex_color( is_scalar( $value ) ? (string) $value : '' );
			return $c ? $c : $default;
		case 'number':
		case 'range':
			$n = is_numeric( $value ) ? $value + 0 : $default;
			if ( isset( $def['min'] ) ) {
				$n = max( $def['min'], $n );
			}
			if ( isset( $def['max'] ) ) {
				$n = min( $def['max'], $n );
			}
			return $n;
		case 'select':
		case 'choice':
			$choices = corbuilder_field_choices( $def );
			if ( 'tint' === $value && ! isset( $choices['tint'] ) && isset( $choices['light'] ) ) { // « Secondaire clair » est devenu « Fond clair »
				$value = 'light';
			}
			return ( is_scalar( $value ) && isset( $choices[ $value ] ) ) ? (string) $value : $default;
		case 'multiselect':
			$choices = corbuilder_field_choices( $def );
			$out     = array();
			foreach ( is_array( $value ) ? $value : array() as $v ) {
				if ( is_scalar( $v ) && isset( $choices[ $v ] ) && ! in_array( (string) $v, $out, true ) ) {
					$out[] = (string) $v;
				}
			}
			return $out;
		case 'repeater':
			if ( ! is_array( $value ) ) {
				return array();
			}
			$max = isset( $def['max'] ) ? (int) $def['max'] : 24;
			$out = array();
			foreach ( array_slice( array_values( $value ), 0, $max ) as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$clean  = corbuilder_sanitize_fields( $def['fields'], $item );
				$filled = false; // on écarte les éléments entièrement vides
				foreach ( $def['fields'] as $k => $sub ) {
					if ( in_array( $sub['type'], array( 'text', 'multiline', 'textarea', 'url', 'image', 'file' ), true ) && ! empty( $clean[ $k ] ) ) {
						$filled = true;
						break;
					}
				}
				if ( $filled ) {
					$out[] = $clean;
				}
			}
			return $out;
	}
	return $default;
}

function corbuilder_sanitize_fields( $fields, $data ) {
	$out = array();
	foreach ( $fields as $key => $def ) {
		$out[ $key ] = corbuilder_sanitize_value( $def, array_key_exists( $key, $data ) ? $data[ $key ] : corbuilder_field_default( $def ) );
	}
	return $out;
}

/* Nettoie la liste des sections d'un contexte : « page » ou « post » (modèle des articles) */
function corbuilder_sanitize_sections_for( $value, $context ) {
	$items = json_decode( is_string( $value ) ? $value : '', true );
	if ( ! is_array( $items ) ) {
		return '[]';
	}
	$registry = corbuilder_get_sections();
	$out      = array();
	$seen     = array();
	$unique   = array();

	foreach ( array_slice( $items, 0, 40 ) as $item ) {
		if ( ! is_array( $item ) || empty( $item['type'] ) || ! is_string( $item['type'] ) ) {
			continue;
		}
		$type = sanitize_key( $item['type'] );
		if ( ! isset( $registry[ $type ] ) || ! in_array( $context, $registry[ $type ]['contexts'], true ) ) {
			continue;
		}
		$def = $registry[ $type ];
		if ( ! empty( $def['unique'] ) ) { // une seule section de ce type : on garde la première
			if ( isset( $unique[ $type ] ) ) {
				continue;
			}
			$unique[ $type ] = true;
		}
		$fields = array_merge( $def['fields'], corbuilder_common_fields( $def ) );
		$data   = ( isset( $item['data'] ) && is_array( $item['data'] ) ) ? $item['data'] : array();

		$id = isset( $item['id'] ) && is_string( $item['id'] ) ? sanitize_key( $item['id'] ) : '';
		if ( '' === $id || isset( $seen[ $id ] ) ) {
			$id = strtolower( wp_generate_password( 6, false, false ) );
		}
		$seen[ $id ] = true;

		$clean = corbuilder_sanitize_fields( $fields, $data );
		if ( empty( $clean['bg_image'] ) ) { // sans image de fond, l'opacité de la couleur ne peut pas être inférieure à 100
			$clean['bg_opacity']  = 100;
			$clean['bg_opacity2'] = 100;
		}
		$out[] = array(
			'id'   => $id,
			'type' => $type,
			'data' => $clean,
		);
	}
	return wp_json_encode( $out );
}

/* Fonctions à un seul paramètre : le Customizer leur transmet aussi l'objet du réglage */
function corbuilder_sanitize_sections( $value, $setting = null ) {
	// Éditeur de contenu : seul le contenu des sections existantes est pris en compte (le reste vient de la valeur enregistrée)
	if ( $setting && ! empty( $setting->id ) && ! current_user_can( 'edit_theme_options' ) ) {
		$value = corbuilder_restrict_posted_sections( $value, $setting->id, isset( $setting->manager ) ? $setting->manager : null );
	}
	return corbuilder_sanitize_sections_for( $value, 'page' );
}

function corbuilder_sanitize_post_template_sections( $value ) {
	return corbuilder_sanitize_sections_for( $value, 'post' );
}

/* Modèle des articles proposé tant que rien n'est enregistré */
function corbuilder_default_post_template() {
	$item = function ( $id, $type ) {
		return array( 'id' => $id, 'type' => $type, 'data' => new stdClass() );
	};
	return wp_json_encode( array(
		$item( 'entete', 'post-header' ),
		$item( 'contenu', 'post-content' ),
		$item( 'precsuiv', 'post-nav' ),
		$item( 'commentaires', 'post-comments' ),
	) );
}

/* =========================================================================
 * LECTURE ET AFFICHAGE
 * ========================================================================= */

function corbuilder_get_sections_by_key( $key, $context, $default = '[]' ) {
	$items = json_decode( (string) corbuilder_migrate_sections_json( (string) get_theme_mod( $key, $default ) ), true ); // anciennes couleurs converties à la lecture
	if ( ! is_array( $items ) ) {
		return array();
	}
	$registry = corbuilder_get_sections();
	$out      = array();
	foreach ( $items as $item ) {
		if ( is_array( $item ) && isset( $item['type'] ) && is_string( $item['type'] ) && isset( $registry[ $item['type'] ] )
			&& in_array( $context, $registry[ $item['type'] ]['contexts'], true ) ) {
			$out[] = $item;
		}
	}
	return $out;
}

function corbuilder_get_page_sections( $pid ) {
	return corbuilder_get_sections_by_key( "corbuilder_p{$pid}_sections", 'page' );
}

/* Sections du modèle des articles (liste vide = le gabarit simple de single.php est utilisé) */
function corbuilder_get_post_template_sections() {
	return corbuilder_get_sections_by_key( 'corbuilder_post_template_sections', 'post', corbuilder_default_post_template() );
}

function corbuilder_sections_have_h1( $sections ) {
	$registry = corbuilder_get_sections();
	foreach ( $sections as $item ) {
		if ( ! empty( $registry[ $item['type'] ]['h1'] ) ) {
			return true;
		}
	}
	return false;
}

function corbuilder_section_data( $def, $data ) {
	$defaults = array_merge( corbuilder_field_defaults( $def['fields'] ), corbuilder_field_defaults( corbuilder_common_fields( $def ) ) );
	return array_merge( $defaults, $data );
}

/* Sections à afficher (celles « vides » sont écartées hors aperçu du Customizer).
   $pid : page, ou article en cours pour le modèle des articles. */
function corbuilder_prepare_items( $items, $pid, $context ) {
	$registry = corbuilder_get_sections();
	$ctx      = (object) array( 'pid' => (int) $pid, 'context' => $context );
	$out      = array();
	foreach ( $items as $item ) {
		$def  = $registry[ $item['type'] ];
		$data = corbuilder_section_data( $def, ( isset( $item['data'] ) && is_array( $item['data'] ) ) ? $item['data'] : array() );
		if ( ! empty( $def['prepare'] ) && is_callable( $def['prepare'] ) ) {
			$data = call_user_func( $def['prepare'], $data, $ctx );
		}
		if ( ! empty( $def['skip'] ) && is_callable( $def['skip'] ) && call_user_func( $def['skip'], $data ) && ! is_customize_preview() ) {
			continue;
		}
		$out[] = array( 'item' => $item, 'def' => $def, 'data' => $data );
	}
	return $out;
}

function corbuilder_prepare_sections( $pid ) {
	return corbuilder_prepare_items( corbuilder_get_page_sections( $pid ), $pid, 'page' );
}

/* Couleur de fond choisie (dans la palette) -> [r, g, b] ou null. « custom » : ancienne couleur libre, encore lue si elle n'a pas été migrée. */
function corbuilder_bg_rgb( $data, $color_key = 'bg_color', $custom_key = 'bg_custom' ) {
	$choice = isset( $data[ $color_key ] ) ? $data[ $color_key ] : 'none';
	if ( 'custom' === $choice ) {
		$choice = corbuilder_nearest_palette_key( isset( $data[ $custom_key ] ) ? $data[ $custom_key ] : '' );
	}
	$hex = ( 'none' === $choice ) ? '' : corbuilder_palette_hex( (string) $choice );
	return $hex ? corbuilder_hex_to_rgb( $hex ) : null;
}

/* Texte clair ou foncé : réglage manuel, sinon calculé d'après le fond obtenu */
function corbuilder_section_tone( $data, $rgb, $opacity, $has_image ) {
	if ( in_array( $data['text_tone'], array( 'light', 'dark' ), true ) ) {
		return $data['text_tone'];
	}
	if ( ! $rgb ) {
		return $has_image ? 'light' : 'dark';
	}
	$base = $has_image ? 128 : 255; // fond estimé derrière la couleur : image moyenne ou page blanche
	$mix  = function ( $c ) use ( $opacity, $base ) {
		return $c * $opacity + $base * ( 1 - $opacity );
	};
	$yiq = ( 299 * $mix( $rgb[0] ) + 587 * $mix( $rgb[1] ) + 114 * $mix( $rgb[2] ) ) / 1000;
	return $yiq >= 150 ? 'dark' : 'light';
}

/* Tout ce qu'il faut savoir sur l'apparence d'une section (rendu HTML et export).
   $index : rang de la section dans la liste ; $after_divider : la section précédente a une transition. */
function corbuilder_section_look( $entry, $index = 0, $after_divider = false ) {
	$def  = $entry['def'];
	$data = $entry['data'];
	$item = $entry['item'];

	$image    = absint( $data['bg_image'] );
	$rgb      = corbuilder_bg_rgb( $data );
	$opacity  = $image ? max( 0, min( 100, (int) $data['bg_opacity'] ) ) / 100 : 1; // sans image de fond, la couleur est toujours pleine (100 %)
	$gradient = isset( $data['bg_mode'] ) && 'gradient' === $data['bg_mode'];
	$raw      = ( isset( $item['data'] ) && is_array( $item['data'] ) ) ? $item['data'] : array();
	// 2e opacité : un dégradé enregistré avant ce réglage garde la même opacité pour ses deux couleurs
	$opacity2 = ( $image && $gradient && array_key_exists( 'bg_opacity2', $raw ) ) ? max( 0, min( 100, (int) $data['bg_opacity2'] ) ) / 100 : $opacity;
	$rgb2     = $gradient ? corbuilder_bg_rgb( $data, 'bg_color2', 'bg_custom2' ) : null;
	$tone_rgb = $rgb;
	if ( $gradient && $rgb && $rgb2 ) { // texte clair ou foncé d'après la couleur moyenne du dégradé
		$tone_rgb = array( (int) round( ( $rgb[0] + $rgb2[0] ) / 2 ), (int) round( ( $rgb[1] + $rgb2[1] ) / 2 ), (int) round( ( $rgb[2] + $rgb2[2] ) / 2 ) );
	} elseif ( $gradient && $rgb2 ) {
		$tone_rgb = $rgb2;
	}
	$tone    = corbuilder_section_tone( $data, $tone_rgb, $gradient ? ( $opacity + $opacity2 ) / 2 : $opacity, (bool) $image );
	$spacing = corbuilder_spacing_values();

	$vars = '';
	if ( $gradient && ( $rgb || $rgb2 ) ) {
		$stop   = function ( $c, $alpha ) {
			return $c ? sprintf( 'rgba(%d,%d,%d,%s)', $c[0], $c[1], $c[2], number_format( $alpha, 2, '.', '' ) ) : 'rgba(0,0,0,0)';
		};
		$angles = array( 'bottom' => 'to bottom', 'top' => 'to top', 'right' => 'to right', 'left' => 'to left', 'diag' => '135deg' );
		$angle  = isset( $angles[ $data['bg_angle'] ] ) ? $angles[ $data['bg_angle'] ] : 'to bottom';
		$vars  .= '--sec-overlay:linear-gradient(' . $angle . ',' . $stop( $rgb, $opacity ) . ',' . $stop( $rgb2, $opacity2 ) . ');';
	} elseif ( ! $gradient && $rgb ) {
		$vars .= sprintf( '--sec-overlay:rgba(%d,%d,%d,%s);', $rgb[0], $rgb[1], $rgb[2], number_format( $opacity, 2, '.', '' ) );
	}
	if ( 'default' !== $data['spacing'] && isset( $spacing[ $data['spacing'] ] ) ) {
		$vars .= '--section-pad:' . $spacing[ $data['spacing'] ] . ';' . corbuilder_head_gap_css( $data['spacing'] );
	}

	$classes = array( 'section', 'section--' . sanitize_html_class( $item['type'] ) );
	if ( $image ) {
		$classes[] = 'has-bg-image';
	}
	if ( 'light' === $tone ) {
		$classes[] = 'is-light-text';
	}
	if ( ! empty( $data['text_shadow'] ) ) {
		$classes[] = 'has-text-shadow';
	}
	if ( in_array( $data['visibility'], array( 'hide-mobile', 'hide-desktop' ), true ) ) {
		$classes[] = $data['visibility'];
	}
	if ( ! empty( $data['anim_off'] ) || empty( $def['animate'] ) ) {
		$classes[] = 'no-anim';
	}
	if ( ! empty( $def['classes'] ) && is_callable( $def['classes'] ) ) {
		foreach ( (array) call_user_func( $def['classes'], $data ) as $extra ) {
			$classes[] = sanitize_html_class( $extra );
		}
	}
	// Transition : le bas de la section est découpé (masque CSS) ; la suivante remonte dessous (after-divider).
	if ( 'none' !== $data['divider'] ) {
		$classes[] = 'has-divider';
		$classes[] = 'has-divider--' . sanitize_html_class( $data['divider'] );
		$classes[] = 'sec-z-' . max( 1, 19 - (int) $index ); // chaque section passe au-dessus de la suivante, mais sous le menu
	}
	if ( $after_divider ) {
		$classes[] = 'after-divider';
	}

	$id     = isset( $item['id'] ) ? sanitize_key( $item['id'] ) : '';
	$anchor = '' !== $data['anchor'] ? sanitize_title( $data['anchor'] ) : ( $id ? 'section-' . $id : '' );

	return array(
		'image'   => $image,
		'rgb'     => $tone_rgb,
		'opacity' => $opacity,
		'tone'    => $tone,
		'vars'    => $vars,
		'classes' => $classes,
		'anchor'  => $anchor,
	);
}

/* Bande derrière la dernière section quand elle a une transition : on voit à travers la découpe la couleur
   du pied de page (« footer »), ou celle de la page si du contenu suit les sections (« page »). Hauteur nulle. */
function corbuilder_section_band_html( $after = 'footer' ) {
	return '<div class="section-band section-band--' . ( 'page' === $after ? 'page' : 'footer' ) . '" aria-hidden="true"></div>';
}

/* HTML complet d'une section. $ctx suit le rang et la transition de la section précédente. */
function corbuilder_section_html( $entry, $ctx ) {
	$def  = $entry['def'];
	$data = $entry['data'];
	$look = corbuilder_section_look( $entry, $ctx->index, ! empty( $ctx->prev_divider ) );

	ob_start();
	echo '<section' . ( $look['anchor'] ? ' id="' . esc_attr( $look['anchor'] ) . '"' : '' )
		. ' class="' . esc_attr( implode( ' ', $look['classes'] ) ) . '"'
		. ( $look['vars'] ? ' style="' . esc_attr( $look['vars'] ) . '"' : '' ) . '>';

	if ( $look['image'] ) {
		$blur = isset( $data['bg_blur'] ) ? (string) $data['bg_blur'] : 'none';
		$lvls = corbuilder_blur_levels();
		$attr = array( 'class' => 'section__bgimg' . ( isset( $lvls[ $blur ] ) ? ' section__bgimg--blur section__bgimg--blur-' . $blur : '' ), 'alt' => '', 'sizes' => '100vw' );
		if ( 0 === $ctx->index ) {
			$attr['loading']       = 'eager';
			$attr['fetchpriority'] = 'high';
		}
		echo wp_get_attachment_image( $look['image'], 'full', false, $attr ); // phpcs:ignore WordPress.Security.EscapeOutput -- sortie WordPress native
	}

	if ( $def['wrap'] ) {
		echo '<div class="wrap section__inner">';
	}
	call_user_func( $def['render'], $data, $ctx );
	echo corbuilder_end_button_html( $data ); // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $def['wrap'] ) {
		echo '</div>';
	}
	echo '</section>';

	$ctx->index++;
	$ctx->prev_divider = ( 'none' !== $data['divider'] );
	return ob_get_clean();
}

/* Affiche une liste de sections préparées, dans l'ordre choisi.
   $after : ce qui suit les sections, pour la couleur derrière la dernière transition ('footer' ou 'page'). */
function corbuilder_render_entries( $entries, $pid, $context, $after = 'footer' ) {
	$ctx = (object) array( 'pid' => (int) $pid, 'h1' => false, 'index' => 0, 'context' => $context, 'prev_divider' => false );
	foreach ( $entries as $entry ) {
		echo corbuilder_section_html( $entry, $ctx ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( ! empty( $ctx->prev_divider ) ) {
		echo corbuilder_section_band_html( $after ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/* Sections d'une page ($after = 'page' si du contenu de l'éditeur suit les sections) */
function corbuilder_render_sections( $pid, $after = 'footer' ) {
	corbuilder_render_entries( corbuilder_prepare_sections( $pid ), $pid, 'page', $after );
}

/* Sections du modèle des articles, pour l'article $pid */
function corbuilder_render_post_template( $pid ) {
	corbuilder_render_entries( corbuilder_prepare_items( corbuilder_get_post_template_sections(), $pid, 'post' ), $pid, 'post', 'footer' );
}
