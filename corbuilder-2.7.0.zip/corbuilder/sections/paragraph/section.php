<?php
/**
 * Section « Paragraphe » : du texte seul, présenté avec soin : texte lisible, encadré, citation ou deux colonnes,
 * avec une lettrine facultative. Une liste de paragraphes titrés (numérotés au choix) permet d'écrire un texte long
 * en rubriques, par exemple une page légale. Dans un texte, une ligne qui commence par « - » devient une puce.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Paragraphe', 'corbuilder' ),
	'description' => __( 'Du texte bien présenté, avec une liste de paragraphes titrés pour les textes longs (pages légales, conditions…). Une ligne qui commence par « - » devient une puce.', 'corbuilder' ),
	'order'       => 15,
	'head_align'  => 'left', // du texte se lit mieux aligné à gauche ; la citation se centre souvent (réglable)
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Texte (ou introduction avant les paragraphes titrés)', 'corbuilder' ) ),
		'blocks'   => array(
			'type'       => 'repeater',
			'label'      => __( 'Paragraphes titrés', 'corbuilder' ),
			'item_label' => __( 'Paragraphe', 'corbuilder' ),
			'add_label'  => __( 'Ajouter un paragraphe titré', 'corbuilder' ),
			'max'        => 60,
			'fields'     => array(
				'heading' => array( 'type' => 'text', 'label' => __( 'Titre du paragraphe', 'corbuilder' ) ),
				'text'    => array( 'type' => 'textarea', 'label' => __( 'Texte', 'corbuilder' ) ),
			),
		),
		'numbered' => array( 'type' => 'checkbox', 'label' => __( 'Numéroter les titres des paragraphes (1., 2., 3.…)', 'corbuilder' ) ),
		'style'    => array(
			'type'    => 'select',
			'label'   => __( 'Présentation', 'corbuilder' ),
			'choices' => array(
				'plain'   => __( 'Texte (colonne lisible)', 'corbuilder' ),
				'boxed'   => __( 'Encadré (fond teinté et liseré)', 'corbuilder' ),
				'quote'   => __( 'Citation (grand texte avec guillemets)', 'corbuilder' ),
				'columns' => __( 'Deux colonnes', 'corbuilder' ),
			),
			'default' => 'plain',
		),
		'width'    => array(
			'type'    => 'select',
			'label'   => __( 'Largeur du texte', 'corbuilder' ),
			'choices' => array(
				'narrow'  => __( 'Étroite', 'corbuilder' ),
				'medium'  => __( 'Moyenne', 'corbuilder' ),
				'wide'    => __( 'Large', 'corbuilder' ),
			),
			'default' => 'medium',
		),
		'dropcap'  => array( 'type' => 'checkbox', 'label' => __( 'Lettrine (grande première lettre)', 'corbuilder' ) ),
	),
	'skip'        => function ( $d ) {
		if ( '' !== $d['title'] || '' !== $d['subtitle'] || '' !== trim( (string) $d['text'] ) ) {
			return false;
		}
		foreach ( (array) $d['blocks'] as $b ) {
			if ( is_array( $b ) && ( '' !== trim( isset( $b['heading'] ) ? (string) $b['heading'] : '' ) || '' !== trim( isset( $b['text'] ) ? (string) $b['text'] : '' ) ) ) {
				return false;
			}
		}
		return true;
	},
	'render'      => function ( $d ) {
		$style = in_array( $d['style'], array( 'plain', 'boxed', 'quote', 'columns' ), true ) ? $d['style'] : 'plain';
		$width = in_array( $d['width'], array( 'narrow', 'medium', 'wide' ), true ) ? $d['width'] : 'medium';
		$align = in_array( $d['head_align'], array( 'left', 'center', 'right' ), true ) ? $d['head_align'] : 'center';

		echo '<div class="paragraph paragraph--' . esc_attr( $style ) . ' paragraph--w-' . esc_attr( $width ) . ' paragraph--align-' . esc_attr( $align ) . ( ! empty( $d['dropcap'] ) ? ' paragraph--dropcap' : '' ) . ' anim">';
		if ( '' !== $d['title'] ) {
			echo '<h2 class="section__title">' . corbuilder_multiline_html( $d['title'] ) . '</h2>';
		}
		if ( '' !== $d['subtitle'] ) {
			echo '<h3 class="section__subtitle">' . corbuilder_multiline_html( $d['subtitle'] ) . '</h3>';
		}

		echo '<div class="paragraph__content">';
		$first = true; // la lettrine ne concerne que le tout premier texte
		if ( '' !== trim( (string) $d['text'] ) ) {
			echo '<div class="paragraph__body paragraph__body--first">' . corbuilder_text_with_lists( $d['text'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$first = false;
		}
		$n = 0;
		foreach ( (array) $d['blocks'] as $b ) {
			$heading = is_array( $b ) && isset( $b['heading'] ) ? trim( (string) $b['heading'] ) : '';
			$text    = is_array( $b ) && isset( $b['text'] ) ? (string) $b['text'] : '';
			if ( '' === $heading && '' === trim( $text ) ) {
				continue;
			}
			echo '<div class="paragraph__block">';
			if ( '' !== $heading ) {
				++$n;
				echo '<h3 class="paragraph__heading">' . ( ! empty( $d['numbered'] ) ? esc_html( $n . '. ' ) : '' ) . esc_html( $heading ) . '</h3>';
			}
			if ( '' !== trim( $text ) ) {
				echo '<div class="paragraph__body' . ( $first ? ' paragraph__body--first' : '' ) . '">' . corbuilder_text_with_lists( $text ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
				$first = false;
			}
			echo '</div>';
		}
		echo '</div></div>';
	},
);
