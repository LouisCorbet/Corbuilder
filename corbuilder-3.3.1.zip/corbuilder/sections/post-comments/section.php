<?php
/**
 * Section « Commentaires » : liste et formulaire (réglages de WordPress). Réservée au modèle des articles.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Commentaires', 'corbuilder' ),
	'description' => __( 'Commentaires et formulaire, selon les réglages de WordPress. Masquée si les commentaires sont fermés et qu’il n’y en a aucun.', 'corbuilder' ),
	'order'       => 4,
	'contexts'    => array( 'post' ),
	'unique'      => true,
	'end_button'  => false,
	'fields'      => array(),
	'skip'        => function () {
		return ! comments_open() && ! get_comments_number();
	},
	'render'      => function () {
		comments_template();
	},
);
