<?php
/**
 * Section « Article précédent / suivant ». Réservée au modèle des articles.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Article précédent / suivant', 'corbuilder' ),
	'description' => __( 'Liens vers l’article précédent et l’article suivant. Masquée s’il n’y en a pas.', 'corbuilder' ),
	'order'       => 3,
	'contexts'    => array( 'post' ),
	'unique'      => true,
	'end_button'  => false,
	'fields'      => array(),
	'skip'        => function () {
		return ! get_previous_post() && ! get_next_post();
	},
	'render'      => function () {
		$links = array(
			'prev' => array( get_previous_post(), __( '← Article précédent', 'corbuilder' ) ),
			'next' => array( get_next_post(), __( 'Article suivant →', 'corbuilder' ) ),
		);
		echo '<nav class="post-nav" aria-label="' . esc_attr__( 'Navigation entre articles', 'corbuilder' ) . '">';
		foreach ( $links as $rel => $pair ) {
			if ( $pair[0] ) {
				echo '<a class="post-nav__link post-nav__link--' . esc_attr( $rel ) . '" rel="' . esc_attr( $rel ) . '" href="' . esc_url( get_permalink( $pair[0] ) ) . '">'
					. '<span class="post-nav__label">' . esc_html( $pair[1] ) . '</span>'
					. '<span class="post-nav__title">' . esc_html( get_the_title( $pair[0] ) ) . '</span></a>';
			}
		}
		echo '</nav>';
	},
);
