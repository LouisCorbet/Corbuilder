<?php
/**
 * Section « Cartes » : en-tête (H2 / H3 / paragraphe) + liste de cartes.
 * Chaque carte a 4 groupes de réglages : En-tête (titre, sous-titre), Contenu (prix, paragraphe,
 * liste de points), Pied de carte, Style (icône, étiquette, bouton, image, mise en avant) ;
 * chacun avec son alignement (voir inc/cards.php).
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'  => __( 'Cartes', 'corbuilder' ),
	'order'  => 30,
	'bg'     => array( 'color' => 'tint' ),
	'fields' => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'columns'  => corbuilder_card_columns_field( 'auto', true ),
		'density'  => corbuilder_card_density_field(),
		'vspread'  => corbuilder_card_spread_field(),
		'items'    => array(
			'type'       => 'repeater',
			'label'      => __( 'Liste des cartes', 'corbuilder' ),
			'item_label' => __( 'Carte', 'corbuilder' ),
			'add_label'  => __( 'Ajouter une carte', 'corbuilder' ),
			'max'        => 24,
			'fields'     => corbuilder_card_fields(),
		),
	),
	'render' => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! empty( $d['items'] ) && is_array( $d['items'] ) ) {
			echo '<div class="' . esc_attr( corbuilder_card_grid_class( $d['columns'] ) . ( 'airy' === $d['density'] ? ' cards__grid--airy' : '' ) . ( 'stack' === $d['vspread'] ? ' cards__grid--stack' : '' ) ) . '">';
			foreach ( array_values( $d['items'] ) as $i => $item ) {
				echo corbuilder_render_card( $item, $i ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div>';
		}
	},
);
