<?php
/**
 * Section « HTML personnalisé » : du HTML (titres, listes, images, citations, vidéos, blocs…), disponible dans les pages et dans les
 * articles. Seul un administrateur peut l'ajouter et en modifier le contenu. C'est aussi la section où arrive le texte d'un article écrit
 * dans l'éditeur WordPress quand le thème passe à l'éditeur par sections : elle y est placée même si l'administrateur ne la propose pas.
 * (L'identifiant interne reste « rich-text » : les articles déjà enregistrés l'utilisent.)
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'HTML personnalisé', 'corbuilder' ),
	'description' => __( 'Du HTML libre (titres, listes, images, citations, vidéos, blocs…), réservé à l’administrateur. Le texte d’un article écrit dans l’éditeur WordPress arrive ici quand on passe à l’éditeur par sections.', 'corbuilder' ),
	'order'       => 16,
	'admin_only'  => true, // ajout et contenu réservés aux administrateurs (l'éditeur de contenu ne peut ni l'ajouter, ni le modifier, ni le supprimer)
	'head_align'  => false,
	'end_button'  => false,
	'fields'      => array(
		'html'  => array( 'type' => 'richtext', 'label' => __( 'Code HTML', 'corbuilder' ) ),
		'render_mode' => array(
			'type'    => 'select',
			'label'   => __( 'Rendu du contenu', 'corbuilder' ),
			'choices' => array(
				'raw'       => __( 'HTML libre (sans formatage automatique)', 'corbuilder' ),
				'wordpress' => __( 'Texte WordPress (paragraphes automatiques)', 'corbuilder' ),
			),
			'default' => 'raw',
		),
		'width' => array(
			'type'    => 'select',
			'label'   => __( 'Largeur du texte', 'corbuilder' ),
			'choices' => array(
				'narrow' => __( 'Étroite (confort de lecture)', 'corbuilder' ),
				'medium' => __( 'Moyenne', 'corbuilder' ),
				'wide'   => __( 'Large', 'corbuilder' ),
			),
			'default' => 'medium',
		),
	),
	'skip'        => function ( $d ) {
		return '' === trim( (string) $d['html'] );
	},
	'render'      => function ( $d ) {
		// Seul le contenu WordPress migré conserve the_content. Pour le HTML libre,
		// wpautop et les transformations
		// typographiques peuvent corrompre les scripts, les styles et leur balisage.
		// Conserver les blocs des articles migrés et les shortcodes sans reformater le code.
		$html = isset( $d['render_mode'] ) && 'wordpress' === $d['render_mode']
			? apply_filters( 'the_content', (string) $d['html'] )
			: do_shortcode( do_blocks( (string) $d['html'] ) );
		echo '<div class="post-content post-content--' . esc_attr( $d['width'] ) . ' entry-content">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- contenu validé à l’enregistrement selon la capacité unfiltered_html
	},
);
