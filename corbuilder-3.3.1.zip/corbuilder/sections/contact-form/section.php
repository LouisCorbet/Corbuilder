<?php
/**
 * Section « Formulaire de contact » : affiche un formulaire Contact Form 7 au choix.
 * Nécessite le plugin Contact Form 7 (et un plugin SMTP pour que les e-mails arrivent bien).
 */
defined( 'ABSPATH' ) || exit;

// Formulaires Contact Form 7 publiés : identifiant => titre.
$corbuilder_cf7_forms = function () {
	static $forms = null;
	if ( null === $forms ) {
		$forms = array();
		foreach ( get_posts( array(
			'post_type'      => 'wpcf7_contact_form',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) ) as $form ) {
			$title                  = html_entity_decode( get_the_title( $form ), ENT_QUOTES, 'UTF-8' );
			$forms[ (int) $form->ID ] = '' !== $title ? $title : sprintf( __( 'Formulaire n° %d', 'corbuilder' ), $form->ID );
		}
	}
	return $forms;
};

// Formulaire choisi s'il existe encore : array( id, titre ) ; sinon null.
$corbuilder_cf7_pick = function ( $value ) use ( $corbuilder_cf7_forms ) {
	if ( ! is_string( $value ) || 0 !== strpos( $value, 'cf7-' ) ) {
		return null;
	}
	$id    = absint( substr( $value, 4 ) );
	$forms = $corbuilder_cf7_forms();
	return ( $id && isset( $forms[ $id ] ) ) ? array( $id, $forms[ $id ] ) : null;
};

return array(
	'label'       => __( 'Formulaire de contact', 'corbuilder' ),
	'description' => __( 'Affiche un formulaire créé avec Contact Form 7 (menu « Contact » de l’administration). Les champs et les e-mails se règlent dans le plugin.', 'corbuilder' ),
	'order'       => 45,
	'requires'    => array( 'contact-form-7' => 'Contact Form 7' ),
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'form'     => array(
			'type'    => 'select',
			'label'   => __( 'Formulaire', 'corbuilder' ),
			'choices' => function () use ( $corbuilder_cf7_forms ) {
				$choices = array( 'none' => __( '— Choisir un formulaire —', 'corbuilder' ) );
				foreach ( $corbuilder_cf7_forms() as $id => $title ) {
					$choices[ 'cf7-' . $id ] = $title;
				}
				return $choices;
			},
		),
	),
	// Pas de « skip » : une section sans titre ni contenu reste affichée (fond, espacement, transition de fin).
	'render'      => function ( $d ) use ( $corbuilder_cf7_pick ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$pick = $corbuilder_cf7_pick( $d['form'] );
		if ( ! $pick || ! shortcode_exists( 'contact-form-7' ) ) {
			// Message réservé aux administrateurs ; rien pour les visiteurs.
			if ( current_user_can( 'edit_theme_options' ) ) {
				echo '<p class="reusable__empty">' . esc_html__( 'Installe et active Contact Form 7, puis choisis un formulaire dans cette section.', 'corbuilder' ) . '</p>';
			}
			return;
		}
		$title = trim( str_replace( array( '"', '[', ']' ), '', $pick[1] ) );
		echo '<div class="corbuilder-contact">' . do_shortcode( '[contact-form-7 id="' . (int) $pick[0] . '" title="' . $title . '"]' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
