<?php
/**
 * Section « Galerie » : grille de photos ; au clic, la photo s'ouvre en grand avec défilement
 * (flèches, clavier, glissement au doigt). Sans JavaScript, le clic ouvre le fichier image.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Galerie', 'corbuilder' ),
	'description' => __( 'Une grille de photos. Au clic, la photo s’affiche en grand avec défilement. La légende vient de la médiathèque.', 'corbuilder' ),
	'order'       => 37,
	'fields'      => array(
		'title'         => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'      => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'          => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'images'        => array( 'type' => 'gallery', 'label' => __( 'Photos', 'corbuilder' ) ),
		'columns'       => array(
			'type'    => 'select',
			'label'   => __( 'Colonnes', 'corbuilder' ),
			'choices' => array(
				'2' => __( '2 colonnes', 'corbuilder' ),
				'3' => __( '3 colonnes', 'corbuilder' ),
				'4' => __( '4 colonnes', 'corbuilder' ),
				'5' => __( '5 colonnes', 'corbuilder' ),
				'6' => __( '6 colonnes', 'corbuilder' ),
			),
			'default' => '3',
		),
		'ratio'         => array(
			'type'    => 'select',
			'label'   => __( 'Forme des vignettes', 'corbuilder' ),
			'choices' => array(
				'square'    => __( 'Carrées', 'corbuilder' ),
				'landscape' => __( 'Paysage (4:3)', 'corbuilder' ),
				'natural'   => __( 'Proportions d’origine', 'corbuilder' ),
			),
		),
		'lightbox'      => array( 'type' => 'checkbox', 'label' => __( 'Ouvrir la photo en grand au clic', 'corbuilder' ), 'default' => true ),
		'show_captions' => array( 'type' => 'checkbox', 'label' => __( 'Afficher les légendes sous les vignettes', 'corbuilder' ) ),
	),
	// Pas de « skip » : une section sans titre ni contenu reste affichée (fond, espacement, transition de fin).
	'render'      => function ( $d ) {
		static $count = 0;
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$ids = array_values( array_filter( array_map( 'absint', (array) $d['images'] ) ) );
		if ( ! $ids ) {
			if ( is_customize_preview() ) { // message d'aide : seulement dans l'aperçu du Customizer, jamais pour les visiteurs
				echo '<p class="reusable__empty">' . esc_html__( 'Ajoute des photos dans cette section.', 'corbuilder' ) . '</p>';
			}
			return;
		}
		$lightbox = ! empty( $d['lightbox'] );
		if ( $lightbox ) {
			wp_enqueue_script( 'corbuilder-lightbox', get_template_directory_uri() . '/assets/lightbox.js', array(), CORBUILDER_VERSION, true );
		}
		++$count;
		$cols = max( 2, min( 6, (int) $d['columns'] ) );

		echo '<ul class="gallery__grid gallery__grid--cols-' . (int) $cols . ' gallery__grid--' . esc_attr( $d['ratio'] ) . '">';
		foreach ( $ids as $i => $id ) {
			$full = wp_get_attachment_image_url( $id, 'full' );
			$img  = wp_get_attachment_image( $id, 'medium_large', false, array( 'loading' => 'lazy' ) );
			if ( ! $full || ! $img ) {
				continue;
			}
			$caption = trim( wp_strip_all_tags( (string) wp_get_attachment_caption( $id ) ) );
			echo '<li class="gallery__item anim" style="--i:' . (int) $i . '">';
			if ( $lightbox ) {
				echo '<a class="gallery__link" href="' . esc_url( $full ) . '" data-corbuilder-lightbox="g' . (int) $count . '" data-caption="' . esc_attr( $caption ) . '">' . $img . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			} else {
				echo $img; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			if ( ! empty( $d['show_captions'] ) && '' !== $caption ) {
				echo '<p class="gallery__caption">' . esc_html( $caption ) . '</p>';
			}
			echo '</li>';
		}
		echo '</ul>';
	},
);
