<?php
/**
 * Section « Boutons de l'article » : un ou deux boutons dont l'adresse peut venir d'un champ personnalisé de l'article.
 * Réservée au modèle des articles. Les boutons ont les mêmes réglages que partout ailleurs (texte, icône, style, nouvel onglet).
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Boutons de l’article', 'corbuilder' ),
	'description' => __( 'Un ou deux boutons dont l’adresse peut être lue dans un champ personnalisé de l’article (lien, fichier ou e-mail), pour que chaque article ait son propre lien. Si le champ est vide, l’adresse saisie dans le bouton sert de secours ; sans adresse, le bouton n’est pas affiché.', 'corbuilder' ),
	'order'       => 5,
	'contexts'    => array( 'post' ),
	'end_button'  => false,
	'fields'      => array(
		'button'         => array( 'type' => 'button', 'label' => __( 'Bouton 1 (facultatif)', 'corbuilder' ) ),
		'button_source'  => array(
			'type'    => 'select',
			'label'   => __( 'Adresse du bouton 1', 'corbuilder' ),
			'choices' => 'corbuilder_button_source_choices',
			'default' => 'fixed',
		),
		'button2'        => array( 'type' => 'button', 'label' => __( 'Bouton 2 (facultatif)', 'corbuilder' ) ),
		'button2_source' => array(
			'type'    => 'select',
			'label'   => __( 'Adresse du bouton 2', 'corbuilder' ),
			'choices' => 'corbuilder_button_source_choices',
			'default' => 'fixed',
		),
		'align'          => array(
			'type'    => 'select',
			'label'   => __( 'Alignement des boutons', 'corbuilder' ),
			'choices' => array(
				'left'   => __( 'À gauche', 'corbuilder' ),
				'center' => __( 'Centré', 'corbuilder' ),
				'right'  => __( 'À droite', 'corbuilder' ),
			),
			'default' => 'center',
		),
	),
	// L'adresse d'un bouton relié à un champ personnalisé est lue dans l'article en cours.
	'prepare'     => function ( $d, $ctx ) {
		foreach ( array( 'button', 'button2' ) as $key ) {
			$btn = wp_parse_args( is_array( $d[ $key ] ) ? $d[ $key ] : array(), corbuilder_button_default() );
			$src = (string) $d[ $key . '_source' ];
			if ( 0 === strpos( $src, 'meta:' ) ) {
				$url = corbuilder_post_meta_url( $ctx->pid, substr( $src, 5 ) );
				if ( '' !== $url ) {
					$btn['url'] = $url;
				} elseif ( '' === trim( (string) $btn['url'] ) ) {
					$btn['label'] = ''; // ni champ rempli, ni adresse de secours : pas de bouton pour cet article
				}
			}
			$d[ $key ] = $btn;
		}
		return $d;
	},
	'skip'        => function ( $d ) {
		return '' === trim( (string) $d['button']['label'] ) && '' === trim( (string) $d['button2']['label'] );
	},
	'render'      => function ( $d ) {
		$btn = corbuilder_button( $d['button'] ) . corbuilder_button( $d['button2'], 'btn--secondary' );
		if ( '' !== $btn ) {
			echo '<div class="section__actions post-buttons post-buttons--' . esc_attr( $d['align'] ) . '">' . $btn . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- boutons échappés par corbuilder_button()
		}
	},
);
