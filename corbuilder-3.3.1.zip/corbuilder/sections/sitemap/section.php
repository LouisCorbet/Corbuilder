<?php
/**
 * Section « Plan du site » : liens vers les pages, hiérarchisés, mis à jour automatiquement.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Plan du site', 'corbuilder' ),
	'description' => __( 'Liste automatique des pages du site (ou du menu principal), mise à jour à chaque nouvelle page.', 'corbuilder' ),
	'order'       => 50,
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'source'   => array(
			'type'    => 'select',
			'label'   => __( 'Contenu de la liste', 'corbuilder' ),
			'choices' => array(
				'pages' => __( 'Toutes les pages', 'corbuilder' ),
				'menu'  => __( 'Le menu principal', 'corbuilder' ),
			),
		),
		'columns'  => array(
			'type'    => 'select',
			'label'   => __( 'Colonnes', 'corbuilder' ),
			'choices' => array(
				'1' => __( '1 colonne', 'corbuilder' ),
				'2' => __( '2 colonnes', 'corbuilder' ),
				'3' => __( '3 colonnes', 'corbuilder' ),
				'4' => __( '4 colonnes', 'corbuilder' ),
			),
			'default' => '2',
		),
		'exclude'  => array(
			'type'    => 'multiselect',
			'label'   => __( 'Pages à ne pas afficher', 'corbuilder' ),
			'choices' => function () {
				$choices = array();
				foreach ( get_pages( array( 'post_status' => 'publish', 'sort_column' => 'post_title' ) ) as $page ) {
					$choices[ 'p' . $page->ID ] = $page->post_title ? $page->post_title : __( '(sans titre)', 'corbuilder' );
				}
				return $choices;
			},
		),
	),
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$cols = max( 1, min( 4, (int) $d['columns'] ) );
		if ( 'menu' === $d['source'] ) {
			$list = wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'echo'           => false,
				'fallback_cb'    => '__return_false',
				'items_wrap'     => '<ul class="sitemap__list">%3$s</ul>',
				'depth'          => 3,
			) );
		} else {
			$exclude = array();
			foreach ( (array) $d['exclude'] as $key ) {
				$exclude[] = absint( substr( (string) $key, 1 ) );
			}
			$items = wp_list_pages( array(
				'title_li'    => '',
				'echo'        => 0,
				'exclude'     => implode( ',', array_filter( $exclude ) ),
				'sort_column' => 'menu_order,post_title',
			) );
			$list  = $items ? '<ul class="sitemap__list">' . $items . '</ul>' : '';
		}
		if ( $list ) {
			echo '<nav class="sitemap anim" style="--cols:' . (int) $cols . '" aria-label="' . esc_attr__( 'Plan du site', 'corbuilder' ) . '">' . $list . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	},
);
