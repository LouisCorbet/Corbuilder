<?php
/**
 * Section « Composant » : affiche un motif créé dans l'éditeur de blocs.
 * Modifier le motif dans l'éditeur le modifie partout où il est placé.
 * (Ce qui demande un plugin ou des réglages a sa propre section : formulaire, coordonnées, galerie…)
 */
defined( 'ABSPATH' ) || exit;

// Identifiant du motif choisi, s'il existe encore et est publié ; sinon 0.
$corbuilder_reusable_id = function ( $value ) {
	$id = ( is_string( $value ) && 0 === strpos( $value, 'block-' ) ) ? absint( substr( $value, 6 ) ) : 0;
	return ( $id && 'wp_block' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) ? $id : 0;
};

return array(
	'label'       => __( 'Composant', 'corbuilder' ),
	'description' => __( 'Affiche un motif créé dans l’éditeur de blocs (sélectionne des blocs → « Créer un motif »). Modifier le motif le modifie partout où il est utilisé.', 'corbuilder' ),
	'order'       => 40,
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'block' => array(
			'type'    => 'select',
			'label'   => __( 'Motif', 'corbuilder' ),
			'choices' => function () {
				static $choices = null;
				if ( null === $choices ) {
					// Clés préfixées : un objet JSON garde ainsi l'ordre d'insertion côté JavaScript.
					$choices = array( 'none' => __( '— Choisir un motif —', 'corbuilder' ) );
					$blocks  = get_posts( array(
						'post_type'      => 'wp_block',
						'post_status'    => 'publish',
						'posts_per_page' => 200,
						'orderby'        => 'title',
						'order'          => 'ASC',
						'no_found_rows'  => true,
					) );
					foreach ( $blocks as $block ) {
						$title = html_entity_decode( get_the_title( $block ), ENT_QUOTES, 'UTF-8' );
						/* translators: %d: identifiant du motif */
						$choices[ 'block-' . $block->ID ] = '' !== $title ? $title : sprintf( __( 'Motif n° %d', 'corbuilder' ), $block->ID );
					}
				}
				return $choices;
			},
		),
	),
	'skip'        => function ( $d ) use ( $corbuilder_reusable_id ) {
		return ! $corbuilder_reusable_id( $d['block'] );
	},
	'render'      => function ( $d ) use ( $corbuilder_reusable_id ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput
		$id = $corbuilder_reusable_id( $d['block'] );
		if ( ! $id ) {
			echo '<p class="reusable__empty">' . esc_html__( 'Choisis un motif dans cette section.', 'corbuilder' ) . '</p>'; // visible seulement dans l'aperçu
			return;
		}
		$html = render_block( array(
			'blockName'    => 'core/block',
			'attrs'        => array( 'ref' => $id ),
			'innerBlocks'  => array(),
			'innerHTML'    => '',
			'innerContent' => array(),
		) );
		echo '<div class="reusable__content entry-content">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- rendu natif des blocs
	},
);
