<?php
/**
 * Section « Vidéo » : une vidéo YouTube, Vimeo ou un fichier vidéo (.mp4, .webm), au format 16/9, dans la taille choisie.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'corbuilder_video_embed' ) ) {
	/* Adresse saisie -> array( 'type' => 'iframe' | 'file', 'src' => … ) ; null si elle n'est pas reconnue */
	function corbuilder_video_embed( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return null;
		}
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return null;
		}
		$host  = preg_replace( '/^www\\./', '', strtolower( $parts['host'] ) );
		$path  = isset( $parts['path'] ) ? $parts['path'] : '';
		$query = array();
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query );
		}

		// YouTube : lecteur « sans cookies »
		$id = '';
		if ( in_array( $host, array( 'youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com' ), true ) ) {
			if ( ! empty( $query['v'] ) && is_string( $query['v'] ) ) {
				$id = $query['v'];
			} elseif ( preg_match( '#^/(?:embed|shorts|live|v)/([A-Za-z0-9_-]+)#', $path, $m ) ) {
				$id = $m[1];
			}
		} elseif ( 'youtu.be' === $host && preg_match( '#^/([A-Za-z0-9_-]+)#', $path, $m ) ) {
			$id = $m[1];
		}
		if ( '' !== $id ) {
			return preg_match( '/^[A-Za-z0-9_-]{6,20}$/', $id ) ? array( 'type' => 'iframe', 'src' => 'https://www.youtube-nocookie.com/embed/' . $id ) : null;
		}

		// Vimeo (le paramètre dnt limite le suivi)
		if ( in_array( $host, array( 'vimeo.com', 'player.vimeo.com' ), true ) && preg_match( '#/(?:video/)?(\\d{5,})(?:/([A-Fa-f0-9]+))?#', $path, $m ) ) {
			$hash = ! empty( $m[2] ) ? $m[2] : ( ( ! empty( $query['h'] ) && is_string( $query['h'] ) && preg_match( '/^[A-Fa-f0-9]+$/', $query['h'] ) ) ? $query['h'] : '' );
			return array( 'type' => 'iframe', 'src' => 'https://player.vimeo.com/video/' . $m[1] . '?dnt=1' . ( '' !== $hash ? '&h=' . $hash : '' ) );
		}

		// Fichier vidéo direct
		if ( preg_match( '/\\.(mp4|m4v|webm|ogv)$/i', $path ) ) {
			return array( 'type' => 'file', 'src' => $url );
		}
		return null;
	}
}

return array(
	'label'       => __( 'Vidéo', 'corbuilder' ),
	'description' => __( 'Une vidéo YouTube, Vimeo ou un fichier vidéo (.mp4, .webm). Colle simplement son adresse.', 'corbuilder' ),
	'order'       => 36,
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'url'      => array( 'type' => 'url', 'label' => __( 'Adresse de la vidéo (https://…)', 'corbuilder' ) ),
		'size'     => array(
			'type'    => 'select',
			'label'   => __( 'Taille', 'corbuilder' ),
			'choices' => array(
				'small'  => __( 'Petite', 'corbuilder' ),
				'medium' => __( 'Moyenne', 'corbuilder' ),
				'large'  => __( 'Grande', 'corbuilder' ),
				'full'   => __( 'Pleine largeur', 'corbuilder' ),
			),
			'default' => 'large',
		),
	),
	'skip'        => function ( $d ) {
		return null === corbuilder_video_embed( $d['url'] );
	},
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$v = corbuilder_video_embed( $d['url'] );
		if ( ! $v ) { // n'arrive que dans l'aperçu du Customizer (sinon la section est écartée)
			echo '<p class="video__notice">' . esc_html__( 'Adresse de vidéo non reconnue : colle un lien YouTube, Vimeo ou un fichier .mp4 / .webm.', 'corbuilder' ) . '</p>';
			return;
		}
		$size  = in_array( $d['size'], array( 'small', 'medium', 'large', 'full' ), true ) ? $d['size'] : 'large';
		$title = '' !== (string) $d['title'] ? corbuilder_multiline_plain( $d['title'] ) : __( 'Lecteur vidéo', 'corbuilder' );

		echo '<div class="video video--' . esc_attr( $size ) . ' anim"><div class="video__frame">';
		if ( 'iframe' === $v['type'] ) {
			echo '<iframe src="' . esc_url( $v['src'] ) . '" title="' . esc_attr( $title ) . '" loading="lazy" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo '<video src="' . esc_url( $v['src'] ) . '" controls preload="metadata" playsinline></video>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	},
);
