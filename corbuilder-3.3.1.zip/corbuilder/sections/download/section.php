<?php
/**
 * Section « Téléchargement » : un ou plusieurs documents de la médiathèque, avec un bouton de téléchargement.
 * Pour un PDF, un aperçu est affiché dans la page (lecteur PDF du navigateur) ; sur mobile, où il est peu fiable,
 * la carte montre seulement le type du fichier.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Téléchargement', 'corbuilder' ),
	'description' => __( 'Des documents à télécharger (plaquette, tarifs, formulaire…), choisis dans la médiathèque. Les PDF s’affichent avec un aperçu.', 'corbuilder' ),
	'order'       => 39,
	'fields'      => array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'columns'  => corbuilder_card_columns_field( 'auto', true ),
		'items'    => array(
			'type'       => 'repeater',
			'label'      => __( 'Documents', 'corbuilder' ),
			'item_label' => __( 'Document', 'corbuilder' ),
			'add_label'  => __( 'Ajouter un document', 'corbuilder' ),
			'max'        => 12,
			'fields'     => array(
				'file'         => array( 'type' => 'file', 'label' => __( 'Fichier', 'corbuilder' ) ),
				'title'        => array( 'type' => 'text', 'label' => __( 'Titre (par défaut, celui du fichier)', 'corbuilder' ) ),
				'description'  => array( 'type' => 'text', 'label' => __( 'Description', 'corbuilder' ) ),
				'button_label' => array( 'type' => 'text', 'label' => __( 'Texte du bouton (par défaut : Télécharger)', 'corbuilder' ) ),
				'preview'      => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’aperçu (PDF)', 'corbuilder' ), 'default' => true ),
			),
		),
	),
	'skip'        => function ( $d ) {
		foreach ( (array) $d['items'] as $it ) {
			if ( is_array( $it ) && ! empty( $it['file'] ) && wp_get_attachment_url( absint( $it['file'] ) ) ) {
				return false;
			}
		}
		return true;
	},
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput

		$cols  = isset( $d['columns'] ) ? (string) $d['columns'] : 'auto';
		$cards = '';
		foreach ( (array) $d['items'] as $it ) {
			$it  = is_array( $it ) ? array_merge( array( 'file' => 0, 'title' => '', 'description' => '', 'button_label' => '', 'preview' => true ), $it ) : array();
			$id  = ! empty( $it['file'] ) ? absint( $it['file'] ) : 0;
			$url = $id ? wp_get_attachment_url( $id ) : '';
			if ( ! $url ) {
				continue;
			}
			$path  = (string) get_attached_file( $id );
			$ext   = strtoupper( pathinfo( $path ? $path : wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			$size  = ( '' !== $path && is_readable( $path ) ) ? size_format( (int) filesize( $path ), 1 ) : '';
			$is_pdf = 'application/pdf' === get_post_mime_type( $id ) || 'PDF' === $ext;
			$title = '' !== trim( (string) $it['title'] ) ? (string) $it['title'] : get_the_title( $id );
			$label = '' !== trim( (string) $it['button_label'] ) ? (string) $it['button_label'] : __( 'Télécharger', 'corbuilder' );
			$meta  = trim( $ext . ( '' !== $size ? ' · ' . $size : '' ), ' ·' );

			$cards .= '<article class="card download-card anim">';
			$fallback = '<span class="download-card__fallback"><span class="download-card__icon">' . corbuilder_icon_svg( 'file-text', 'download-card__svg' ) . '</span>' . ( '' !== $ext ? '<span class="download-card__ext">' . esc_html( $ext ) . '</span>' : '' ) . '</span>';
			if ( $is_pdf && ! empty( $it['preview'] ) ) {
				/* translators: %s: titre du document */
				$frame_title = sprintf( __( 'Aperçu : %s', 'corbuilder' ), $title );
				$cards      .= '<div class="download-card__preview download-card__preview--pdf"><iframe src="' . esc_url( $url ) . '#toolbar=0&amp;navpanes=0&amp;view=FitH" title="' . esc_attr( $frame_title ) . '" loading="lazy"></iframe>' . $fallback . '</div>';
			} else {
				$cards .= '<div class="download-card__preview">' . $fallback . '</div>';
			}
			$cards .= '<div class="download-card__body">';
			if ( '' !== $title ) {
				$cards .= '<h3 class="download-card__title">' . esc_html( $title ) . '</h3>';
			}
			if ( '' !== trim( (string) $it['description'] ) ) {
				$cards .= '<p class="download-card__desc">' . esc_html( $it['description'] ) . '</p>';
			}
			if ( '' !== $meta ) {
				$cards .= '<p class="download-card__meta">' . esc_html( $meta ) . '</p>';
			}
			$cards .= '<div class="download-card__actions"><a class="btn" href="' . esc_url( $url ) . '" download>' . corbuilder_icon_svg( 'download', 'btn__icon' ) . esc_html( $label ) . '</a></div>';
			$cards .= '</div></article>';
		}
		$class = 'download__grid' . ( ( 'auto' !== $cols && '' !== $cols ) ? ' download__grid--' . sanitize_html_class( $cols ) : '' );
		echo '<div class="' . esc_attr( $class ) . '">' . $cards . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
