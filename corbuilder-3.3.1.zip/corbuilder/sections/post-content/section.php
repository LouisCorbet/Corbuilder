<?php
/**
 * Section « Contenu de l'article » : le texte écrit dans l'éditeur de l'article.
 * Réservée au modèle des articles ; une seule par modèle.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Contenu de l’article', 'corbuilder' ),
	'description' => __( 'Emplacement du corps de l’article : le texte écrit dans l’éditeur WordPress ou, avec « Éditeur des articles : par sections » (Réglages du thème → Articles), les sections de chaque article. Sans cette section dans le modèle, le corps de l’article ne s’affiche pas (en mode sections, il suit alors l’en-tête).', 'corbuilder' ),
	'order'       => 2,
	'contexts'    => array( 'post' ),
	'unique'      => true,
	'end_button'  => false,
	'fields'      => array(
		'width' => array(
			'type'    => 'select',
			'label'   => __( 'Largeur du texte', 'corbuilder' ),
			'choices' => array(
				'narrow' => __( 'Étroite (confort de lecture)', 'corbuilder' ),
				'medium' => __( 'Moyenne', 'corbuilder' ),
				'wide'   => __( 'Large', 'corbuilder' ),
			),
			'default' => 'medium',
		),
	),
	'render'      => function ( $d ) {
		// the_content() gère les articles protégés par mot de passe, les extraits « Lire la suite », etc.
		ob_start();
		the_content();
		$html = ob_get_clean();
		ob_start();
		wp_link_pages();
		$pages = ob_get_clean();
		echo '<div class="post-content post-content--' . esc_attr( $d['width'] ) . ' entry-content">' . $html . $pages . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- rendu natif de WordPress
	},
);
