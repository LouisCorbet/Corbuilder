<?php get_header(); ?>
<div class="wrap content-area">
	<h1 class="page-title"><?php esc_html_e( 'Page introuvable', 'corbuilder' ); ?></h1>
	<p><?php esc_html_e( 'Cette page n’existe pas ou a été déplacée.', 'corbuilder' ); ?></p>
	<?php get_search_form(); ?>
</div>
<?php get_footer(); ?>
