<?php
/** Pied de page « Simple » : texte, coordonnées et réseaux à gauche, menu du pied de page à droite, liens légaux en dessous. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Simple', 'corbuilder' ),
	'description' => __( 'Texte, coordonnées et réseaux à gauche, menu à droite, liens légaux en bas.', 'corbuilder' ),
	'order'       => 10,
	'render'      => function () {
		echo '<footer class="site-footer footer--simple"><div class="wrap footer-inner"><div class="footer-about"><div class="footer-text">' . corbuilder_footer_text() . '</div>' . corbuilder_footer_contact_html() . corbuilder_footer_social_html() . '</div>' . corbuilder_footer_nav_html( 'footer' ) . '</div>' . corbuilder_footer_legal_bar() . '</footer>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
