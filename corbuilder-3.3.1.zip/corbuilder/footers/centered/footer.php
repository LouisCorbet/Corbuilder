<?php
/** Pied de page « Centré » : menu du pied de page, texte, coordonnées, réseaux et liens légaux, centrés. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Centré', 'corbuilder' ),
	'description' => __( 'Menu, texte, coordonnées, réseaux et liens légaux centrés, empilés.', 'corbuilder' ),
	'order'       => 30,
	'render'      => function () {
		echo '<footer class="site-footer footer--centered"><div class="wrap footer-inner">' . corbuilder_footer_nav_html( 'footer' ) . '<div class="footer-text">' . corbuilder_footer_text() . '</div>' . corbuilder_footer_contact_html() . corbuilder_footer_social_html() . '</div>' . corbuilder_footer_legal_bar() . '</footer>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
