<?php
/** Pied de page « Colonnes » : présentation et réseaux, coordonnées, puis un menu par colonne, liens légaux en bas. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Colonnes', 'corbuilder' ),
	'description' => __( 'Présentation, coordonnées et deux colonnes de menus (titres modifiables), liens légaux en bas.', 'corbuilder' ),
	'order'       => 20,
	'render'      => function () {
		$contact = corbuilder_footer_contact_html();
		$menu1   = corbuilder_footer_nav_html( 'footer', 2 );
		$menu2   = corbuilder_footer_nav_html( 'footer2', 2 );

		echo '<footer class="site-footer footer--columns"><div class="wrap footer-cols">';
		echo '<div class="footer-col">' . corbuilder_footer_col_title( 'footer_title_main', get_bloginfo( 'name' ) ) . '<div class="footer-text">' . corbuilder_footer_text() . '</div>' . corbuilder_footer_social_html() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $contact ) {
			echo '<div class="footer-col">' . corbuilder_footer_col_title( 'footer_title_contact' ) . $contact . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $menu1 ) {
			echo '<div class="footer-col">' . corbuilder_footer_col_title( 'footer_title_menu1' ) . $menu1 . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $menu2 ) {
			echo '<div class="footer-col">' . corbuilder_footer_col_title( 'footer_title_menu2' ) . $menu2 . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>' . corbuilder_footer_legal_bar() . '</footer>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
