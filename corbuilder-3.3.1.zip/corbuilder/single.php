<?php get_header(); ?>
<?php
$panel = corbuilder_get_post_template_panel(); // panneau latéral du modèle des articles (null : aucun)
corbuilder_panel_open( $panel );
while ( have_posts() ) :
	the_post();
	$sections = corbuilder_get_post_template_sections();

	if ( $sections ) : ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php
			// Sans section portant le H1, le titre de l'article reste présent pour l'accessibilité et le SEO.
			if ( ! corbuilder_sections_have_h1( $sections ) ) {
				echo '<h1 class="screen-reader-text">' . esc_html( get_the_title() ) . '</h1>';
			}
			corbuilder_render_post_template( get_the_ID() );
			?>
		</article>
	<?php else : // modèle vide : mise en page simple ?>
		<div class="wrap content-area">
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<?php get_template_part( 'template-parts/meta' ); ?>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-thumb"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
				</div>
			</article>
			<nav class="nav-links">
				<?php previous_post_link( '%link', '← %title' ); ?>
				<?php next_post_link( '%link', '%title →' ); ?>
			</nav>
			<?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
		</div>
	<?php endif;
endwhile;
corbuilder_panel_close( $panel );
?>
<?php get_footer(); ?>
