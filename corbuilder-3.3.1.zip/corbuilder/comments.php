<?php if ( post_password_required() ) { return; } ?>
<section id="comments" class="comments-area">
	<?php if ( have_comments() ) : ?>
		<h2><?php printf( esc_html( _n( '%d commentaire', '%d commentaires', get_comments_number(), 'corbuilder' ) ), (int) get_comments_number() ); ?></h2>
		<ol class="comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'avatar_size' => 40 ) ); ?></ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>
	<?php comment_form(); ?>
</section>
