<?php
/** Style « Éditorial » : titres en Playfair Display (police hébergée dans le thème). */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Éditorial', 'corbuilder' ),
	'description' => __( 'Titres en Playfair Display, filet fin, sous-titres en petites capitales.', 'corbuilder' ),
	'order'       => 20,
);
