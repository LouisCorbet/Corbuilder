<?php
/** Style « Moderne » : Poppins (police hébergée dans le thème), titres affirmés, sans filet. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Moderne', 'corbuilder' ),
	'description' => __( 'Poppins partout, grands titres affirmés, sous-titres en capitales, sans filet.', 'corbuilder' ),
	'order'       => 30,
);
