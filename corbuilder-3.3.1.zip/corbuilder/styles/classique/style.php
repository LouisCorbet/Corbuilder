<?php
/** Style « Classique » : polices système, titres sobres avec petit filet coloré. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Classique', 'corbuilder' ),
	'description' => __( 'Polices système, titres sobres soulignés d’un filet coloré. Le plus léger.', 'corbuilder' ),
	'order'       => 10,
);
