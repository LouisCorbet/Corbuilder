<?php
/** Style « Éditorial + Moderne » : H1 et H2 en Playfair Display (éditorial), H3 et le reste en Poppins (moderne). */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Éditorial + Moderne', 'corbuilder' ),
	'description' => __( 'Titres H1 et H2 en Playfair Display avec filet fin ; sous-titres, H3, texte, cartes et texte animé en Poppins.', 'corbuilder' ),
	'order'       => 40,
);
