<?php
/** En-tête « Appel à l’action » : disposition classique, liens du menu en boutons. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Appel à l’action', 'corbuilder' ),
	'description' => __( 'Logo à gauche, menu à droite ; le dernier lien du menu est mis en avant comme un bouton.', 'corbuilder' ),
	'order'       => 12,
	'buttons'     => 'last', // liens du 1er niveau affichés en boutons : last (le dernier) ou all (tous)
	'render'      => function () {
		echo '<header class="site-header header--classic header--cta"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html() . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
