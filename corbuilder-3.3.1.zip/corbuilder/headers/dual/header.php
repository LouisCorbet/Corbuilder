<?php
/** En-tête « Deux images » : seconde image à gauche, logo et nom au centre, menu à droite. */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'corbuilder_header_image2_html' ) ) {
	/* Seconde image choisie dans Réglages du thème > En-tête (vide si aucune) */
	function corbuilder_header_image2_html() {
		$id = absint( corbuilder_mod( 'header_image2' ) );
		return $id ? wp_get_attachment_image( $id, 'medium', false, array( 'class' => 'header__image' ) ) : '';
	}
}

return array(
	'label'        => __( 'Deux images', 'corbuilder' ),
	'description'  => __( 'Une seconde image à gauche, logo et nom au centre, menu à droite. La seconde image se choisit juste en dessous.', 'corbuilder' ),
	'order'        => 40,
	'second_image' => true, // affiche le champ « Seconde image de l'en-tête » dans le Customizer
	'render'       => function () {
		echo '<header class="site-header header--dual"><div class="wrap header-inner">'
			. '<div class="header__side">' . corbuilder_header_image2_html() . '</div>'
			. corbuilder_brand_html()
			. '<div class="header__nav">' . corbuilder_nav_html() . '</div>'
			. '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
