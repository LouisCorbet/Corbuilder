<?php
/** En-tête « Centré » : logo au centre, menu en dessous. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Centré', 'corbuilder' ),
	'description' => __( 'Logo au centre, menu centré en dessous.', 'corbuilder' ),
	'order'       => 20,
	'render'      => function () {
		echo '<header class="site-header header--centered"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html() . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
