<?php
/** En-tête « Menu centré » : logo et nom à gauche, menu au milieu, dernier lien du menu en bouton à droite. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Menu centré + bouton', 'corbuilder' ),
	'description' => __( 'Logo et nom à gauche, menu au milieu, et le dernier lien du menu mis en avant sous forme de bouton à droite.', 'corbuilder' ),
	'order'       => 15,
	'buttons'     => 'last', // le dernier lien du menu devient un bouton
	'render'      => function () {
		echo '<header class="site-header header--split"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html( true ) . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
