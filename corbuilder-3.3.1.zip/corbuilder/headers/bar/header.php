<?php
/** En-tête « Bandeau coloré » : fond de la couleur principale. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Bandeau coloré', 'corbuilder' ),
	'description' => __( 'Fond de la couleur principale, texte clair.', 'corbuilder' ),
	'order'       => 30,
	'render'      => function () {
		echo '<header class="site-header header--bar"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html() . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
