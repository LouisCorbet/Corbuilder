<?php
/** En-tête « Boutons » : disposition classique, liens du menu en boutons. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Boutons', 'corbuilder' ),
	'description' => __( 'Logo à gauche, menu à droite ; tous les liens du menu prennent le style des boutons.', 'corbuilder' ),
	'order'       => 13,
	'buttons'     => 'all', // liens du 1er niveau affichés en boutons : last (le dernier) ou all (tous)
	'render'      => function () {
		echo '<header class="site-header header--classic header--buttons"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html() . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
