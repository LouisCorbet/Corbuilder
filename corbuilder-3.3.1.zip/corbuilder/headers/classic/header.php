<?php
/** En-tête « Classique » : logo et nom à gauche, menu à droite. */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Classique', 'corbuilder' ),
	'description' => __( 'Logo à gauche, menu à droite.', 'corbuilder' ),
	'order'       => 10,
	'render'      => function () {
		echo '<header class="site-header header--classic"><div class="wrap header-inner">' . corbuilder_brand_html() . corbuilder_nav_html() . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
