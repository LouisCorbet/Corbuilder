<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * MODULES : un dossier par élément (sections, headers, footers, menus, styles),
 * découverts automatiquement dans le thème, puis dans le thème
 * enfant (qui peut ajouter ou remplacer un module du même nom).
 * ========================================================================= */

function corbuilder_module_roots( $folder ) {
	$roots = array( array( get_template_directory() . '/' . $folder, get_template_directory_uri() . '/' . $folder ) );
	if ( get_stylesheet_directory() !== get_template_directory() ) {
		$roots[] = array( get_stylesheet_directory() . '/' . $folder, get_stylesheet_directory_uri() . '/' . $folder );
	}
	return $roots;
}

/* Image d'aperçu d'un module : preview.png|jpg|webp|svg dans son dossier */
function corbuilder_module_preview( $dir, $uri ) {
	foreach ( array( 'png', 'jpg', 'jpeg', 'webp', 'svg' ) as $ext ) {
		if ( is_readable( $dir . '/preview.' . $ext ) ) {
			return $uri . '/preview.' . $ext;
		}
	}
	return '';
}

/* Liste brute des modules d'un dossier : id => file, dir, uri, preview */
function corbuilder_find_modules( $folder, $file ) {
	$found = array();
	foreach ( corbuilder_module_roots( $folder ) as $root ) {
		list( $base, $uri ) = $root;
		foreach ( (array) glob( $base . '/*', GLOB_ONLYDIR ) as $dir ) {
			if ( is_readable( $dir . '/' . $file ) ) {
				$mod_uri = $uri . '/' . basename( $dir );
				$found[ sanitize_key( basename( $dir ) ) ] = array(
					'file'    => $dir . '/' . $file,
					'dir'     => $dir,
					'uri'     => $mod_uri,
					'preview' => corbuilder_module_preview( $dir, $mod_uri ),
				);
			}
		}
	}
	return $found;
}

/* Charge les modules : chaque fichier retourne un tableau de définition */
function corbuilder_load_modules( $folder, $file, $required = array(), $defaults = array() ) {
	$out = array();
	foreach ( corbuilder_find_modules( $folder, $file ) as $id => $m ) {
		$def = include $m['file'];
		if ( ! is_array( $def ) ) {
			continue;
		}
		foreach ( (array) $required as $key ) {
			if ( empty( $def[ $key ] ) ) {
				continue 2;
			}
		}
		$def            = wp_parse_args( $def, array_merge( array(
			'label'       => $id,
			'description' => '',
			'order'       => 50,
			'requires'    => array(), // plugins nécessaires : slug => nom
		), $defaults ) );
		$def['id']      = $id;
		$def['dir']     = $m['dir'];
		$def['uri']     = $m['uri'];
		$def['preview'] = $m['preview'];
		$out[ $id ]     = $def;
	}
	uasort( $out, function ( $a, $b ) {
		return $a['order'] <=> $b['order'];
	} );
	return $out;
}

function corbuilder_get_headers() {
	static $c = null;
	return null !== $c ? $c : ( $c = corbuilder_load_modules( 'headers', 'header.php', array( 'render' ) ) );
}

function corbuilder_get_footers() {
	static $c = null;
	return null !== $c ? $c : ( $c = corbuilder_load_modules( 'footers', 'footer.php', array( 'render' ) ) );
}

function corbuilder_get_styles() {
	static $c = null;
	return null !== $c ? $c : ( $c = corbuilder_load_modules( 'styles', 'style.php' ) );
}

/* Animations : fichiers animations/<id>.css, nom lu dans « Name: … » */
function corbuilder_get_animations() {
	static $c = null;
	if ( null !== $c ) {
		return $c;
	}
	$c = array();
	foreach ( corbuilder_module_roots( 'animations' ) as $root ) {
		list( $base, $uri ) = $root;
		foreach ( (array) glob( $base . '/*.css' ) as $file ) {
			$id    = sanitize_key( basename( $file, '.css' ) );
			$head  = (string) file_get_contents( $file, false, null, 0, 300 );
			$label = preg_match( '/Name:\s*(.+?)\s*\*\//', $head, $m ) ? $m[1] : $id;
			$c[ $id ] = array( 'id' => $id, 'label' => $label, 'file' => $file, 'uri' => $uri . '/' . basename( $file ) );
		}
	}
	return $c;
}

/* Module actuellement choisi (style, header, footer) */
function corbuilder_selected( $kind ) {
	$map = array(
		'style'  => array( 'global_style', 'corbuilder_get_styles' ),
		'header' => array( 'header_style', 'corbuilder_get_headers' ),
		'footer' => array( 'footer_style', 'corbuilder_get_footers' ),
	);
	list( $key, $getter ) = $map[ $kind ];
	$all = call_user_func( $getter );
	$id  = corbuilder_mod( $key );
	if ( isset( $all[ $id ] ) ) {
		return $all[ $id ];
	}
	return $all ? reset( $all ) : null;
}

/* Fichier CSS propre à un module, chargé seulement s'il est choisi */
function corbuilder_enqueue_module_css( $handle, $def, $file ) {
	if ( $def && is_readable( $def['dir'] . '/' . $file ) ) {
		wp_enqueue_style( $handle, $def['uri'] . '/' . $file, array( 'corbuilder' ), CORBUILDER_VERSION );
	}
}

/* URL d'un fichier du thème (ou du thème enfant) à partir de son chemin */
function corbuilder_path_to_url( $path ) {
	$roots = array(
		get_stylesheet_directory() => get_stylesheet_directory_uri(),
		get_template_directory()   => get_template_directory_uri(),
	);
	foreach ( $roots as $dir => $uri ) {
		if ( 0 === strpos( $path, $dir ) ) {
			return $uri . substr( $path, strlen( $dir ) );
		}
	}
	return '';
}
