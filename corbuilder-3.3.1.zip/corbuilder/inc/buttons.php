<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * BOUTONS ET ICÔNES
 * Un champ « button » contient : label, url, new_tab, icon_type (none|library|media),
 * icon (nom dans /icons), icon_media (image de la médiathèque), icon_tint.
 * ========================================================================= */

function corbuilder_button_default() {
	return array(
		'label'      => '',
		'url'        => '',
		'new_tab'    => false,
		'icon_type'  => 'none',
		'icon'       => '',
		'icon_media' => 0,
		'icon_tint'  => false,
		'variant'    => 'default', // default (réglage du site) | solid | outline | text
	);
}

/* Bibliothèque : nom => chemin et URL (le thème enfant peut ajouter /icons) */
function corbuilder_icon_library() {
	static $lib = null;
	if ( null !== $lib ) {
		return $lib;
	}
	$lib = array();
	foreach ( corbuilder_module_roots( 'icons' ) as $root ) {
		list( $base, $uri ) = $root;
		foreach ( (array) glob( $base . '/*.svg' ) as $file ) {
			$slug         = sanitize_key( basename( $file, '.svg' ) );
			$lib[ $slug ] = array( 'slug' => $slug, 'file' => $file, 'url' => $uri . '/' . basename( $file ) );
		}
	}
	ksort( $lib );
	return $lib;
}

function corbuilder_sanitize_icon_slug( $value ) {
	$slug = sanitize_key( is_scalar( $value ) ? (string) $value : '' );
	$lib  = corbuilder_icon_library();
	return isset( $lib[ $slug ] ) ? $slug : '';
}

function corbuilder_sanitize_button( $value ) {
	$v    = is_array( $value ) ? $value : array();
	$type = ( isset( $v['icon_type'] ) && in_array( $v['icon_type'], array( 'library', 'media' ), true ) ) ? $v['icon_type'] : 'none';
	return array(
		'label'      => sanitize_text_field( isset( $v['label'] ) && is_scalar( $v['label'] ) ? (string) $v['label'] : '' ),
		'url'        => esc_url_raw( isset( $v['url'] ) && is_scalar( $v['url'] ) ? (string) $v['url'] : '' ),
		'new_tab'    => ! empty( $v['new_tab'] ),
		'icon_type'  => $type,
		'icon'       => corbuilder_sanitize_icon_slug( isset( $v['icon'] ) ? $v['icon'] : '' ),
		'icon_media' => absint( isset( $v['icon_media'] ) && is_scalar( $v['icon_media'] ) ? $v['icon_media'] : 0 ),
		'icon_tint'  => ! empty( $v['icon_tint'] ),
		'variant'    => ( isset( $v['variant'] ) && in_array( $v['variant'], array( 'solid', 'outline', 'text' ), true ) ) ? $v['variant'] : 'default',
	);
}

/* SVG de la bibliothèque, prêt à être inséré : taille en em, couleur du texte */
function corbuilder_icon_svg( $slug, $class = 'btn__icon' ) {
	static $cache = array();
	$cache_key = $slug . '|' . $class;
	if ( isset( $cache[ $cache_key ] ) ) {
		return $cache[ $cache_key ];
	}
	$lib = corbuilder_icon_library();
	if ( ! isset( $lib[ $slug ] ) ) {
		return '';
	}
	$svg = (string) file_get_contents( $lib[ $slug ]['file'] );
	$svg = preg_replace( '/<!--.*?-->/s', '', $svg );
	$svg = preg_replace_callback( '/<svg\b[^>]*>/s', function ( $m ) use ( $class ) {
		$tag = preg_replace( '/\s(width|height|class)="[^"]*"/', '', $m[0] );
		return preg_replace( '/<svg/', '<svg class="' . esc_attr( $class ) . '" aria-hidden="true" focusable="false"', $tag, 1 );
	}, $svg, 1 );
	$svg = trim( preg_replace( '/\s+/', ' ', $svg ) );
	$svg = str_replace( '> <', '><', preg_replace( '/\s+>/', '>', $svg ) );
	return $cache[ $cache_key ] = ( false !== strpos( $svg, '<svg' ) ) ? $svg : '';
}

function corbuilder_button_icon( $btn ) {
	if ( 'library' === $btn['icon_type'] && $btn['icon'] ) {
		return corbuilder_icon_svg( $btn['icon'] );
	}
	if ( 'media' === $btn['icon_type'] && $btn['icon_media'] ) {
		$url = wp_get_attachment_url( absint( $btn['icon_media'] ) );
		if ( ! $url ) {
			return '';
		}
		if ( $btn['icon_tint'] ) { // l'image sert de masque : elle prend la couleur du texte
			$style = "--icon:url('" . str_replace( "'", '%27', esc_url_raw( $url ) ) . "')";
			return '<span class="btn__icon btn__icon--mask" style="' . esc_attr( $style ) . '" aria-hidden="true"></span>';
		}
		return '<img class="btn__icon" src="' . esc_url( $url ) . '" alt="" aria-hidden="true">';
	}
	return '';
}

/* Bouton complet (chaîne vide si aucun texte) */
function corbuilder_button( $btn, $class = '' ) {
	$btn = wp_parse_args( is_array( $btn ) ? $btn : array(), corbuilder_button_default() );
	if ( '' === trim( (string) $btn['label'] ) ) {
		return '';
	}
	if ( in_array( $btn['variant'], array( 'solid', 'outline', 'text' ), true ) ) { // variante choisie : elle remplace le style secondaire d'origine
		$class = trim( str_replace( 'btn--secondary', '', (string) $class ) . ' btn--' . $btn['variant'] );
	}
	$html  = '<a class="btn' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" href="' . esc_url( $btn['url'] ? $btn['url'] : '#' ) . '"';
	$html .= $btn['new_tab'] ? ' target="_blank" rel="noopener"' : '';
	$html .= '>' . esc_html( $btn['label'] ) . corbuilder_button_icon( $btn ) . '</a>';
	return $html;
}

/* =========================================================================
 * ADRESSES VENUES DES CHAMPS PERSONNALISÉS DE L'ARTICLE
 * ========================================================================= */

/* Noms des champs personnalisés utilisés par les articles (hors champs internes, qui commencent par « _ ») */
function corbuilder_post_meta_keys() {
	static $keys = null;
	if ( null !== $keys ) {
		return $keys;
	}
	global $wpdb;
	$found = $wpdb->get_col( $wpdb->prepare(
		"SELECT DISTINCT pm.meta_key FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
		WHERE p.post_type = 'post' AND p.post_status NOT IN ( 'auto-draft', 'trash' ) AND pm.meta_key NOT LIKE %s
		ORDER BY pm.meta_key LIMIT 200",
		$wpdb->esc_like( '_' ) . '%'
	) );
	$keys = array_values( array_diff( array_map( 'strval', (array) $found ), array( 'enclosure', 'pingme' ) ) ); // champs techniques de WordPress sans « _ »
	$keys = (array) apply_filters( 'corbuilder_post_meta_keys', $keys );
	return $keys;
}

/* Choix « d'où vient l'adresse » d'un bouton : la valeur saisie dans le bouton, ou un champ personnalisé (valeur « meta:nom ») */
function corbuilder_button_source_choices() {
	$out = array( 'fixed' => __( 'Adresse saisie dans le bouton', 'corbuilder' ) );
	foreach ( corbuilder_post_meta_keys() as $key ) {
		$out[ 'meta:' . $key ] = sprintf( __( 'Champ personnalisé : %s', 'corbuilder' ), $key );
	}
	return $out;
}

/* Adresse contenue dans un champ personnalisé : texte, adresse e-mail, identifiant d'un fichier de la médiathèque ou lien (tableau avec « url », comme ACF) */
function corbuilder_post_meta_url( $pid, $key ) {
	$v = get_post_meta( (int) $pid, (string) $key, true );
	if ( is_array( $v ) ) {
		$v = isset( $v['url'] ) ? $v['url'] : '';
	}
	$v = is_scalar( $v ) ? trim( (string) $v ) : '';
	if ( '' === $v ) {
		return '';
	}
	if ( ctype_digit( $v ) ) {
		$file = wp_get_attachment_url( (int) $v );
		return $file ? esc_url_raw( $file ) : '';
	}
	if ( is_email( $v ) ) {
		return 'mailto:' . $v;
	}
	return esc_url_raw( $v );
}
