<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * MISES À JOUR DANS WORDPRESS
 * La plus récente version du fichier versions.json (réglé dans Apparence → Versions) est annoncée à WordPress : le thème apparaît
 * alors dans Apparence → Thèmes et Tableau de bord → Mises à jour avec le bouton « Mettre à jour maintenant ».
 * L'installation reste faite par WordPress ; trois contrôles s'y ajoutent, les mêmes que ceux du menu Versions :
 *  - avant le téléchargement : le zip est téléchargé par le thème, son empreinte SHA-256 et sa structure sont vérifiées ;
 *  - avant le remplacement du thème : les réglages du site sont sauvegardés (restauration dans Apparence → Versions).
 * Les mises à jour automatiques de WordPress ne sont pas activées par le thème.
 * ========================================================================= */

/* Version vérifiée par ce téléchargement-ci (null quand l'installation vient du menu Versions, qui fait déjà ces contrôles lui-même) */
function corbuilder_updates_state( $set = null ) {
	static $state = null;
	if ( null !== $set ) {
		$state = false === $set ? null : $set;
	}
	return $state;
}

/* Version la plus récente de la liste (null si l'adresse n'est pas réglée ou illisible) */
function corbuilder_updates_latest() {
	if ( '' === corbuilder_versions_url() ) {
		return null;
	}
	$list = corbuilder_versions_list();
	return ( is_wp_error( $list ) || empty( $list[0] ) ) ? null : $list[0];
}

/* 1. Annoncer la mise à jour à WordPress */
function corbuilder_updates_announce( $transient ) {
	if ( ! is_object( $transient ) || 'corbuilder' !== get_template() ) {
		return $transient;
	}
	$latest = corbuilder_updates_latest();
	if ( $latest && version_compare( $latest['version'], CORBUILDER_VERSION, '>' ) ) {
		$transient->response['corbuilder'] = array(
			'theme'        => 'corbuilder',
			'new_version'  => $latest['version'],
			'url'          => admin_url( 'themes.php?page=corbuilder-versions' ),
			'package'      => $latest['url'],
			'requires'     => '',
			'requires_php' => '',
		);
	} elseif ( isset( $transient->response['corbuilder'] ) ) {
		unset( $transient->response['corbuilder'] );
	}
	return $transient;
}
add_filter( 'pre_set_site_transient_update_themes', 'corbuilder_updates_announce' );

/* 2. Avant le téléchargement : le thème télécharge lui-même le zip et en vérifie l'empreinte et la structure */
function corbuilder_updates_pre_download( $reply, $package, $upgrader, $hook_extra = array() ) {
	// Un fichier local (installation depuis le menu Versions, déjà vérifiée par ce menu) n'est pas concerné
	if ( false !== $reply || empty( $hook_extra['theme'] ) || 'corbuilder' !== $hook_extra['theme'] || ! is_string( $package ) || ! preg_match( '#^https?://#i', $package ) ) {
		return $reply;
	}
	$entry  = null;
	$latest = corbuilder_updates_latest();
	if ( $latest && $latest['url'] === $package ) {
		$entry = $latest;
	}
	if ( ! $entry ) { // adresse inconnue de la liste : refusée
		return new WP_Error( 'corbuilder_package', __( 'Cette mise à jour ne vient pas de la liste des versions de Corbuilder : installation refusée.', 'corbuilder' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = download_url( $package, 120 );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	$hash = hash_file( 'sha256', $tmp );
	if ( ! $hash || ! hash_equals( $entry['sha256'], $hash ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
		return new WP_Error( 'corbuilder_hash', __( 'L’empreinte SHA-256 du zip ne correspond pas à celle du fichier versions.json : rien n’a été installé.', 'corbuilder' ) );
	}
	$check = corbuilder_versions_check_zip( $tmp, $entry['version'] );
	if ( is_wp_error( $check ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
		return $check;
	}
	corbuilder_updates_state( $entry );
	return $tmp; // WordPress installe ce fichier
}
add_filter( 'upgrader_pre_download', 'corbuilder_updates_pre_download', 10, 4 );

/* 3. Avant le remplacement du thème : sauvegarde des réglages (seulement pour un zip vérifié par le contrôle ci-dessus) */
function corbuilder_updates_pre_install( $response, $hook_extra = array() ) {
	$entry = corbuilder_updates_state();
	if ( $entry && ! empty( $hook_extra['theme'] ) && 'corbuilder' === $hook_extra['theme'] ) {
		corbuilder_versions_backup( $entry['version'] );
		corbuilder_updates_state( false );
	}
	return $response;
}
add_filter( 'upgrader_pre_install', 'corbuilder_updates_pre_install', 10, 2 );
