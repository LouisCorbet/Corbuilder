<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * VERSIONS DU THÈME : Apparence → Versions (réservé à ceux qui peuvent installer des thèmes : administrateurs)
 *
 * Le menu lit un fichier versions.json dont l'adresse se règle dans la page (voir README du dossier corbuilder-versions) :
 *   { "versions": [ { "version": "2.5.0", "file": "corbuilder-2.5.0.zip", "sha256": "…", "date": "…", "notes": [ … ] } ] }
 * Les zips se trouvent à côté du fichier : « file » est relatif à l'adresse du versions.json (le dossier est donc déplaçable).
 *
 * Installer une version : le zip est téléchargé, son empreinte SHA-256 et sa structure sont vérifiées, les réglages du site sont
 * sauvegardés (Restaurer, dans la page), puis le dossier du thème est remplacé avec le mécanisme de mise à jour de WordPress
 * (l'ancien dossier est conservé si l'installation échoue).
 * ========================================================================= */

/* ---------- Réglage : adresse du versions.json ---------- */

function corbuilder_versions_url() {
	return (string) get_option( 'corbuilder_versions_url', '' );
}

function corbuilder_versions_allowed_protocols() {
	return in_array( wp_get_environment_type(), array( 'local', 'development' ), true ) ? array( 'https', 'http' ) : array( 'https' );
}

/* ---------- Lecture de la liste ---------- */

/* Adresse d'un zip : celle du dossier qui contient le versions.json, suivie du nom du fichier */
function corbuilder_versions_file_url( $list_url, $file ) {
	$p = wp_parse_url( $list_url );
	if ( empty( $p['scheme'] ) || empty( $p['host'] ) ) {
		return '';
	}
	$path = isset( $p['path'] ) ? $p['path'] : '/';
	$dir  = substr( $path, 0, (int) strrpos( $path, '/' ) + 1 );
	return $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' ) . $dir . rawurlencode( $file );
}

/* Contrôle du contenu du fichier et mise en forme : versions les plus récentes d'abord. Une entrée invalide est ignorée. */
function corbuilder_versions_parse( $body, $list_url ) {
	$data = json_decode( (string) $body, true );
	if ( ! is_array( $data ) || empty( $data['versions'] ) || ! is_array( $data['versions'] ) ) {
		return new WP_Error( 'corbuilder_versions_format', __( 'Le fichier ne contient pas de liste de versions valide.', 'corbuilder' ) );
	}
	$list = array();
	foreach ( $data['versions'] as $v ) {
		if ( ! is_array( $v ) || empty( $v['version'] ) || empty( $v['file'] ) || empty( $v['sha256'] ) ) {
			continue;
		}
		$version = (string) $v['version'];
		$file    = (string) $v['file'];
		$sha     = strtolower( (string) $v['sha256'] );
		// Nommage imposé : corbuilder-x.y.z.zip, dans le même dossier que le versions.json, et empreinte de 64 caractères hexadécimaux
		if ( ! preg_match( '/^\d+\.\d+\.\d+$/', $version ) || 'corbuilder-' . $version . '.zip' !== $file || ! preg_match( '/^[a-f0-9]{64}$/', $sha ) ) {
			continue;
		}
		$notes = array();
		foreach ( array_slice( ( isset( $v['notes'] ) && is_array( $v['notes'] ) ) ? $v['notes'] : array(), 0, 20 ) as $note ) {
			if ( is_string( $note ) && '' !== trim( $note ) ) {
				$notes[] = sanitize_text_field( $note );
			}
		}
		$list[ $version ] = array(
			'version' => $version,
			'file'    => $file,
			'url'     => corbuilder_versions_file_url( $list_url, $file ),
			'sha256'  => $sha,
			'date'    => isset( $v['date'] ) ? sanitize_text_field( (string) $v['date'] ) : '',
			'notes'   => $notes,
		);
	}
	if ( ! $list ) {
		return new WP_Error( 'corbuilder_versions_empty', __( 'Aucune version utilisable dans le fichier (nom de zip au format corbuilder-x.y.z.zip, empreinte SHA-256 de 64 caractères).', 'corbuilder' ) );
	}
	uksort( $list, function ( $a, $b ) {
		return version_compare( $b, $a );
	} );
	return array_values( $list );
}

/* Liste des versions (gardée 6 h) ; $force : relit le fichier */
function corbuilder_versions_list( $force = false ) {
	$url = corbuilder_versions_url();
	if ( '' === $url ) {
		return new WP_Error( 'corbuilder_versions_nourl', __( 'Aucune adresse n’est réglée : indique l’adresse du fichier versions.json.', 'corbuilder' ) );
	}
	$key = 'corbuilder_versions_' . md5( $url );
	if ( ! $force ) {
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}
	$res = wp_safe_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3, 'headers' => array( 'Accept' => 'application/json' ) ) );
	if ( is_wp_error( $res ) ) {
		/* translators: %s : message d'erreur */
		return new WP_Error( 'corbuilder_versions_http', sprintf( __( 'Impossible de lire la liste des versions : %s', 'corbuilder' ), $res->get_error_message() ) );
	}
	if ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		/* translators: %d : code HTTP */
		return new WP_Error( 'corbuilder_versions_http', sprintf( __( 'Impossible de lire la liste des versions (réponse du serveur : %d).', 'corbuilder' ), (int) wp_remote_retrieve_response_code( $res ) ) );
	}
	$list = corbuilder_versions_parse( wp_remote_retrieve_body( $res ), $url );
	if ( is_wp_error( $list ) ) {
		return $list;
	}
	set_transient( $key, $list, 6 * HOUR_IN_SECONDS );
	return $list;
}

/* ---------- Sauvegarde des réglages avant une installation ---------- */

function corbuilder_versions_backups() {
	$b = get_option( 'corbuilder_versions_backups', array() );
	return is_array( $b ) ? $b : array();
}

/* Les 5 dernières sauvegardes sont gardées (réglages du thème : couleurs, styles, sections de toutes les pages, menus…).
   Elles sont dans la base de données, pas dans un dossier accessible depuis internet. */
function corbuilder_versions_backup( $to_version ) {
	$backups   = corbuilder_versions_backups();
	$backups[] = array(
		'time'         => time(),
		'from'         => CORBUILDER_VERSION,
		'to'           => $to_version,
		'data_version' => (string) get_option( 'corbuilder_data_version', '' ),
		'mods'         => (array) get_theme_mods(),
	);
	update_option( 'corbuilder_versions_backups', array_slice( $backups, -5 ), false );
}

/* ---------- Contrôle du zip ---------- */

function corbuilder_versions_check_zip( $file, $version ) {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'L’extension PHP « zip » n’est pas disponible sur ce serveur.', 'corbuilder' ) );
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $file ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'Le fichier téléchargé n’est pas un zip lisible.', 'corbuilder' ) );
	}
	for ( $i = 0; $i < $zip->numFiles; $i++ ) {
		$name = (string) $zip->getNameIndex( $i );
		if ( 0 !== strpos( $name, 'corbuilder/' ) || false !== strpos( $name, '..' ) ) {
			$zip->close();
			return new WP_Error( 'corbuilder_zip', __( 'Le zip doit contenir un seul dossier « corbuilder » à sa racine.', 'corbuilder' ) );
		}
	}
	$style = $zip->getFromName( 'corbuilder/style.css', 8192 );
	$funcs = $zip->locateName( 'corbuilder/functions.php' );
	$zip->close();
	if ( false === $style || false === $funcs ) {
		return new WP_Error( 'corbuilder_zip', __( 'Le zip ne contient pas un thème Corbuilder complet (style.css et functions.php).', 'corbuilder' ) );
	}
	if ( ! preg_match( '/^[ \t\/*#@]*Version:\s*(\S+)/mi', $style, $m ) || $m[1] !== $version ) {
		/* translators: 1 : version annoncée, 2 : version trouvée dans le zip */
		return new WP_Error( 'corbuilder_zip', sprintf( __( 'Le zip ne contient pas la version %1$s annoncée (version trouvée : %2$s).', 'corbuilder' ), $version, isset( $m[1] ) ? $m[1] : '?' ) );
	}
	return true;
}

/* ---------- Installation ---------- */

function corbuilder_versions_install( $entry ) {
	if ( ! current_user_can( 'install_themes' ) ) {
		return new WP_Error( 'corbuilder_cap', __( 'Accès refusé.', 'corbuilder' ) );
	}
	if ( 'corbuilder' !== get_template() ) {
		/* translators: %s : nom du dossier du thème */
		return new WP_Error( 'corbuilder_dir', sprintf( __( 'Le dossier du thème actif s’appelle « %s » : l’installation exige qu’il s’appelle « corbuilder ».', 'corbuilder' ), get_template() ) );
	}
	if ( function_exists( 'wp_is_file_mod_allowed' ) && ! wp_is_file_mod_allowed( 'corbuilder_versions' ) ) {
		return new WP_Error( 'corbuilder_mods', __( 'Ce site interdit la modification de fichiers (DISALLOW_FILE_MODS).', 'corbuilder' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

	$tmp = download_url( $entry['url'], 120 );
	if ( is_wp_error( $tmp ) ) {
		/* translators: %s : message d'erreur */
		return new WP_Error( 'corbuilder_download', sprintf( __( 'Téléchargement impossible : %s', 'corbuilder' ), $tmp->get_error_message() ) );
	}
	$hash = hash_file( 'sha256', $tmp );
	if ( ! $hash || ! hash_equals( $entry['sha256'], $hash ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
		return new WP_Error( 'corbuilder_hash', __( 'L’empreinte SHA-256 du zip ne correspond pas à celle du fichier versions.json : rien n’a été installé.', 'corbuilder' ) );
	}
	$check = corbuilder_versions_check_zip( $tmp, $entry['version'] );
	if ( is_wp_error( $check ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
		return $check;
	}

	corbuilder_versions_backup( $entry['version'] );

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$upgrader->init();
	$upgrader->upgrade_strings();
	$root   = get_theme_root( 'corbuilder' );
	$result = $upgrader->run( array(
		'package'           => $tmp,
		'destination'       => $root,
		'clear_destination' => true,
		'clear_working'     => true,
		'hook_extra'        => array(
			'theme'       => 'corbuilder',
			'type'        => 'theme',
			'action'      => 'update',
			'temp_backup' => array( 'slug' => 'corbuilder', 'src' => $root, 'dir' => 'themes' ), // l'ancien dossier revient si l'installation échoue (WordPress 6.3 et plus)
		),
	) );
	@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	if ( ! $result ) {
		$messages = array_filter( array_map( 'wp_strip_all_tags', (array) $skin->get_upgrade_messages() ) );
		return new WP_Error( 'corbuilder_install', __( 'L’installation a échoué.', 'corbuilder' ) . ( $messages ? ' ' . implode( ' ', array_slice( $messages, -3 ) ) : '' ) );
	}
	wp_clean_themes_cache();
	if ( function_exists( 'wp_opcache_invalidate_directory' ) ) {
		wp_opcache_invalidate_directory( trailingslashit( $root ) . 'corbuilder' );
	}
	return true;
}

/* ---------- Page et formulaires ---------- */

function corbuilder_versions_menu() {
	add_theme_page( __( 'Versions de Corbuilder', 'corbuilder' ), __( 'Versions', 'corbuilder' ), 'install_themes', 'corbuilder-versions', 'corbuilder_versions_page' );
}
add_action( 'admin_menu', 'corbuilder_versions_menu' );

function corbuilder_versions_back( $notice ) {
	set_transient( 'corbuilder_versions_notice_' . get_current_user_id(), $notice, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'themes.php?page=corbuilder-versions' ) );
	exit;
}

function corbuilder_versions_guard( $action ) {
	if ( ! current_user_can( 'install_themes' ) ) {
		wp_die( esc_html__( 'Accès refusé.', 'corbuilder' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( $action );
}

function corbuilder_versions_save_url_request() {
	corbuilder_versions_guard( 'corbuilder_versions_url' );
	$raw = isset( $_POST['corbuilder_versions_url'] ) ? trim( (string) wp_unslash( $_POST['corbuilder_versions_url'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$url = '' === $raw ? '' : esc_url_raw( $raw, corbuilder_versions_allowed_protocols() );
	if ( '' !== $raw && '' === $url ) {
		corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( __( 'Adresse refusée : elle doit commencer par https://.', 'corbuilder' ) ) ) );
	}
	update_option( 'corbuilder_versions_url', $url, false );
	corbuilder_versions_back( array( 'type' => 'success', 'lines' => array( '' === $url ? __( 'Adresse retirée.', 'corbuilder' ) : __( 'Adresse enregistrée.', 'corbuilder' ) ) ) );
}
add_action( 'admin_post_corbuilder_versions_save_url', 'corbuilder_versions_save_url_request' );

function corbuilder_versions_refresh_request() {
	corbuilder_versions_guard( 'corbuilder_versions_refresh' );
	$list = corbuilder_versions_list( true );
	if ( is_wp_error( $list ) ) {
		corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( $list->get_error_message() ) ) );
	}
	delete_site_transient( 'update_themes' ); // WordPress refait son contrôle des mises à jour au prochain affichage
	/* translators: %d : nombre de versions */
	corbuilder_versions_back( array( 'type' => 'success', 'lines' => array( sprintf( _n( 'Liste actualisée : %d version.', 'Liste actualisée : %d versions.', count( $list ), 'corbuilder' ), count( $list ) ) ) ) );
}
add_action( 'admin_post_corbuilder_versions_refresh', 'corbuilder_versions_refresh_request' );

function corbuilder_versions_install_request() {
	corbuilder_versions_guard( 'corbuilder_versions_install' );
	$wanted = isset( $_POST['version'] ) ? sanitize_text_field( wp_unslash( $_POST['version'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$list   = corbuilder_versions_list( true ); // liste à jour au moment d'installer
	if ( is_wp_error( $list ) ) {
		corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( $list->get_error_message() ) ) );
	}
	$entry = null;
	foreach ( $list as $e ) {
		if ( $e['version'] === $wanted ) {
			$entry = $e;
		}
	}
	if ( ! $entry ) {
		corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( __( 'Cette version n’est pas dans la liste.', 'corbuilder' ) ) ) );
	}
	$res = corbuilder_versions_install( $entry );
	if ( is_wp_error( $res ) ) {
		corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( $res->get_error_message() ) ) );
	}
	/* translators: %s : numéro de version */
	corbuilder_versions_back( array( 'type' => 'success', 'lines' => array( sprintf( __( 'Version %s installée. Les réglages précédents ont été sauvegardés (bas de cette page).', 'corbuilder' ), $entry['version'] ) ) ) );
}
add_action( 'admin_post_corbuilder_versions_install', 'corbuilder_versions_install_request' );

/* Remet les réglages d'une sauvegarde (ceux qui étaient en place avant l'installation) */
function corbuilder_versions_restore_request() {
	corbuilder_versions_guard( 'corbuilder_versions_restore' );
	$time = isset( $_POST['time'] ) ? absint( $_POST['time'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( corbuilder_versions_backups() as $b ) {
		if ( isset( $b['time'], $b['mods'] ) && (int) $b['time'] === $time && is_array( $b['mods'] ) ) {
			update_option( 'theme_mods_' . get_option( 'stylesheet' ), $b['mods'] );
			if ( '' === (string) $b['data_version'] ) {
				delete_option( 'corbuilder_data_version' );
			} else {
				update_option( 'corbuilder_data_version', $b['data_version'] );
			}
			corbuilder_versions_back( array( 'type' => 'success', 'lines' => array( __( 'Réglages restaurés.', 'corbuilder' ) ) ) );
		}
	}
	corbuilder_versions_back( array( 'type' => 'error', 'lines' => array( __( 'Sauvegarde introuvable.', 'corbuilder' ) ) ) );
}
add_action( 'admin_post_corbuilder_versions_restore', 'corbuilder_versions_restore_request' );

function corbuilder_versions_page() {
	$key    = 'corbuilder_versions_notice_' . get_current_user_id();
	$notice = get_transient( $key );
	delete_transient( $key );
	$url  = corbuilder_versions_url();
	$list = '' === $url ? null : corbuilder_versions_list();
	$post = esc_url( admin_url( 'admin-post.php' ) );

	$problems = array();
	if ( 'corbuilder' !== get_template() ) {
		/* translators: %s : nom du dossier du thème */
		$problems[] = sprintf( __( 'Le dossier du thème actif s’appelle « %s » : il doit s’appeler « corbuilder » pour installer une version.', 'corbuilder' ), get_template() );
	}
	if ( function_exists( 'wp_is_file_mod_allowed' ) && ! wp_is_file_mod_allowed( 'corbuilder_versions' ) ) {
		$problems[] = __( 'Ce site interdit la modification de fichiers : l’installation est impossible.', 'corbuilder' );
	}
	if ( ! class_exists( 'ZipArchive' ) ) {
		$problems[] = __( 'L’extension PHP « zip » est absente : l’installation est impossible.', 'corbuilder' );
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Versions de Corbuilder', 'corbuilder' ); ?></h1>
		<p>
			<?php
			/* translators: %s : numéro de version */
			echo esc_html( sprintf( __( 'Version installée : %s.', 'corbuilder' ), CORBUILDER_VERSION ) );
			?>
		</p>

		<?php if ( is_array( $notice ) ) : ?>
			<div class="notice notice-<?php echo 'success' === $notice['type'] ? 'success' : 'error'; ?>">
				<?php foreach ( $notice['lines'] as $line ) : ?>
					<p><?php echo esc_html( $line ); ?></p>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php foreach ( $problems as $p ) : ?>
			<div class="notice notice-warning"><p><?php echo esc_html( $p ); ?></p></div>
		<?php endforeach; ?>

		<h2><?php esc_html_e( 'Source des versions', 'corbuilder' ); ?></h2>
		<form method="post" action="<?php echo $post; // phpcs:ignore WordPress.Security.EscapeOutput ?>">
			<input type="hidden" name="action" value="corbuilder_versions_save_url">
			<?php wp_nonce_field( 'corbuilder_versions_url' ); ?>
			<p>
				<label for="corbuilder_versions_url"><?php esc_html_e( 'Adresse du fichier versions.json', 'corbuilder' ); ?></label><br>
				<input type="url" id="corbuilder_versions_url" name="corbuilder_versions_url" class="large-text code" value="<?php echo esc_attr( $url ); ?>" placeholder="https://exemple.fr/corbuilder-versions/versions.json">
			</p>
			<p class="description"><?php esc_html_e( 'Les zips doivent se trouver dans le même dossier que ce fichier. Une version installée remplace le thème sur ce site : n’indique qu’une adresse en laquelle tu as confiance.', 'corbuilder' ); ?></p>
			<?php submit_button( __( 'Enregistrer l’adresse', 'corbuilder' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php if ( '' !== $url ) : ?>
			<form method="post" action="<?php echo $post; // phpcs:ignore WordPress.Security.EscapeOutput ?>" style="margin-top:8px">
				<input type="hidden" name="action" value="corbuilder_versions_refresh">
				<?php wp_nonce_field( 'corbuilder_versions_refresh' ); ?>
				<?php submit_button( __( 'Actualiser la liste', 'corbuilder' ), 'secondary', 'submit', false ); ?>
			</form>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Versions disponibles', 'corbuilder' ); ?></h2>
		<?php if ( null === $list ) : ?>
			<p><?php esc_html_e( 'Indique l’adresse du fichier versions.json pour voir les versions.', 'corbuilder' ); ?></p>
		<?php elseif ( is_wp_error( $list ) ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( $list->get_error_message() ); ?></p></div>
		<?php else : ?>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Version', 'corbuilder' ); ?></th>
					<th><?php esc_html_e( 'Date', 'corbuilder' ); ?></th>
					<th><?php esc_html_e( 'Notes', 'corbuilder' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php
				foreach ( $list as $e ) :
					$cmp = version_compare( $e['version'], CORBUILDER_VERSION );
					if ( 0 === $cmp ) {
						$label = __( 'Réinstaller', 'corbuilder' );
					} elseif ( $cmp > 0 ) {
						$label = __( 'Installer (mise à jour)', 'corbuilder' );
					} else {
						$label = __( 'Installer (version antérieure)', 'corbuilder' );
					}
					/* translators: 1 : version à installer, 2 : version actuelle */
					$confirm = sprintf( __( 'Installer la version %1$s ? Elle remplace la version actuelle (%2$s). Les réglages du site sont sauvegardés avant.', 'corbuilder' ), $e['version'], CORBUILDER_VERSION );
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $e['version'] ); ?></strong>
							<?php if ( 0 === $cmp ) : ?>
								<span class="dashicons dashicons-yes-alt" title="<?php esc_attr_e( 'Version installée', 'corbuilder' ); ?>"></span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $e['date'] ); ?></td>
						<td>
							<?php foreach ( $e['notes'] as $n ) : ?>
								<div>• <?php echo esc_html( $n ); ?></div>
							<?php endforeach; ?>
						</td>
						<td>
							<form method="post" action="<?php echo $post; // phpcs:ignore WordPress.Security.EscapeOutput ?>" onsubmit="return confirm('<?php echo esc_js( $confirm ); ?>');">
								<input type="hidden" name="action" value="corbuilder_versions_install">
								<input type="hidden" name="version" value="<?php echo esc_attr( $e['version'] ); ?>">
								<?php wp_nonce_field( 'corbuilder_versions_install' ); ?>
								<button type="submit" class="button<?php echo $cmp > 0 ? ' button-primary' : ''; ?>"<?php disabled( ! empty( $problems ) ); ?>><?php echo esc_html( $label ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Installer une version remplace les fichiers du thème (toute modification faite à la main dans le dossier du thème est perdue). Les pages, les médias et les réglages restent en place, et les réglages sont sauvegardés avant chaque installation.', 'corbuilder' ); ?></p>
		<?php endif; ?>

		<?php $backups = array_reverse( corbuilder_versions_backups() ); ?>
		<?php if ( $backups ) : ?>
			<h2><?php esc_html_e( 'Sauvegardes des réglages', 'corbuilder' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Une sauvegarde est faite avant chaque installation (les 5 dernières sont gardées). Installer une ancienne version ne défait pas les conversions de données faites par une version plus récente : restaure alors la sauvegarde d’avant.', 'corbuilder' ); ?></p>
			<table class="widefat striped">
				<tbody>
				<?php foreach ( $backups as $b ) : ?>
					<tr>
						<td>
							<?php
							/* translators: 1 : date, 2 : version avant, 3 : version installée */
							echo esc_html( sprintf( __( '%1$s : avant le passage de la version %2$s à la version %3$s', 'corbuilder' ), wp_date( 'd/m/Y H:i', (int) $b['time'] ), $b['from'], $b['to'] ) );
							?>
						</td>
						<td>
							<form method="post" action="<?php echo $post; // phpcs:ignore WordPress.Security.EscapeOutput ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Remplacer les réglages actuels du site par ceux de cette sauvegarde ?', 'corbuilder' ) ); ?>');">
								<input type="hidden" name="action" value="corbuilder_versions_restore">
								<input type="hidden" name="time" value="<?php echo (int) $b['time']; ?>">
								<?php wp_nonce_field( 'corbuilder_versions_restore' ); ?>
								<button type="submit" class="button"><?php esc_html_e( 'Restaurer ces réglages', 'corbuilder' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
	<?php
}
