<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * PLUGINS REQUIS : chaque module (section, composition, en-tête, pied de page,
 * style) peut déclarer 'requires' => array( 'slug-du-plugin' => 'Nom' ).
 * La page Apparence → Plugins requis liste ceux qui manquent.
 * ========================================================================= */

function corbuilder_required_plugins() {
	$sources = array(
		__( 'Section', 'corbuilder' )        => corbuilder_get_sections(),
		__( 'En-tête', 'corbuilder' )        => corbuilder_get_headers(),
		__( 'Pied de page', 'corbuilder' )   => corbuilder_get_footers(),
		__( 'Style', 'corbuilder' )          => corbuilder_get_styles(),
	);
	$out = array();
	foreach ( $sources as $kind => $modules ) {
		foreach ( $modules as $module ) {
			foreach ( (array) $module['requires'] as $slug => $name ) {
				$slug = sanitize_key( $slug );
				if ( ! isset( $out[ $slug ] ) ) {
					$out[ $slug ] = array( 'name' => $name, 'used_by' => array() );
				}
				$out[ $slug ]['used_by'][] = $kind . ' « ' . $module['label'] . ' »';
			}
		}
	}
	return $out;
}

/* array( 'active'|'inactive'|'missing', fichier principal du plugin ) */
function corbuilder_plugin_status( $slug ) {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	foreach ( get_plugins() as $file => $info ) {
		if ( 0 === strpos( $file, $slug . '/' ) ) {
			return array( is_plugin_active( $file ) ? 'active' : 'inactive', $file );
		}
	}
	return array( 'missing', '' );
}

function corbuilder_requirements_menu() {
	add_theme_page( __( 'Plugins requis', 'corbuilder' ), __( 'Plugins requis', 'corbuilder' ), 'edit_theme_options', 'corbuilder-plugins', 'corbuilder_requirements_page' );
}
add_action( 'admin_menu', 'corbuilder_requirements_menu' );

function corbuilder_requirements_page() {
	$plugins = corbuilder_required_plugins();
	echo '<div class="wrap"><h1>' . esc_html__( 'Plugins requis par le thème', 'corbuilder' ) . '</h1>';
	echo '<p>' . esc_html__( 'Certaines sections ou compositions ont besoin d’un plugin pour fonctionner. Voici l’état de chacun.', 'corbuilder' ) . '</p>';

	if ( ! $plugins ) {
		echo '<p>' . esc_html__( 'Aucun plugin n’est requis pour l’instant.', 'corbuilder' ) . '</p></div>';
		return;
	}

	echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Plugin', 'corbuilder' ) . '</th><th>' . esc_html__( 'Nécessaire pour', 'corbuilder' ) . '</th><th>' . esc_html__( 'État', 'corbuilder' ) . '</th><th></th></tr></thead><tbody>';
	foreach ( $plugins as $slug => $plugin ) {
		list( $status, $file ) = corbuilder_plugin_status( $slug );
		$labels = array(
			'active'   => __( 'Actif', 'corbuilder' ),
			'inactive' => __( 'Installé, non activé', 'corbuilder' ),
			'missing'  => __( 'Manquant', 'corbuilder' ),
		);
		$action = '';
		if ( 'missing' === $status && current_user_can( 'install_plugins' ) ) {
			$url    = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . $slug ), 'install-plugin_' . $slug );
			$action = '<a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Installer', 'corbuilder' ) . '</a>';
		} elseif ( 'inactive' === $status && current_user_can( 'activate_plugins' ) ) {
			$url    = wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( $file ) ), 'activate-plugin_' . $file );
			$action = '<a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Activer', 'corbuilder' ) . '</a>';
		}
		echo '<tr><td><strong>' . esc_html( $plugin['name'] ) . '</strong></td><td>' . esc_html( implode( ', ', $plugin['used_by'] ) ) . '</td><td>' . esc_html( $labels[ $status ] ) . '</td><td>' . $action . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- boutons construits ci-dessus
	}
	echo '</tbody></table>';
	echo '<p class="description">' . esc_html__( 'L’installation en un clic fonctionne pour les plugins du répertoire officiel WordPress. Les plugins payants s’installent à la main.', 'corbuilder' ) . '</p></div>';
}
