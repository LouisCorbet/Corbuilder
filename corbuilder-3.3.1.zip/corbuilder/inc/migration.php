<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * REPRISE DES RÉGLAGES DE L'ANCIEN THÈME « LÉGER »
 * WordPress range les réglages d'un thème sous le nom de son dossier : Corbuilder démarrerait donc vide.
 * À l'activation (ou avec le bouton d'Apparence → Export / import), on copie vers Corbuilder les réglages de
 * Léger : couleurs, styles, menus, CSS additionnel et sections de toutes les pages. Les clés qui portaient
 * l'ancien nom (leger_p12_sections) sont renommées. L'ancien thème n'est jamais modifié.
 * ========================================================================= */

function corbuilder_old_theme_mods() {
	$mods = get_option( 'theme_mods_leger' );
	return ( is_array( $mods ) && $mods ) ? $mods : array();
}

/* Réglages de l'ancien thème, avec les clés renommées */
function corbuilder_renamed_mods( $old ) {
	$new = array();
	foreach ( $old as $key => $value ) {
		if ( 'custom_css_post_id' === $key ) {
			continue; // le CSS additionnel est repris à part
		}
		if ( preg_match( '/^leger_p(\d+)_sections$/', (string) $key, $m ) ) {
			$key = 'corbuilder_p' . $m[1] . '_sections';
		} elseif ( 'leger_post_template_sections' === $key ) {
			$key = 'corbuilder_post_template_sections';
		}
		$new[ $key ] = $value;
	}
	return $new;
}

/* Copie les réglages de Léger vers le thème actif. $overwrite : les valeurs de Léger remplacent celles déjà présentes (bouton manuel).
   Retourne le nombre de réglages repris, ou false s'il n'y a rien à reprendre. */
function corbuilder_migrate_from_leger( $overwrite = false ) {
	$slug = get_option( 'stylesheet' );
	$old  = corbuilder_old_theme_mods();
	if ( ! $old || 'leger' === $slug ) {
		return false;
	}
	$current = get_option( 'theme_mods_' . $slug );
	$current = is_array( $current ) ? $current : array();
	// Hors réglages que WordPress crée tout seul à l'activation, le thème est-il encore vide ?
	$own = array_diff_key( $current, array_flip( array( 'nav_menu_locations', 'sidebars_widgets', 0 ) ) );
	if ( $own && ! $overwrite ) {
		return false; // Corbuilder a déjà ses propres réglages : on n'y touche pas
	}
	$mods = corbuilder_renamed_mods( $old );
	$new  = $overwrite ? array_merge( $current, $mods ) : array_merge( $mods, $own ? $own : array() );
	if ( isset( $current['nav_menu_locations'] ) && ! isset( $mods['nav_menu_locations'] ) ) {
		$new['nav_menu_locations'] = $current['nav_menu_locations'];
	}
	update_option( 'theme_mods_' . $slug, $new );

	// CSS additionnel : il est rattaché au nom du dossier du thème
	$css_post = get_posts( array( 'post_type' => 'custom_css', 'name' => 'leger', 'post_status' => 'any', 'numberposts' => 1 ) );
	if ( $css_post && '' !== trim( (string) $css_post[0]->post_content ) && ( $overwrite || '' === trim( (string) wp_get_custom_css() ) ) ) {
		wp_update_custom_css_post( $css_post[0]->post_content, array( 'stylesheet' => $slug ) );
	}
	update_option( 'corbuilder_migrated_from_leger', time(), false );
	return count( $mods );
}

/* À l'activation : reprise automatique, une seule fois */
function corbuilder_migrate_on_switch() {
	if ( get_option( 'corbuilder_migrated_from_leger' ) ) {
		return;
	}
	if ( false !== corbuilder_migrate_from_leger( false ) ) {
		set_transient( 'corbuilder_migrated_notice', 1, 10 * MINUTE_IN_SECONDS );
	}
}
add_action( 'after_switch_theme', 'corbuilder_migrate_on_switch' );

function corbuilder_migration_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) || ! get_transient( 'corbuilder_migrated_notice' ) ) {
		return;
	}
	delete_transient( 'corbuilder_migrated_notice' );
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Corbuilder a repris les réglages, les menus et les sections de toutes les pages de l’ancien thème Léger. Léger n’a pas été modifié : tu pourras le supprimer quand tu auras vérifié ton site.', 'corbuilder' ) . '</p></div>';
}
add_action( 'admin_notices', 'corbuilder_migration_notice' );

/* Bouton manuel (Apparence → Export / import) */
function corbuilder_migrate_request() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accès refusé.', 'corbuilder' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'corbuilder_migrate' );
	$count = corbuilder_migrate_from_leger( true );
	corbuilder_transfer_back( false === $count
		? array( 'type' => 'error', 'lines' => array( __( 'Aucun réglage de Léger à reprendre.', 'corbuilder' ) ) )
		/* translators: %d: nombre de réglages */
		: array( 'type' => 'success', 'lines' => array( sprintf( __( 'Réglages de Léger repris : %d réglages (couleurs, styles, menus, sections des pages, CSS additionnel).', 'corbuilder' ), $count ) ) ) );
}
add_action( 'admin_post_corbuilder_migrate', 'corbuilder_migrate_request' );
