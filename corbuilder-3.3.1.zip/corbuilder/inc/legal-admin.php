<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * BROUILLONS DISPONIBLES (administration) : Apparence → Brouillons disponibles.
 * Crée des BROUILLONS de pages à partir des modèles du thème (pour l'instant : les pages
 * légales, dossier /legal). Rien n'est publié automatiquement ni créé à l'activation.
 * ========================================================================= */

/* Texte d'un modèle, avec le nom et l'adresse du site déjà renseignés */
function corbuilder_legal_template( $key ) {
	$pages = corbuilder_legal_pages();
	if ( ! isset( $pages[ $key ] ) || '' === $pages[ $key ]['file'] ) {
		return '';
	}
	$file = '';
	foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $dir ) { // le thème enfant peut remplacer un modèle
		if ( is_readable( $dir . '/legal/' . $pages[ $key ]['file'] ) ) {
			$file = $dir . '/legal/' . $pages[ $key ]['file'];
			break;
		}
	}
	if ( '' === $file ) {
		return '';
	}
	return strtr( (string) file_get_contents( $file ), array(
		'{site}'        => esc_html( get_bloginfo( 'name' ) ),
		'{url}'         => esc_url( home_url( '/' ) ),
		'{privacy_url}' => esc_url( home_url( '/' . $pages['privacy']['slug'] . '/' ) ),
		'{cookies_url}' => esc_url( home_url( '/' . $pages['cookies']['slug'] . '/' ) ),
		'{year}'        => gmdate( 'Y' ),
	) );
}

/* Page existante portant exactement le même titre ou la même adresse que le modèle (hors corbeille) ; 0 si aucune.
   Les pages choisies dans les emplacements du pied de page n'entrent pas en compte. */
function corbuilder_find_page_like( $title, $slug ) {
	$statuses = array( 'publish', 'draft', 'pending', 'private', 'future' );
	$by_slug  = get_posts( array( 'post_type' => 'page', 'post_status' => $statuses, 'name' => $slug, 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( $by_slug ) {
		return (int) $by_slug[0];
	}
	$by_title = get_posts( array( 'post_type' => 'page', 'post_status' => $statuses, 'title' => $title, 'numberposts' => 1, 'fields' => 'ids' ) );
	return $by_title ? (int) $by_title[0] : 0;
}

/* Sections d'une page (liste décodée, vide si aucune) */
function corbuilder_page_sections_list( $id ) {
	$list = json_decode( (string) get_theme_mod( 'corbuilder_p' . (int) $id . '_sections', '[]' ), true );
	return is_array( $list ) ? $list : array();
}

/* Nombre de points « À COMPLÉTER » restants, dans le texte de la page et dans ses sections */
function corbuilder_count_todo( $id ) {
	$post  = get_post( $id );
	$count = $post ? substr_count( (string) $post->post_content, '[À COMPLÉTER' ) : 0;
	$list  = corbuilder_page_sections_list( $id );
	array_walk_recursive( $list, function ( $value ) use ( &$count ) {
		if ( is_string( $value ) ) {
			$count += substr_count( $value, '[À COMPLÉTER' );
		}
	} );
	return $count;
}

/* État d'un modèle : missing (aucune page de même titre ou de même adresse) | draft | publish, avec le nombre de points « À COMPLÉTER » restants */
function corbuilder_legal_status( $key ) {
	$pages = corbuilder_legal_pages();
	$id    = isset( $pages[ $key ] ) ? corbuilder_find_page_like( $pages[ $key ]['title'], $pages[ $key ]['slug'] ) : 0;
	if ( ! $id ) {
		return array( 'state' => 'missing', 'id' => 0, 'todo' => 0 );
	}
	return array(
		'state' => 'publish' === get_post_status( $id ) ? 'publish' : 'draft',
		'id'    => $id,
		'todo'  => corbuilder_count_todo( $id ),
	);
}

/* HTML d'un modèle -> texte simple pour une section : paragraphes séparés par une ligne vide, listes en lignes « - », gras et liens conservés */
function corbuilder_html_to_text( $html ) {
	$html = preg_replace_callback( '#<ul[^>]*>(.*?)</ul>#is', function ( $m ) {
		preg_match_all( '#<li[^>]*>(.*?)</li>#is', $m[1], $items );
		$lines = array();
		foreach ( $items[1] as $item ) {
			$lines[] = '- ' . trim( preg_replace( '/\s+/', ' ', $item ) );
		}
		return "\n\n" . implode( "\n", $lines ) . "\n\n";
	}, (string) $html );
	$html = preg_replace( '#</p>#i', "\n\n", $html );
	$html = preg_replace( '#<p[^>]*>#i', '', $html );
	$html = preg_replace( '#<br\s*/?>#i', "\n", $html );
	return trim( preg_replace( "/\n{3,}/", "\n\n", $html ) );
}

/* Modèle -> introduction et paragraphes titrés (un par rubrique <h2>) */
function corbuilder_legal_split( $html ) {
	$html  = preg_replace( '/<!--.*?-->/s', '', (string) $html );
	$parts = preg_split( '#<h2[^>]*>(.*?)</h2>#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
	$intro = corbuilder_html_to_text( array_shift( $parts ) );
	$blocks = array();
	for ( $i = 0; $i + 1 < count( $parts ); $i += 2 ) {
		$blocks[] = array(
			'heading' => trim( html_entity_decode( wp_strip_all_tags( $parts[ $i ] ), ENT_QUOTES, 'UTF-8' ) ),
			'text'    => corbuilder_html_to_text( $parts[ $i + 1 ] ),
		);
	}
	return array( 'intro' => $intro, 'blocks' => $blocks );
}

/* Sections d'une page légale : une section « Paragraphe » remplie avec le modèle, modifiable dans Personnaliser */
function corbuilder_legal_sections( $key ) {
	$pages = corbuilder_legal_pages();
	if ( ! isset( $pages[ $key ] ) ) {
		return new WP_Error( 'corbuilder_legal', __( 'Page légale inconnue.', 'corbuilder' ) );
	}
	if ( ! empty( $pages[ $key ]['sections'] ) ) { // pas de texte de modèle : la page n'affiche que la section « Plan du site »
		return array( array( 'id' => 'plan', 'type' => 'sitemap', 'data' => array( 'title' => $pages[ $key ]['title'] ) ) );
	}
	$html = corbuilder_legal_template( $key );
	if ( '' === $html ) {
		return new WP_Error( 'corbuilder_legal', __( 'Modèle introuvable dans le dossier /legal du thème.', 'corbuilder' ) );
	}
	$split = corbuilder_legal_split( $html );
	return array( array(
		'id'   => 'texte',
		'type' => 'paragraph',
		'data' => array(
			'title'    => $pages[ $key ]['title'],
			'text'     => $split['intro'],
			'blocks'   => $split['blocks'],
			'numbered' => 'cgv' === $key,
			'style'    => 'plain',
			'width'    => 'medium',
		),
	) );
}

/* Crée le brouillon d'un modèle s'il n'existe pas encore (aucune page de même titre ou de même adresse) ; retourne l'identifiant de la page ou une erreur.
   Le brouillon n'est PAS relié à un emplacement du pied de page : c'est à toi de le choisir dans Personnaliser. */
function corbuilder_create_legal_page( $key ) {
	$pages = corbuilder_legal_pages();
	if ( ! isset( $pages[ $key ] ) ) {
		return new WP_Error( 'corbuilder_legal', __( 'Page légale inconnue.', 'corbuilder' ) );
	}
	$status = corbuilder_legal_status( $key );
	if ( 'missing' !== $status['state'] ) {
		return $status['id']; // déjà présente : on ne touche à rien
	}
	$sections = corbuilder_legal_sections( $key );
	if ( is_wp_error( $sections ) ) {
		return $sections;
	}
	$id = wp_insert_post( wp_slash( array(
		'post_type'    => 'page',
		'post_status'  => 'draft',
		'post_title'   => $pages[ $key ]['title'],
		'post_name'    => $pages[ $key ]['slug'],
		'post_content' => '',
	) ), true );
	if ( ! is_wp_error( $id ) ) {
		set_theme_mod( 'corbuilder_p' . (int) $id . '_sections', wp_json_encode( $sections ) );
	}
	return $id;
}

/* Catégories de brouillons proposées par l'écran. D'autres catégories s'ajoutent avec le filtre
   « corbuilder_draft_groups » : title, intro, pages (clé => title), status (fonction), create (fonction). */
function corbuilder_draft_groups() {
	return apply_filters( 'corbuilder_draft_groups', array(
		'legal' => array(
			'title'  => __( 'Pages légales', 'corbuilder' ),
			'intro'  => __( 'Ces modèles sont des textes généraux : ils ne remplacent pas l’avis d’un professionnel du droit et doivent être adaptés à ton activité. Chaque point à renseigner est marqué [À COMPLÉTER]. Les pages se modifient dans Personnaliser → Sections des pages ; les liens du pied de page se choisissent dans Personnaliser → Pied de page. Un modèle est proposé tant qu’aucune page n’a exactement le même titre ou la même adresse.', 'corbuilder' ),
			'pages'  => corbuilder_legal_pages(),
			'status' => 'corbuilder_legal_status',
			'create' => 'corbuilder_create_legal_page',
		),
	) );
}

function corbuilder_drafts_menu() {
	add_theme_page( __( 'Brouillons disponibles', 'corbuilder' ), __( 'Brouillons disponibles', 'corbuilder' ), 'edit_theme_options', 'corbuilder-drafts', 'corbuilder_drafts_admin_page' );
}
add_action( 'admin_menu', 'corbuilder_drafts_menu' );

function corbuilder_draft_create_url( $group, $key ) {
	return wp_nonce_url( admin_url( 'admin-post.php?action=corbuilder_create_draft&group=' . $group . '&page_key=' . $key ), 'corbuilder_drafts' );
}

function corbuilder_drafts_admin_page() {
	echo '<div class="wrap"><h1>' . esc_html__( 'Brouillons disponibles', 'corbuilder' ) . '</h1>';

	if ( isset( $_GET['created'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success"><p>' . esc_html__( 'Brouillon(s) créé(s). Complète les points signalés par [À COMPLÉTER], puis publie.', 'corbuilder' ) . '</p></div>';
	}
	if ( isset( $_GET['error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['error'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}
	echo '<p>' . esc_html__( 'Des modèles de pages à compléter. Ils sont créés en brouillon : ils ne sont jamais publiés automatiquement, ni créés à l’activation du thème.', 'corbuilder' ) . '</p>';

	$labels = array(
		'missing' => __( 'Non créée', 'corbuilder' ),
		'draft'   => __( 'Brouillon', 'corbuilder' ),
		'publish' => __( 'Publiée', 'corbuilder' ),
	);
	foreach ( corbuilder_draft_groups() as $group_id => $group ) {
		echo '<h2>' . esc_html( $group['title'] ) . '</h2>';
		if ( ! empty( $group['intro'] ) ) {
			echo '<p>' . esc_html( $group['intro'] ) . '</p>';
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Page', 'corbuilder' ) . '</th><th>' . esc_html__( 'État', 'corbuilder' ) . '</th><th>' . esc_html__( 'Points à compléter', 'corbuilder' ) . '</th><th></th></tr></thead><tbody>';
		$missing = 0;
		foreach ( $group['pages'] as $key => $page ) {
			$st = call_user_func( $group['status'], $key );
			if ( 'missing' === $st['state'] ) {
				++$missing;
				$action = '<a class="button button-primary" href="' . esc_url( corbuilder_draft_create_url( $group_id, $key ) ) . '">' . esc_html__( 'Créer le brouillon', 'corbuilder' ) . '</a>';
			} else {
				$post = get_post( $st['id'] );
				if ( corbuilder_page_sections_list( $st['id'] ) ) { // page faite de sections : elle se modifie dans Personnaliser
					$edit = add_query_arg( array( 'autofocus' => array( 'section' => 'corbuilder_page_' . (int) $st['id'] ), 'url' => rawurlencode( corbuilder_page_preview_url( $post ) ) ), admin_url( 'customize.php' ) );
					$action = '<a class="button button-primary" href="' . esc_url( $edit ) . '">' . esc_html__( 'Modifier dans Personnaliser', 'corbuilder' ) . '</a>';
				} else {
					$action = '<a class="button" href="' . esc_url( get_edit_post_link( $st['id'] ) ) . '">' . esc_html__( 'Modifier', 'corbuilder' ) . '</a>';
				}
				$action .= ' <a class="button" href="' . esc_url( corbuilder_page_preview_url( $post ) ) . '">' . esc_html( 'publish' === $st['state'] ? __( 'Voir', 'corbuilder' ) : __( 'Aperçu', 'corbuilder' ) ) . '</a>';
			}
			$todo = 'missing' === $st['state'] ? '—' : ( $st['todo'] ? (string) $st['todo'] : __( 'Aucun', 'corbuilder' ) );
			echo '<tr><td><strong>' . esc_html( $page['title'] ) . '</strong></td><td>' . esc_html( $labels[ $st['state'] ] ) . '</td><td>' . esc_html( $todo ) . '</td><td>' . $action . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- boutons construits ci-dessus
		}
		echo '</tbody></table>';
		if ( $missing > 1 ) {
			echo '<p><a class="button" href="' . esc_url( corbuilder_draft_create_url( $group_id, 'all' ) ) . '">' . esc_html__( 'Créer tous les brouillons manquants', 'corbuilder' ) . '</a></p>';
		}
	}
	echo '<p class="description">' . esc_html__( 'Les textes des modèles se modifient dans le dossier du thème (par exemple /legal pour les pages légales).', 'corbuilder' ) . '</p></div>';
}

function corbuilder_draft_create_request() {
	check_admin_referer( 'corbuilder_drafts' );
	if ( ! current_user_can( 'edit_pages' ) || ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Droits insuffisants.', 'corbuilder' ) );
	}
	$group_id = isset( $_GET['group'] ) ? sanitize_key( wp_unslash( $_GET['group'] ) ) : 'legal';
	$key      = isset( $_GET['page_key'] ) ? sanitize_key( wp_unslash( $_GET['page_key'] ) ) : '';
	$groups   = corbuilder_draft_groups();
	$args     = array( 'error' => rawurlencode( __( 'Catégorie de brouillons inconnue.', 'corbuilder' ) ) );

	if ( isset( $groups[ $group_id ] ) ) {
		$group = $groups[ $group_id ];
		$keys  = ( 'all' === $key ) ? array_keys( $group['pages'] ) : array( $key );
		$args  = array( 'created' => $key );
		foreach ( $keys as $k ) {
			$result = call_user_func( $group['create'], $k );
			if ( is_wp_error( $result ) ) {
				$args = array( 'error' => rawurlencode( $result->get_error_message() ) );
				break;
			}
		}
	}
	wp_safe_redirect( add_query_arg( $args, admin_url( 'themes.php?page=corbuilder-drafts' ) ) );
	exit;
}
add_action( 'admin_post_corbuilder_create_draft', 'corbuilder_draft_create_request' );
