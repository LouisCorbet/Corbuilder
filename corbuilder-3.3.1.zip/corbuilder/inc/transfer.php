<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * EXPORT / IMPORT DU SITE : Apparence → Export / import.
 *
 * L'export crée une archive .zip : un fichier site.json (pages, articles, motifs, catégories, menus,
 * réglages du thème, réglages généraux, CSS additionnel) et les fichiers de la médiathèque.
 * L'import VIDE D'ABORD le site (pages, articles, motifs, médias, menus, catégories, réglages du thème),
 * puis recrée tout ce que contient l'archive. Les numéros changent d'un site à l'autre : tout ce qui y fait
 * référence (images des sections, pages d'accueil, menus, pages légales, motifs…) est reconnecté.
 * ========================================================================= */

/* Réglages généraux de WordPress transportés avec le site */
function corbuilder_transfer_options() {
	return array( 'blogname', 'blogdescription', 'show_on_front', 'page_on_front', 'page_for_posts', 'wp_page_for_privacy_policy', 'site_icon',
		'permalink_structure', 'category_base', 'tag_base', 'posts_per_page', 'date_format', 'time_format', 'timezone_string', 'gmt_offset', 'start_of_week' );
}

/* Dossier où déposer une archive trop grosse pour être envoyée par le formulaire (FTP) */
function corbuilder_transfer_dir() {
	$u = wp_upload_dir( null, false );
	return trailingslashit( $u['basedir'] ) . 'corbuilder-import';
}

function corbuilder_transfer_server_files() {
	$files = array();
	foreach ( (array) glob( corbuilder_transfer_dir() . '/*.zip' ) as $f ) {
		$files[ basename( $f ) ] = $f;
	}
	ksort( $files );
	return $files;
}

/* ---------- Petits outils ---------- */

/* Remplacement des anciennes adresses (site, dossier des images) par les nouvelles, dans une valeur de n'importe quel type */
function corbuilder_transfer_urls( $value, $urls ) {
	if ( is_string( $value ) ) {
		return $urls ? str_replace( array_keys( $urls ), array_values( $urls ), $value ) : $value;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = corbuilder_transfer_urls( $v, $urls );
		}
	}
	return $value;
}

function corbuilder_transfer_map( $map, $kind, $old ) {
	$old = (int) $old;
	return isset( $map[ $kind ][ $old ] ) ? (int) $map[ $kind ][ $old ] : 0;
}

/* Champs d'une section (comme dans le Customizer), pour retrouver ceux qui contiennent une image */
function corbuilder_transfer_fields( $def ) {
	return array_merge( corbuilder_normalize_fields( $def['fields'] ), corbuilder_common_fields( $def ) );
}

/* Données d'une section : images, galeries, icônes de boutons, motifs et adresses reconnectés */
function corbuilder_transfer_remap_fields( $fields, $data, $map, $urls ) {
	if ( ! is_array( $data ) ) {
		return $data;
	}
	foreach ( $data as $key => $value ) {
		$type = isset( $fields[ $key ]['type'] ) ? $fields[ $key ]['type'] : '';
		switch ( $type ) {
			case 'image':
			case 'file':
				$data[ $key ] = corbuilder_transfer_map( $map, 'media', $value );
				break;
			case 'gallery':
				$ids = array();
				foreach ( is_array( $value ) ? $value : array() as $old ) {
					$new = corbuilder_transfer_map( $map, 'media', $old );
					if ( $new ) {
						$ids[] = $new;
					}
				}
				$data[ $key ] = $ids;
				break;
			case 'button':
				if ( is_array( $value ) ) {
					$value = corbuilder_transfer_urls( $value, $urls );
					if ( isset( $value['icon_media'] ) ) {
						$value['icon_media'] = corbuilder_transfer_map( $map, 'media', $value['icon_media'] );
					}
				}
				$data[ $key ] = $value;
				break;
			case 'repeater':
				if ( is_array( $value ) && isset( $fields[ $key ]['fields'] ) ) {
					$sub = corbuilder_normalize_fields( $fields[ $key ]['fields'] );
					foreach ( $value as $i => $item ) {
						$value[ $i ] = corbuilder_transfer_remap_fields( $sub, $item, $map, $urls );
					}
				}
				$data[ $key ] = $value;
				break;
			case 'select':
				if ( is_string( $value ) && preg_match( '/^block-(\d+)$/', $value, $m ) ) { // section « Composant » : motif
					$new          = corbuilder_transfer_map( $map, 'post', $m[1] );
					$data[ $key ] = $new ? 'block-' . $new : 'none';
				}
				break;
			default:
				$data[ $key ] = corbuilder_transfer_urls( $value, $urls );
		}
	}
	return $data;
}

/* JSON des sections d'une page (ou du modèle des articles) -> JSON reconnecté */
function corbuilder_transfer_remap_sections( $json, $map, $urls ) {
	$items = json_decode( is_string( $json ) ? $json : '', true );
	if ( ! is_array( $items ) ) {
		return $json;
	}
	$registry = corbuilder_get_sections();
	foreach ( $items as $i => $item ) {
		if ( is_array( $item ) && isset( $item['type'], $item['data'] ) && is_string( $item['type'] ) && isset( $registry[ $item['type'] ] ) && is_array( $item['data'] ) ) {
			$items[ $i ]['data'] = corbuilder_transfer_remap_fields( corbuilder_transfer_fields( $registry[ $item['type'] ] ), $item['data'], $map, $urls );
		}
	}
	return wp_json_encode( $items );
}

/* Contenu d'une page ou d'un article : images, motifs, galeries et adresses reconnectés */
function corbuilder_transfer_remap_content( $html, $map, $urls ) {
	$html = corbuilder_transfer_urls( (string) $html, $urls );
	// Classes « wp-image-123 »
	$html = preg_replace_callback( '/wp-image-(\d+)/', function ( $m ) use ( $map ) {
		$new = corbuilder_transfer_map( $map, 'media', $m[1] );
		return $new ? 'wp-image-' . $new : $m[0];
	}, $html );
	// Blocs : "id", "mediaId", "ids":[…] pour les images et "ref" pour les motifs
	$html = preg_replace_callback( '/<!--\s+wp:[a-z0-9\/-]+\s+\{.*?\}\s*\/?-->/s', function ( $m ) use ( $map ) {
		$c = $m[0];
		$c = preg_replace_callback( '/"(id|mediaId)":(\d+)/', function ( $x ) use ( $map ) {
			$new = corbuilder_transfer_map( $map, 'media', $x[2] );
			return $new ? '"' . $x[1] . '":' . $new : $x[0];
		}, $c );
		$c = preg_replace_callback( '/"ref":(\d+)/', function ( $x ) use ( $map ) {
			$new = corbuilder_transfer_map( $map, 'post', $x[1] );
			return $new ? '"ref":' . $new : $x[0];
		}, $c );
		return preg_replace_callback( '/"ids":\[([\d,\s]*)\]/', function ( $x ) use ( $map ) {
			$ids = array();
			foreach ( array_filter( array_map( 'trim', explode( ',', $x[1] ) ) ) as $old ) {
				$new   = corbuilder_transfer_map( $map, 'media', $old );
				$ids[] = $new ? $new : (int) $old;
			}
			return '"ids":[' . implode( ',', $ids ) . ']';
		}, $c );
	}, $html );
	// Codes courts [gallery ids="1,2,3"]
	return preg_replace_callback( '/ids="([\d,\s]+)"/', function ( $m ) use ( $map ) {
		$ids = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', $m[1] ) ) ) as $old ) {
			$new   = corbuilder_transfer_map( $map, 'media', $old );
			$ids[] = $new ? $new : (int) $old;
		}
		return 'ids="' . implode( ',', $ids ) . '"';
	}, $html );
}

/* =========================================================================
 * EXPORT
 * ========================================================================= */

/* Crée l'archive $zip_path ; retourne true ou une erreur */
function corbuilder_transfer_export( $zip_path ) {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'L’extension PHP « zip » n’est pas disponible sur ce serveur : impossible de créer l’archive.', 'corbuilder' ) );
	}
	@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	wp_raise_memory_limit( 'admin' );

	$uploads = wp_upload_dir( null, false );
	$data    = array(
		'format'        => 1,
		'theme'         => get_stylesheet(),
		'theme_version' => defined( 'CORBUILDER_VERSION' ) ? CORBUILDER_VERSION : '',
		'exported'      => gmdate( 'c' ),
		'home'          => untrailingslashit( home_url() ),
		'uploads'       => untrailingslashit( $uploads['baseurl'] ),
		'options'       => array(),
		'terms'         => array(),
		'posts'         => array(),
		'media'         => array(),
		'menus'         => array(),
		'mods'          => array(),
		'custom_css'    => (string) wp_get_custom_css(),
	);

	foreach ( corbuilder_transfer_options() as $key ) {
		$value = get_option( $key, null );
		if ( null !== $value ) {
			$data['options'][ $key ] = $value;
		}
	}

	foreach ( array( 'category', 'post_tag' ) as $tax ) {
		$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $t ) {
			$data['terms'][] = array(
				'id'          => (int) $t->term_id,
				'taxonomy'    => $tax,
				'name'        => $t->name,
				'slug'        => $t->slug,
				'description' => $t->description,
				'parent'      => (int) $t->parent,
			);
		}
	}

	$post_ids = get_posts( array(
		'post_type'        => array( 'page', 'post', 'wp_block' ),
		'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
		'numberposts'      => -1,
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'fields'           => 'ids',
		'suppress_filters' => true,
	) );
	foreach ( $post_ids as $id ) {
		$p = get_post( $id );
		if ( ! $p ) {
			continue;
		}
		$row = array(
			'id'             => (int) $p->ID,
			'type'           => $p->post_type,
			'status'         => $p->post_status,
			'title'          => $p->post_title,
			'slug'           => $p->post_name,
			'content'        => $p->post_content,
			'excerpt'        => $p->post_excerpt,
			'date'           => $p->post_date,
			'date_gmt'       => $p->post_date_gmt,
			'parent'         => (int) $p->post_parent,
			'menu_order'     => (int) $p->menu_order,
			'comment_status' => $p->comment_status,
			'ping_status'    => $p->ping_status,
			'password'       => $p->post_password,
			'thumbnail'      => (int) get_post_thumbnail_id( $p ),
			'terms'          => array(),
			'meta'           => array(),
		);
		foreach ( array( 'category', 'post_tag' ) as $tax ) {
			if ( is_object_in_taxonomy( $p->post_type, $tax ) ) {
				$row['terms'][ $tax ] = array_map( 'intval', (array) wp_get_object_terms( $p->ID, $tax, array( 'fields' => 'ids' ) ) );
			}
		}
		foreach ( (array) get_post_meta( $p->ID ) as $k => $values ) {
			if ( '_wp_page_template' === $k || '_' !== substr( $k, 0, 1 ) ) {
				$row['meta'][ $k ] = array_map( 'maybe_unserialize', (array) $values );
			}
		}
		$data['posts'][] = $row;
	}

	$zip = new ZipArchive();
	if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'Impossible de créer le fichier d’archive.', 'corbuilder' ) );
	}

	$att_ids = get_posts( array(
		'post_type'        => 'attachment',
		'post_status'      => array( 'inherit', 'publish', 'private' ),
		'numberposts'      => -1,
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'fields'           => 'ids',
		'suppress_filters' => true,
	) );
	foreach ( $att_ids as $id ) {
		$p    = get_post( $id );
		$file = get_attached_file( $id );
		$rel  = (string) get_post_meta( $id, '_wp_attached_file', true );
		if ( ! $p || ! $file || '' === $rel || ! is_readable( $file ) ) {
			continue;
		}
		$zip->addFile( $file, 'media/' . $rel );
		$data['media'][] = array(
			'id'          => (int) $p->ID,
			'file'        => $rel,
			'title'       => $p->post_title,
			'caption'     => $p->post_excerpt,
			'description' => $p->post_content,
			'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'mime'        => $p->post_mime_type,
			'parent'      => (int) $p->post_parent,
			'date'        => $p->post_date,
		);
	}

	$locations = array();
	foreach ( (array) get_nav_menu_locations() as $loc => $menu_id ) {
		$locations[ (int) $menu_id ][] = $loc;
	}
	foreach ( (array) wp_get_nav_menus() as $menu ) {
		$items = array();
		foreach ( (array) wp_get_nav_menu_items( $menu->term_id, array( 'post_status' => 'any' ) ) as $it ) {
			$items[] = array(
				'id'          => (int) $it->ID,
				'parent'      => (int) $it->menu_item_parent,
				'type'        => $it->type,
				'object'      => $it->object,
				'object_id'   => (int) $it->object_id,
				'title'       => $it->title,
				'url'         => $it->url,
				'target'      => $it->target,
				'attr_title'  => $it->attr_title,
				'description' => $it->description,
				'classes'     => array_values( array_filter( (array) $it->classes ) ),
				'xfn'         => $it->xfn,
				'order'       => (int) $it->menu_order,
			);
		}
		$data['menus'][] = array(
			'name'      => $menu->name,
			'locations' => isset( $locations[ (int) $menu->term_id ] ) ? $locations[ (int) $menu->term_id ] : array(),
			'items'     => $items,
		);
	}

	foreach ( (array) get_theme_mods() as $key => $value ) {
		if ( in_array( $key, array( 'nav_menu_locations', 'custom_css_post_id' ), true ) || 0 === strpos( (string) $key, 'sidebars_widgets' ) ) {
			continue;
		}
		$data['mods'][ $key ] = $value;
	}

	$json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( false === $json ) {
		$zip->close();
		return new WP_Error( 'corbuilder_json', __( 'Le contenu du site contient des caractères invalides : export impossible.', 'corbuilder' ) );
	}
	$zip->addFromString( 'site.json', $json );
	if ( ! $zip->close() ) {
		return new WP_Error( 'corbuilder_zip', __( 'Impossible de terminer l’archive (espace disque ?).', 'corbuilder' ) );
	}
	return true;
}

/* =========================================================================
 * IMPORT
 * ========================================================================= */

/* Lit et vérifie l'archive SANS rien modifier ; retourne array( 'zip' => ZipArchive, 'data' => … ) ou une erreur */
function corbuilder_transfer_open( $zip_path ) {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'L’extension PHP « zip » n’est pas disponible sur ce serveur.', 'corbuilder' ) );
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $zip_path ) ) {
		return new WP_Error( 'corbuilder_zip', __( 'Ce fichier n’est pas une archive valide.', 'corbuilder' ) );
	}
	$json = $zip->getFromName( 'site.json' );
	$data = false === $json ? null : json_decode( $json, true );
	if ( ! is_array( $data ) || ! isset( $data['format'], $data['posts'], $data['media'] ) ) {
		$zip->close();
		return new WP_Error( 'corbuilder_format', __( 'Ce fichier n’est pas un export de ce thème (fichier site.json absent ou illisible).', 'corbuilder' ) );
	}
	if ( 1 !== (int) $data['format'] ) {
		$zip->close();
		return new WP_Error( 'corbuilder_format', __( 'Cet export vient d’une version incompatible du thème.', 'corbuilder' ) );
	}
	return array( 'zip' => $zip, 'data' => $data );
}

/* Vide le site : pages, articles, motifs, médias, menus, catégories, étiquettes, réglages du thème */
function corbuilder_transfer_wipe() {
	$count = array( 'posts' => 0, 'media' => 0, 'menus' => 0, 'terms' => 0 );

	foreach ( (array) wp_get_nav_menus() as $menu ) {
		if ( ! is_wp_error( wp_delete_nav_menu( $menu->term_id ) ) ) {
			$count['menus']++;
		}
	}

	$types = array_unique( array_merge( array_values( get_post_types( array( 'public' => true ) ) ), array( 'page', 'post', 'attachment', 'wp_block', 'wp_navigation' ) ) );
	foreach ( array( 'any', 'trash' ) as $status ) {
		do {
			$ids = get_posts( array(
				'post_type'        => $types,
				'post_status'      => $status,
				'numberposts'      => 200,
				'fields'           => 'ids',
				'suppress_filters' => true,
			) );
			foreach ( $ids as $id ) {
				$is_media = 'attachment' === get_post_type( $id );
				if ( wp_delete_post( $id, true ) ) {
					$count[ $is_media ? 'media' : 'posts' ]++;
				}
			}
		} while ( $ids );
	}

	$default = (int) get_option( 'default_category' );
	foreach ( array( 'category', 'post_tag' ) as $tax ) {
		$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'fields' => 'ids' ) );
		foreach ( is_wp_error( $terms ) ? array() : $terms as $term_id ) {
			if ( (int) $term_id !== $default && ! is_wp_error( wp_delete_term( $term_id, $tax ) ) ) {
				$count['terms']++;
			}
		}
	}

	remove_theme_mods();
	update_option( 'show_on_front', 'posts' );
	update_option( 'page_on_front', 0 );
	update_option( 'page_for_posts', 0 );
	update_option( 'wp_page_for_privacy_policy', 0 );
	return $count;
}

/* Vide le site puis recrée le contenu de l'archive $zip_path ; retourne un résumé ou une erreur */
function corbuilder_transfer_import( $zip_path ) {
	$opened = corbuilder_transfer_open( $zip_path ); // tout est vérifié avant de supprimer quoi que ce soit
	if ( is_wp_error( $opened ) ) {
		return $opened;
	}
	$zip  = $opened['zip'];
	$data = $opened['data'];

	@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	@ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	wp_raise_memory_limit( 'admin' );
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/post.php';

	// Pas de filtrage du contenu ni de révisions : on restaure le contenu de l'administrateur tel quel.
	kses_remove_filters();
	remove_action( 'post_updated', 'wp_save_post_revision' );
	wp_defer_term_counting( true );

	$summary = array( 'wiped' => corbuilder_transfer_wipe(), 'media' => 0, 'skipped' => 0, 'pages' => 0, 'posts' => 0, 'blocks' => 0, 'menus' => 0, 'terms' => 0 );
	$map     = array( 'media' => array(), 'post' => array(), 'term' => array(), 'item' => array() );

	$new_home    = untrailingslashit( home_url() );
	$uploads     = wp_upload_dir( null, false );
	$new_uploads = untrailingslashit( $uploads['baseurl'] );
	$urls        = array();
	$old_uploads = isset( $data['uploads'] ) ? untrailingslashit( (string) $data['uploads'] ) : '';
	$old_home    = isset( $data['home'] ) ? untrailingslashit( (string) $data['home'] ) : '';
	if ( '' !== $old_uploads && $old_uploads !== $new_uploads ) {
		$urls[ $old_uploads ] = $new_uploads; // d'abord le dossier des images (il est dans l'adresse du site)
	}
	if ( '' !== $old_home && $old_home !== $new_home ) {
		$urls[ $old_home ] = $new_home;
	}

	// 1. Médiathèque
	foreach ( (array) $data['media'] as $m ) {
		$rel = isset( $m['file'] ) ? (string) $m['file'] : '';
		if ( '' === $rel || false !== strpos( $rel, '..' ) || '/' === $rel[0] || '\\' === $rel[0] ) {
			$summary['skipped']++;
			continue;
		}
		$type = wp_check_filetype( basename( $rel ) );
		if ( empty( $type['type'] ) ) { // type de fichier non autorisé par WordPress (ex. .php) : on ne l'importe pas
			$summary['skipped']++;
			continue;
		}
		$stream = $zip->getStream( 'media/' . $rel );
		if ( ! $stream ) {
			$summary['skipped']++;
			continue;
		}
		$dest = $uploads['basedir'] . '/' . $rel;
		wp_mkdir_p( dirname( $dest ) );
		$out = fopen( $dest, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $out ) {
			fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$summary['skipped']++;
			continue;
		}
		stream_copy_to_stream( $stream, $out );
		fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$att_id = wp_insert_attachment( array(
			'post_mime_type' => ! empty( $m['mime'] ) ? $m['mime'] : $type['type'],
			'post_title'     => isset( $m['title'] ) ? $m['title'] : '',
			'post_content'   => isset( $m['description'] ) ? $m['description'] : '',
			'post_excerpt'   => isset( $m['caption'] ) ? $m['caption'] : '',
			'post_status'    => 'inherit',
			'post_date'      => ! empty( $m['date'] ) ? $m['date'] : current_time( 'mysql' ),
		), $dest, 0, true );
		if ( is_wp_error( $att_id ) || ! $att_id ) {
			$summary['skipped']++;
			continue;
		}
		wp_update_attachment_metadata( $att_id, wp_generate_attachment_metadata( $att_id, $dest ) );
		if ( ! empty( $m['alt'] ) ) {
			update_post_meta( $att_id, '_wp_attachment_image_alt', wp_slash( $m['alt'] ) );
		}
		$map['media'][ (int) $m['id'] ] = (int) $att_id;
		$summary['media']++;
	}

	// 2. Catégories et étiquettes (les parents d'abord)
	$terms = array_values( (array) $data['terms'] );
	for ( $pass = 0; $pass < 5 && $terms; $pass++ ) {
		$left = array();
		foreach ( $terms as $t ) {
			if ( ! empty( $t['parent'] ) && ! isset( $map['term'][ (int) $t['parent'] ] ) ) {
				$left[] = $t;
				continue;
			}
			$parent   = ! empty( $t['parent'] ) ? $map['term'][ (int) $t['parent'] ] : 0;
			$existing = term_exists( $t['slug'], $t['taxonomy'] );
			if ( $existing ) {
				$term_id = (int) ( is_array( $existing ) ? $existing['term_id'] : $existing );
				wp_update_term( $term_id, $t['taxonomy'], array( 'name' => $t['name'], 'description' => $t['description'], 'parent' => $parent ) );
			} else {
				$new     = wp_insert_term( $t['name'], $t['taxonomy'], array( 'slug' => $t['slug'], 'description' => $t['description'], 'parent' => $parent ) );
				$term_id = is_wp_error( $new ) ? 0 : (int) $new['term_id'];
				if ( $term_id ) {
					$summary['terms']++;
				}
			}
			if ( $term_id ) {
				$map['term'][ (int) $t['id'] ] = $term_id;
			}
		}
		$terms = $left;
	}

	// 3. Pages, articles et motifs (les parents d'abord, pour que les adresses soient exactes)
	$posts   = array_values( (array) $data['posts'] );
	$created = array();
	for ( $pass = 0; $pass < 12 && $posts; $pass++ ) {
		$left = array();
		foreach ( $posts as $p ) {
			if ( ! empty( $p['parent'] ) && ! isset( $map['post'][ (int) $p['parent'] ] ) && $pass < 11 ) {
				$left[] = $p;
				continue;
			}
			$id = wp_insert_post( wp_slash( array(
				'post_type'      => $p['type'],
				'post_status'    => $p['status'],
				'post_title'     => $p['title'],
				'post_name'      => $p['slug'],
				'post_content'   => $p['content'],
				'post_excerpt'   => $p['excerpt'],
				'post_date'      => $p['date'],
				'post_date_gmt'  => $p['date_gmt'],
				'post_parent'    => ! empty( $p['parent'] ) && isset( $map['post'][ (int) $p['parent'] ] ) ? $map['post'][ (int) $p['parent'] ] : 0,
				'menu_order'     => (int) $p['menu_order'],
				'comment_status' => $p['comment_status'],
				'ping_status'    => $p['ping_status'],
				'post_password'  => $p['password'],
				'post_author'    => get_current_user_id(),
			) ), true );
			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}
			$map['post'][ (int) $p['id'] ] = (int) $id;
			$created[]                     = array( 'new' => (int) $id, 'row' => $p );
			$key                           = 'page' === $p['type'] ? 'pages' : ( 'wp_block' === $p['type'] ? 'blocks' : 'posts' );
			$summary[ $key ]++;
		}
		$posts = $left;
	}

	// 3 bis. Contenu, image à la une, catégories, champs personnalisés : une fois que tous les numéros sont connus
	foreach ( $created as $c ) {
		$id  = $c['new'];
		$row = $c['row'];
		$new = corbuilder_transfer_remap_content( $row['content'], $map, $urls );
		if ( $new !== $row['content'] ) {
			wp_update_post( wp_slash( array( 'ID' => $id, 'post_content' => $new ) ) );
		}
		if ( ! empty( $row['thumbnail'] ) && corbuilder_transfer_map( $map, 'media', $row['thumbnail'] ) ) {
			set_post_thumbnail( $id, corbuilder_transfer_map( $map, 'media', $row['thumbnail'] ) );
		}
		foreach ( (array) $row['terms'] as $tax => $old_ids ) {
			$new_ids = array();
			foreach ( (array) $old_ids as $old ) {
				if ( corbuilder_transfer_map( $map, 'term', $old ) ) {
					$new_ids[] = corbuilder_transfer_map( $map, 'term', $old );
				}
			}
			if ( $new_ids ) {
				wp_set_object_terms( $id, $new_ids, $tax );
			}
		}
		foreach ( (array) $row['meta'] as $k => $values ) {
			foreach ( (array) $values as $v ) {
				add_post_meta( $id, $k, wp_slash( corbuilder_transfer_urls( $v, $urls ) ) );
			}
		}
	}
	// Pièces jointes : la page à laquelle elles sont rattachées
	global $wpdb;
	foreach ( (array) $data['media'] as $m ) {
		$att = corbuilder_transfer_map( $map, 'media', $m['id'] );
		$par = ! empty( $m['parent'] ) ? corbuilder_transfer_map( $map, 'post', $m['parent'] ) : 0;
		if ( $att && $par ) {
			$wpdb->update( $wpdb->posts, array( 'post_parent' => $par ), array( 'ID' => $att ) );
		}
	}

	// 4. Menus
	$locations = array();
	foreach ( (array) $data['menus'] as $menu ) {
		$menu_id = wp_create_nav_menu( $menu['name'] );
		if ( is_wp_error( $menu_id ) ) {
			$obj     = wp_get_nav_menu_object( $menu['name'] );
			$menu_id = $obj ? (int) $obj->term_id : 0;
		}
		if ( ! $menu_id ) {
			continue;
		}
		$summary['menus']++;
		$items = array_values( (array) $menu['items'] );
		usort( $items, function ( $a, $b ) {
			return (int) $a['order'] <=> (int) $b['order'];
		} );
		for ( $pass = 0; $pass < 6 && $items; $pass++ ) {
			$left = array();
			foreach ( $items as $it ) {
				if ( ! empty( $it['parent'] ) && ! isset( $map['item'][ (int) $it['parent'] ] ) && $pass < 5 ) {
					$left[] = $it;
					continue;
				}
				$object_id = 0;
				if ( 'post_type' === $it['type'] ) {
					$object_id = corbuilder_transfer_map( $map, 'post', $it['object_id'] );
				} elseif ( 'taxonomy' === $it['type'] ) {
					$object_id = corbuilder_transfer_map( $map, 'term', $it['object_id'] );
				}
				if ( 'custom' !== $it['type'] && ! $object_id ) { // la page ou la catégorie visée n'existe pas dans l'export
					continue;
				}
				$item_id = wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-type'        => $it['type'],
					'menu-item-object'      => $it['object'],
					'menu-item-object-id'   => $object_id,
					'menu-item-title'       => $it['title'],
					'menu-item-url'         => 'custom' === $it['type'] ? corbuilder_transfer_urls( $it['url'], $urls ) : '',
					'menu-item-target'      => $it['target'],
					'menu-item-attr-title'  => $it['attr_title'],
					'menu-item-description' => $it['description'],
					'menu-item-classes'     => implode( ' ', (array) $it['classes'] ),
					'menu-item-xfn'         => $it['xfn'],
					'menu-item-position'    => (int) $it['order'],
					'menu-item-parent-id'   => ! empty( $it['parent'] ) && isset( $map['item'][ (int) $it['parent'] ] ) ? $map['item'][ (int) $it['parent'] ] : 0,
					'menu-item-status'      => 'publish',
				) );
				if ( ! is_wp_error( $item_id ) ) {
					$map['item'][ (int) $it['id'] ] = (int) $item_id;
				}
			}
			$items = $left;
		}
		foreach ( (array) $menu['locations'] as $loc ) {
			$locations[ $loc ] = (int) $menu_id;
		}
	}

	// 5. Réglages du thème : les numéros de pages et d'images sont remplacés par les nouveaux
	$mods = array();
	foreach ( (array) $data['mods'] as $key => $value ) {
		if ( preg_match( '/^(?:corbuilder|leger)_p(\d+)_sections$/', $key, $m ) ) { // « leger_ » : exports créés avec l'ancien thème Léger
			$page = corbuilder_transfer_map( $map, 'post', $m[1] );
			if ( $page ) {
				$mods[ 'corbuilder_p' . $page . '_sections' ] = corbuilder_transfer_remap_sections( $value, $map, $urls );
			}
		} elseif ( preg_match( '/^corbuilder_p(\d+)_panel$/', $key, $m ) ) { // panneau latéral d'une page
			$page = corbuilder_transfer_map( $map, 'post', $m[1] );
			if ( $page ) {
				$mods[ 'corbuilder_p' . $page . '_panel' ] = $value;
			}
		} elseif ( in_array( $key, array( 'corbuilder_post_template_sections', 'leger_post_template_sections' ), true ) ) {
			$mods['corbuilder_post_template_sections'] = corbuilder_transfer_remap_sections( $value, $map, $urls ); // toujours sous le nom actuel, même pour un export créé avec Léger
		} elseif ( in_array( $key, array( 'custom_logo', 'header_image2' ), true ) ) {
			$mods[ $key ] = corbuilder_transfer_map( $map, 'media', $value );
		} elseif ( 0 === strpos( $key, 'legal_page_' ) ) {
			$mods[ $key ] = corbuilder_transfer_map( $map, 'post', $value );
		} else {
			$mods[ $key ] = corbuilder_transfer_urls( $value, $urls );
		}
	}
	foreach ( $mods as $key => $value ) {
		set_theme_mod( $key, $value );
	}
	set_theme_mod( 'nav_menu_locations', $locations );
	corbuilder_upgrade_to_240(); // archive d'une ancienne version : couleurs converties vers la palette
	wp_update_custom_css_post( isset( $data['custom_css'] ) ? (string) $data['custom_css'] : '' );

	// 6. Réglages généraux
	foreach ( (array) $data['options'] as $key => $value ) {
		if ( ! in_array( $key, corbuilder_transfer_options(), true ) ) {
			continue;
		}
		if ( in_array( $key, array( 'page_on_front', 'page_for_posts', 'wp_page_for_privacy_policy' ), true ) ) {
			$value = corbuilder_transfer_map( $map, 'post', $value );
		} elseif ( 'site_icon' === $key ) {
			$value = corbuilder_transfer_map( $map, 'media', $value );
		}
		update_option( $key, $value );
	}
	if ( 'page' === get_option( 'show_on_front' ) && ! get_option( 'page_on_front' ) ) {
		update_option( 'show_on_front', 'posts' );
	}

	wp_defer_term_counting( false );
	kses_init_filters();
	add_action( 'post_updated', 'wp_save_post_revision', 10, 1 );
	$zip->close();
	wp_cache_flush();
	flush_rewrite_rules();
	return $summary;
}

/* =========================================================================
 * ADMINISTRATION : Apparence → Export / import
 * ========================================================================= */

function corbuilder_transfer_menu() {
	add_theme_page( __( 'Export / import du site', 'corbuilder' ), __( 'Export / import', 'corbuilder' ), 'manage_options', 'corbuilder-transfer', 'corbuilder_transfer_page' );
}
add_action( 'admin_menu', 'corbuilder_transfer_menu' );

function corbuilder_transfer_back( $notice ) {
	set_transient( 'corbuilder_transfer_notice_' . get_current_user_id(), $notice, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'themes.php?page=corbuilder-transfer' ) );
	exit;
}

/* Téléchargement de l'export */
function corbuilder_transfer_export_request() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accès refusé.', 'corbuilder' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'corbuilder_transfer_export' );
	$tmp = wp_tempnam( 'corbuilder-export.zip' );
	$res = corbuilder_transfer_export( $tmp );
	if ( is_wp_error( $res ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
		corbuilder_transfer_back( array( 'type' => 'error', 'lines' => array( $res->get_error_message() ) ) );
	}
	$host = sanitize_file_name( wp_parse_url( home_url(), PHP_URL_HOST ) );
	nocache_headers();
	header( 'Content-Type: application/zip' );
	header( 'Content-Disposition: attachment; filename="corbuilder-export-' . $host . '-' . gmdate( 'Y-m-d' ) . '.zip"' );
	header( 'Content-Length: ' . filesize( $tmp ) );
	readfile( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
	exit;
}
add_action( 'admin_post_corbuilder_export', 'corbuilder_transfer_export_request' );

/* Message expliquant pourquoi PHP a refusé le fichier envoyé (code d'erreur de $_FILES) */
function corbuilder_transfer_upload_error( $code ) {
	switch ( $code ) {
		case UPLOAD_ERR_INI_SIZE:
			/* translators: %s: valeur de upload_max_filesize */
			$cause = sprintf( __( 'le fichier dépasse la limite « upload_max_filesize » de PHP (%s).', 'corbuilder' ), (string) ini_get( 'upload_max_filesize' ) );
			break;
		case UPLOAD_ERR_FORM_SIZE:
			$cause = __( 'le fichier dépasse la taille maximale indiquée par le formulaire.', 'corbuilder' );
			break;
		case UPLOAD_ERR_PARTIAL:
			$cause = __( 'le fichier n’a été reçu qu’en partie : l’envoi a été interrompu (connexion coupée ou délai dépassé côté PHP, serveur web ou Cloudflare).', 'corbuilder' );
			break;
		case UPLOAD_ERR_NO_TMP_DIR:
			$cause = __( 'PHP n’a pas de dossier temporaire où poser le fichier.', 'corbuilder' );
			break;
		case UPLOAD_ERR_CANT_WRITE:
			$cause = __( 'PHP n’a pas pu écrire le fichier sur le disque (dossier temporaire plein ou non inscriptible).', 'corbuilder' );
			break;
		case UPLOAD_ERR_EXTENSION:
			$cause = __( 'une extension PHP a bloqué l’envoi.', 'corbuilder' );
			break;
		default:
			/* translators: %d: code d'erreur PHP */
			$cause = sprintf( __( 'erreur inconnue (code PHP %d).', 'corbuilder' ), $code );
	}
	/* translators: 1: cause de l'erreur, 2: post_max_size */
	return sprintf( __( 'Le fichier n’a pas pu être envoyé : %1$s (post_max_size : %2$s). Tu peux plutôt le déposer dans le dossier indiqué plus bas et le choisir dans la liste. Rien n’a été modifié.', 'corbuilder' ), $cause, (string) ini_get( 'post_max_size' ) );
}

/* Import : confirmation obligatoire, puis le site est vidé et recréé */
function corbuilder_transfer_import_request() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accès refusé.', 'corbuilder' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'corbuilder_transfer_import' );

	$confirm = isset( $_POST['corbuilder_confirm'] ) ? strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['corbuilder_confirm'] ) ) ) ) : '';
	if ( 'VIDER' !== $confirm ) {
		corbuilder_transfer_back( array( 'type' => 'error', 'lines' => array( __( 'Import annulé : tape le mot VIDER pour confirmer que le site sera vidé. Rien n’a été modifié.', 'corbuilder' ) ) ) );
	}

	$path   = '';
	$remove = false;
	if ( ! empty( $_FILES['corbuilder_file']['tmp_name'] ) && is_uploaded_file( $_FILES['corbuilder_file']['tmp_name'] ) && UPLOAD_ERR_OK === (int) $_FILES['corbuilder_file']['error'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path   = wp_tempnam( 'corbuilder-import.zip' );
		$remove = true;
		move_uploaded_file( $_FILES['corbuilder_file']['tmp_name'], $path ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	} elseif ( ! empty( $_POST['corbuilder_server_file'] ) ) {
		$files = corbuilder_transfer_server_files();
		$name  = sanitize_file_name( wp_unslash( $_POST['corbuilder_server_file'] ) );
		$path  = isset( $files[ $name ] ) ? $files[ $name ] : '';
	} elseif ( ! empty( $_FILES['corbuilder_file']['error'] ) && UPLOAD_ERR_NO_FILE !== (int) $_FILES['corbuilder_file']['error'] ) {
		corbuilder_transfer_back( array( 'type' => 'error', 'lines' => array( corbuilder_transfer_upload_error( (int) $_FILES['corbuilder_file']['error'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	}
	if ( '' === $path || ! is_readable( $path ) ) {
		corbuilder_transfer_back( array( 'type' => 'error', 'lines' => array( __( 'Aucun fichier d’export choisi. Rien n’a été modifié.', 'corbuilder' ) ) ) );
	}

	$res = corbuilder_transfer_import( $path );
	if ( $remove ) {
		@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
	}
	if ( is_wp_error( $res ) ) {
		corbuilder_transfer_back( array( 'type' => 'error', 'lines' => array( $res->get_error_message(), __( 'Rien n’a été modifié.', 'corbuilder' ) ) ) );
	}
	$lines = array(
		/* translators: 1: pages, 2: articles, 3: médias, 4: menus */
		sprintf( __( 'Import terminé : %1$d pages, %2$d articles, %3$d médias, %4$d menus.', 'corbuilder' ), $res['pages'], $res['posts'], $res['media'], $res['menus'] ),
		/* translators: 1: éléments supprimés, 2: médias supprimés */
		sprintf( __( 'Avant l’import, le site a été vidé : %1$d contenus et %2$d médias supprimés.', 'corbuilder' ), $res['wiped']['posts'], $res['wiped']['media'] ),
	);
	if ( $res['skipped'] ) {
		/* translators: %d: nombre de fichiers */
		$lines[] = sprintf( __( '%d fichier(s) de la médiathèque n’ont pas pu être importés (type non autorisé ou fichier manquant).', 'corbuilder' ), $res['skipped'] );
	}
	corbuilder_transfer_back( array( 'type' => 'success', 'lines' => $lines ) );
}
add_action( 'admin_post_corbuilder_import', 'corbuilder_transfer_import_request' );

function corbuilder_transfer_page() {
	$key    = 'corbuilder_transfer_notice_' . get_current_user_id();
	$notice = get_transient( $key );
	delete_transient( $key );
	$files = corbuilder_transfer_server_files();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Export / import du site', 'corbuilder' ); ?></h1>

		<?php if ( is_array( $notice ) ) : ?>
			<div class="notice notice-<?php echo 'success' === $notice['type'] ? 'success' : 'error'; ?>">
				<?php foreach ( $notice['lines'] as $line ) : ?>
					<p><?php echo esc_html( $line ); ?></p>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( corbuilder_old_theme_mods() && 'leger' !== get_option( 'stylesheet' ) ) : ?>
			<h2><?php esc_html_e( 'Reprendre les réglages de Léger', 'corbuilder' ); ?></h2>
			<p>
				<?php
				echo esc_html( get_option( 'corbuilder_migrated_from_leger' )
					? __( 'Les réglages de l’ancien thème Léger ont déjà été repris à l’activation. Ce bouton les recopie une nouvelle fois : les valeurs de Léger remplacent celles de Corbuilder.', 'corbuilder' )
					: __( 'Les réglages de l’ancien thème Léger (couleurs, styles, menus, sections de toutes les pages, CSS additionnel) n’ont pas encore été repris. Léger n’est pas modifié.', 'corbuilder' ) );
				?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Les réglages de Léger vont remplacer ceux de Corbuilder. Continuer ?', 'corbuilder' ) ); ?>');">
				<input type="hidden" name="action" value="corbuilder_migrate">
				<?php wp_nonce_field( 'corbuilder_migrate' ); ?>
				<?php submit_button( __( 'Reprendre les réglages de Léger', 'corbuilder' ), 'secondary', 'submit', false ); ?>
			</form>
			<hr>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Exporter', 'corbuilder' ); ?></h2>
		<p><?php esc_html_e( 'Crée une archive (.zip) avec les pages, les articles, les motifs, les catégories, les menus, la médiathèque, les réglages du thème (Personnaliser) et les réglages généraux du site (titre, page d’accueil, adresses).', 'corbuilder' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="corbuilder_export">
			<?php wp_nonce_field( 'corbuilder_transfer_export' ); ?>
			<?php submit_button( __( 'Télécharger l’export', 'corbuilder' ), 'primary', 'submit', false ); ?>
		</form>

		<hr>

		<h2><?php esc_html_e( 'Importer', 'corbuilder' ); ?></h2>
		<div class="notice notice-warning inline">
			<p><strong><?php esc_html_e( 'L’import vide d’abord entièrement ce site', 'corbuilder' ); ?></strong> : <?php esc_html_e( 'pages, articles, motifs, médias, menus, catégories et réglages du thème sont supprimés, puis remplacés par le contenu de l’archive. Les utilisateurs, les plugins et le thème ne sont pas touchés. Fais une sauvegarde avant si ce site contient quelque chose à garder.', 'corbuilder' ); ?></p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="corbuilder_import">
			<?php wp_nonce_field( 'corbuilder_transfer_import' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="corbuilder_file"><?php esc_html_e( 'Archive d’export (.zip)', 'corbuilder' ); ?></label></th>
					<td>
						<input type="file" id="corbuilder_file" name="corbuilder_file" accept=".zip">
						<p class="description">
							<?php
							/* translators: %s: taille maximale */
							printf( esc_html__( 'Taille maximale acceptée par ton hébergeur : %s.', 'corbuilder' ), esc_html( size_format( wp_max_upload_size() ) ) );
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="corbuilder_server_file"><?php esc_html_e( 'ou archive déjà déposée sur le serveur', 'corbuilder' ); ?></label></th>
					<td>
						<select id="corbuilder_server_file" name="corbuilder_server_file">
							<option value=""><?php esc_html_e( '— Aucune —', 'corbuilder' ); ?></option>
							<?php foreach ( array_keys( $files ) as $name ) : ?>
								<option value="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $name ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php
							/* translators: %s: chemin du dossier */
							printf( esc_html__( 'Pour une archive trop grosse : dépose-la par FTP dans %s, puis recharge cette page.', 'corbuilder' ), '<code>' . esc_html( str_replace( ABSPATH, '', corbuilder_transfer_dir() ) ) . '/</code>' );
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="corbuilder_confirm"><?php esc_html_e( 'Confirmation', 'corbuilder' ); ?></label></th>
					<td>
						<input type="text" id="corbuilder_confirm" name="corbuilder_confirm" autocomplete="off" placeholder="VIDER">
						<p class="description"><?php esc_html_e( 'Tape le mot VIDER pour confirmer que ce site sera vidé.', 'corbuilder' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Vider le site et importer', 'corbuilder' ), 'delete', 'submit', false ); ?>
		</form>
	</div>
	<?php
}
