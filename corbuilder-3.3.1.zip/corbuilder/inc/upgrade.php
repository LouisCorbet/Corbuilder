<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * MISES À JOUR DES DONNÉES ENREGISTRÉES
 * Exécutées une seule fois après l'installation d'une nouvelle version (le site public lit déjà les anciennes valeurs
 * correctement : cette étape ne fait que nettoyer ce qui est enregistré).
 *
 * 2.4.0 : palette de 5 couleurs. Les couleurs personnalisées des sections, de l'en-tête et du pied de page deviennent la couleur
 *         de la palette la plus proche ; « Secondaire clair » devient « Fond clair ».
 * ========================================================================= */

function corbuilder_upgrade_to_240() {
	foreach ( array( 'header', 'footer' ) as $part ) {
		$choice = (string) get_theme_mod( $part . '_color', '' );
		if ( 'custom' === $choice ) {
			set_theme_mod( $part . '_color', corbuilder_nearest_palette_key( get_theme_mod( $part . '_color_custom', '' ) ) );
		} elseif ( 'tint' === $choice ) {
			set_theme_mod( $part . '_color', 'light' );
		}
		remove_theme_mod( $part . '_color_custom' );
	}
	// Le « style du menu » n'existe plus : « Appel à l'action » et « Boutons » sont des styles d'en-tête (seul l'en-tête Classique est converti)
	$menu = (string) get_theme_mod( 'menu_style', '' );
	if ( in_array( $menu, array( 'cta', 'buttons' ), true ) && in_array( (string) get_theme_mod( 'header_style', 'classic' ), array( 'classic', '' ), true ) ) {
		set_theme_mod( 'header_style', $menu );
	}
	remove_theme_mod( 'menu_style' );
	foreach ( (array) get_theme_mods() as $key => $value ) {
		if ( is_string( $value ) && preg_match( '/^corbuilder_(p\d+|post_template)_sections$/', (string) $key ) ) {
			$new = corbuilder_migrate_sections_json( $value );
			if ( $new !== $value ) {
				set_theme_mod( $key, $new );
			}
		}
	}
}

function corbuilder_run_upgrades() {
	$done = (string) get_option( 'corbuilder_data_version', '0' );
	if ( version_compare( $done, '2.4.0', '<' ) ) {
		corbuilder_upgrade_to_240();
		update_option( 'corbuilder_data_version', '2.4.0' );
	}
}
add_action( 'admin_init', 'corbuilder_run_upgrades' );
add_action( 'after_switch_theme', 'corbuilder_run_upgrades' );
