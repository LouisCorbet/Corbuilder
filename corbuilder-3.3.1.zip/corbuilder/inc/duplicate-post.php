<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * DUPLIQUER UN ARTICLE
 * Lien « Dupliquer » dans les actions de chaque ligne de la liste des articles : crée un brouillon identique (titre suivi de « (copie) »,
 * texte, extrait, catégories, étiquettes, image à la une, champs personnalisés, et les sections de l'article en mode « éditeur par sections »).
 * ========================================================================= */

function corbuilder_can_duplicate( $post ) {
	return $post && 'post' === $post->post_type && current_user_can( 'edit_posts' ) && current_user_can( 'edit_post', $post->ID );
}

function corbuilder_duplicate_row_action( $actions, $post ) {
	if ( corbuilder_can_duplicate( $post ) && 'auto-draft' !== $post->post_status ) {
		$url = wp_nonce_url( admin_url( 'admin.php?action=corbuilder_duplicate&post=' . (int) $post->ID ), 'corbuilder_duplicate_' . (int) $post->ID );
		$actions['corbuilder_duplicate'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Dupliquer', 'corbuilder' ) . '</a>';
	}
	return $actions;
}
add_filter( 'post_row_actions', 'corbuilder_duplicate_row_action', 20, 2 );

/* Crée la copie (brouillon) et retourne son numéro, ou 0 en cas d'échec */
function corbuilder_duplicate_post_copy( $post ) {
	$title = trim( (string) $post->post_title );
	$data  = array(
		'post_type'      => $post->post_type,
		'post_status'    => 'draft',
		/* translators: %s : titre de l'article copié */
		'post_title'     => sprintf( __( '%s (copie)', 'corbuilder' ), '' !== $title ? $title : __( '(sans titre)', 'corbuilder' ) ),
		'post_content'   => $post->post_content,
		'post_excerpt'   => $post->post_excerpt,
		'post_author'    => get_current_user_id(),
		'post_parent'    => $post->post_parent,
		'menu_order'     => $post->menu_order,
		'comment_status' => $post->comment_status,
		'ping_status'    => $post->ping_status,
		'post_password'  => $post->post_password,
	);
	$new = wp_insert_post( wp_slash( $data ), true );
	if ( is_wp_error( $new ) || ! $new ) {
		return 0;
	}
	foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) { // catégories, étiquettes, format
		$terms = wp_get_object_terms( $post->ID, $taxonomy, array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $terms ) && $terms ) {
			wp_set_object_terms( $new, array_map( 'intval', $terms ), $taxonomy );
		}
	}
	// Champs personnalisés (dont l'image à la une et _corbuilder_sections), sauf ceux qui sont propres à l'article d'origine
	$skip = array( '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_trash_meta_status', '_wp_trash_meta_time', '_wp_desired_post_slug' );
	foreach ( array_keys( (array) get_post_meta( $post->ID ) ) as $key ) {
		if ( in_array( $key, $skip, true ) ) {
			continue;
		}
		foreach ( get_post_meta( $post->ID, $key, false ) as $value ) {
			add_post_meta( $new, $key, wp_slash( $value ) );
		}
	}
	return (int) $new;
}

function corbuilder_duplicate_post() {
	$id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	check_admin_referer( 'corbuilder_duplicate_' . $id );
	$post = get_post( $id );
	if ( ! corbuilder_can_duplicate( $post ) ) {
		wp_die( esc_html__( 'Tu ne peux pas dupliquer cet article.', 'corbuilder' ), '', array( 'response' => 403 ) );
	}
	$new = corbuilder_duplicate_post_copy( $post );
	if ( ! $new ) {
		wp_die( esc_html__( 'La copie de l’article a échoué.', 'corbuilder' ) );
	}
	wp_safe_redirect( add_query_arg( 'corbuilder_duplicated', $new, admin_url( 'edit.php' ) ) );
	exit;
}
add_action( 'admin_action_corbuilder_duplicate', 'corbuilder_duplicate_post' );

/* Message après la copie, avec le lien vers le brouillon */
function corbuilder_duplicate_notice() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'edit-post' !== $screen->id || empty( $_GET['corbuilder_duplicated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- simple affichage d'un message
		return;
	}
	$id   = absint( $_GET['corbuilder_duplicated'] ); // phpcs:ignore WordPress.Security.NonceVerification
	$post = get_post( $id );
	if ( ! $post || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Article dupliqué en brouillon :', 'corbuilder' ) . ' <a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( $post->post_title ) . '</a></p></div>';
}
add_action( 'admin_notices', 'corbuilder_duplicate_notice' );
