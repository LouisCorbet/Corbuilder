<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * PANNEAU LATÉRAL
 * Une colonne à côté de la page (ou du modèle des articles), à gauche ou à droite, dont la largeur est un pourcentage de l'écran.
 * Chaque type de panneau est un dossier panels/<type>/ (panel.php + preview.svg), comme les sections.
 * Sur mobile et tablette, le panneau devient un volet qui coulisse depuis le bord de l'écran (assets/panel.js).
 * Réglage enregistré (JSON) : corbuilder_p<page>_panel (une page) ou corbuilder_post_template_panel (tous les articles).
 *   { "type": "posts-list", "side": "right", "width": 33, "data": { … } }
 * « data » regroupe, pour tous les types : le texte (titre H2, sous-titre H3, paragraphe, alignement), le fond (image, couleur,
 * dégradé, opacité, flou, texte clair ou foncé, ombre) et les champs propres au type.
 * ========================================================================= */

define( 'CORBUILDER_PANEL_MIN', 20 ); // % de l'écran
define( 'CORBUILDER_PANEL_MAX', 50 );
define( 'CORBUILDER_PANEL_DEFAULT', 33 );

/* Types de panneau disponibles */
function corbuilder_get_panels() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = corbuilder_load_modules( 'panels', 'panel.php', array( 'render' ), array( 'fields' => array(), 'defaults' => array() ) );
	foreach ( $cache as $id => $def ) {
		$cache[ $id ]['fields'] = corbuilder_normalize_fields( $def['fields'] );
	}
	return $cache;
}

/* Mise en page (enregistrée à part des données) : le côté et la largeur */
function corbuilder_panel_layout_fields() {
	return corbuilder_normalize_fields( array(
		'side'  => array(
			'type'    => 'choice',
			'label'   => __( 'Côté du panneau', 'corbuilder' ),
			'choices' => function () {
				return array(
					'right' => array( 'label' => __( 'À droite', 'corbuilder' ), 'preview' => corbuilder_path_to_url( get_template_directory() . '/panels/side-right.svg' ) ),
					'left'  => array( 'label' => __( 'À gauche', 'corbuilder' ), 'preview' => corbuilder_path_to_url( get_template_directory() . '/panels/side-left.svg' ) ),
				);
			},
			'default' => 'right',
		),
		'width' => array(
			'type'    => 'range',
			'label'   => __( 'Largeur du panneau (% de l’écran, sur ordinateur)', 'corbuilder' ),
			'min'     => CORBUILDER_PANEL_MIN,
			'max'     => CORBUILDER_PANEL_MAX,
			'step'    => 1,
			'default' => CORBUILDER_PANEL_DEFAULT,
		),
	) );
}

/* Texte du panneau, comme l'en-tête des sections : titre (H2), sous-titre (H3), paragraphe et alignement */
function corbuilder_panel_text_fields() {
	return corbuilder_normalize_fields( array(
		'title'    => array( 'type' => 'multiline', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle' => array( 'type' => 'multiline', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'     => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
	) + corbuilder_head_align_fields( 'left' ) );
}

/* Fond du panneau : les réglages de fond des sections (couleur ou dégradé, opacité, image, flou, texte clair ou foncé, ombre).
   Pas d'espacement, de transition, de visibilité, d'animation ni d'ancre : le panneau est une colonne, pas une bande de page. */
function corbuilder_panel_style_fields() {
	$keep = array( 'bg_mode', 'bg_color', 'bg_color2', 'bg_angle', 'bg_opacity', 'bg_opacity2', 'bg_image', 'bg_blur', 'text_tone', 'text_shadow' );
	return corbuilder_normalize_fields( array_intersect_key( corbuilder_common_fields(), array_flip( $keep ) ) );
}

/* Tous les champs de « data » d'un type de panneau : texte, champs du type, puis fond */
function corbuilder_panel_data_fields( $def ) {
	return corbuilder_panel_text_fields() + $def['fields'] + corbuilder_panel_style_fields();
}

/* Valeurs par défaut de « data » pour un type de panneau */
function corbuilder_panel_data_defaults( $def ) {
	return array_merge( corbuilder_field_defaults( corbuilder_panel_data_fields( $def ) ), (array) $def['defaults'] );
}

/* Nettoyage du réglage : JSON valide d'un panneau qui existe, ou chaîne vide (pas de panneau) */
function corbuilder_sanitize_panel( $value ) {
	$raw = json_decode( is_string( $value ) ? $value : '', true );
	if ( ! is_array( $raw ) || empty( $raw['type'] ) || ! is_string( $raw['type'] ) ) {
		return '';
	}
	$panels = corbuilder_get_panels();
	$type   = sanitize_key( $raw['type'] );
	if ( ! isset( $panels[ $type ] ) ) {
		return '';
	}
	$layout = corbuilder_sanitize_fields( corbuilder_panel_layout_fields(), $raw );
	$in     = ( isset( $raw['data'] ) && is_array( $raw['data'] ) ) ? $raw['data'] : array();
	$data   = corbuilder_sanitize_fields( corbuilder_panel_data_fields( $panels[ $type ] ), $in );
	if ( empty( $data['bg_image'] ) ) { // sans image de fond, la couleur est toujours pleine (100 %)
		$data['bg_opacity']  = 100;
		$data['bg_opacity2'] = 100;
	}
	return wp_json_encode( array(
		'type'  => $type,
		'side'  => $layout['side'],
		'width' => (int) $layout['width'],
		'data'  => $data,
	) );
}

/* Panneau enregistré sous une clé de réglage (null s'il n'y en a pas) */
function corbuilder_get_panel_by_key( $key ) {
	$raw = json_decode( (string) get_theme_mod( $key, '' ), true );
	if ( ! is_array( $raw ) || empty( $raw['type'] ) || ! is_string( $raw['type'] ) ) {
		return null;
	}
	$panels = corbuilder_get_panels();
	if ( ! isset( $panels[ $raw['type'] ] ) ) {
		return null;
	}
	$def = $panels[ $raw['type'] ];
	return array(
		'type'  => $raw['type'],
		'def'   => $def,
		'side'  => ( isset( $raw['side'] ) && 'left' === $raw['side'] ) ? 'left' : 'right',
		'width' => isset( $raw['width'] ) ? max( CORBUILDER_PANEL_MIN, min( CORBUILDER_PANEL_MAX, (int) $raw['width'] ) ) : CORBUILDER_PANEL_DEFAULT,
		'raw'   => ( isset( $raw['data'] ) && is_array( $raw['data'] ) ) ? $raw['data'] : array(),
		'data'  => array_merge( corbuilder_panel_data_defaults( $def ), ( isset( $raw['data'] ) && is_array( $raw['data'] ) ) ? $raw['data'] : array() ),
	);
}

/* Panneau d'une page, prêt à afficher (null : pas de panneau, ou panneau vide pour les visiteurs) */
function corbuilder_get_page_panel( $pid ) {
	return corbuilder_prepare_panel( corbuilder_get_panel_by_key( 'corbuilder_p' . (int) $pid . '_panel' ), $pid );
}

/* Panneau du modèle des articles, pour l'article en cours */
function corbuilder_get_post_template_panel() {
	return corbuilder_prepare_panel( corbuilder_get_panel_by_key( 'corbuilder_post_template_panel' ), get_queried_object_id() );
}

function corbuilder_prepare_panel( $panel, $pid ) {
	if ( ! $panel ) {
		return null;
	}
	ob_start();
	call_user_func( $panel['def']['render'], $panel['data'], (object) array( 'pid' => (int) $pid ) );
	$panel['html'] = trim( (string) ob_get_clean() );
	if ( '' === $panel['html'] && ! is_customize_preview() ) { // panneau sans rien à montrer : pas de colonne vide
		return null;
	}
	$panel['head'] = corbuilder_section_head_html( array_merge( array( 'merge_heading' => false, 'chips' => array() ), $panel['data'] ) ); // titre, sous-titre, paragraphe
	$panel['look'] = corbuilder_panel_look( $panel );
	return $panel;
}

/* Fond du panneau : mêmes calculs que pour une section (couleur ou dégradé, opacité, image, texte clair ou foncé) */
function corbuilder_panel_look( $panel ) {
	$data = array_merge( corbuilder_field_defaults( corbuilder_common_fields() ), $panel['data'] );
	$look = corbuilder_section_look( array(
		'def'  => array( 'animate' => false, 'classes' => null ),
		'data' => $data,
		'item' => array( 'type' => 'panel', 'id' => 'panel', 'data' => $panel['raw'] ),
	) );
	$img = '';
	if ( $look['image'] ) {
		$blur = isset( $data['bg_blur'] ) ? (string) $data['bg_blur'] : 'none';
		$lvls = corbuilder_blur_levels();
		$img  = wp_get_attachment_image( $look['image'], 'large', false, array(
			'class' => 'section__bgimg' . ( isset( $lvls[ $blur ] ) ? ' section__bgimg--blur section__bgimg--blur-' . $blur : '' ),
			'alt'   => '',
		) );
	}
	return array(
		'classes' => array_values( array_intersect( $look['classes'], array( 'has-bg-image', 'is-light-text', 'has-text-shadow' ) ) ),
		'vars'    => $look['vars'],
		'image'   => $img,
	);
}

/* Ouvre la mise en page « contenu + panneau » : à appeler avant le contenu de la page, puis corbuilder_panel_close() après */
function corbuilder_panel_open( $panel ) {
	if ( ! $panel ) {
		return;
	}
	wp_enqueue_script( 'corbuilder-panel', get_template_directory_uri() . '/assets/panel.js', array(), CORBUILDER_VERSION . '.' . (int) @filemtime( get_template_directory() . '/assets/panel.js' ), true );
	echo '<div class="has-panel has-panel--' . esc_attr( $panel['side'] ) . '" style="--panel-w:' . (int) $panel['width'] . '%">';
	echo '<div class="has-panel__main">';
}

function corbuilder_panel_close( $panel ) {
	if ( ! $panel ) {
		return;
	}
	echo '</div>'; // .has-panel__main
	echo '<aside id="side-panel" class="side-panel" aria-label="' . esc_attr__( 'Panneau latéral', 'corbuilder' ) . '" data-side="' . esc_attr( $panel['side'] ) . '">';
	echo '<button type="button" class="side-panel__handle" aria-controls="side-panel" aria-expanded="false" data-label-open="' . esc_attr__( 'Ouvrir le panneau latéral', 'corbuilder' ) . '" data-label-close="' . esc_attr__( 'Fermer le panneau latéral', 'corbuilder' ) . '">';
	echo '<span class="screen-reader-text">' . esc_html__( 'Ouvrir le panneau latéral', 'corbuilder' ) . '</span><span class="side-panel__chevron" aria-hidden="true"></span></button>';
	$look = $panel['look'];
	echo '<div class="side-panel__box ' . esc_attr( implode( ' ', $look['classes'] ) ) . '"' . ( $look['vars'] ? ' style="' . esc_attr( $look['vars'] ) . '"' : '' ) . '>';
	echo $look['image']; // phpcs:ignore WordPress.Security.EscapeOutput -- image WordPress native
	echo '<div class="side-panel__inner">' . $panel['head'] . $panel['html'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML produit par le type de panneau
	echo '</div></aside></div>';
	// Sans JavaScript, le panneau ne peut pas coulisser : sur mobile et tablette, il s'affiche simplement sous le contenu
	echo '<noscript><style>@media (max-width:1024px){.side-panel{position:static;width:auto;transform:none;box-shadow:none}.side-panel__handle{display:none}.side-panel__inner{height:auto;padding:2rem 1.25rem}}</style></noscript>';
}

/* ---------- Articles : requête commune aux sections et aux panneaux « Liste d'articles » ---------- */

/* Étiquettes du site (adresse => nom), pour le filtre des listes d'articles */
function corbuilder_tag_choices() {
	static $cache = null;
	if ( null === $cache ) {
		$cache = array();
		$terms = get_terms( array( 'taxonomy' => 'post_tag', 'hide_empty' => false, 'orderby' => 'name' ) );
		foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) {
			$cache[ $term->slug ] = html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' );
		}
	}
	return $cache;
}

/* Articles d'une liste : les plus récents, éventuellement limités aux étiquettes choisies (au moins une des étiquettes).
   Dans un article, l'article en cours est exclu. */
function corbuilder_posts_list_get( $d ) {
	$args = array(
		'post_type'   => 'post',
		'post_status' => 'publish',
		'numberposts' => max( 1, min( 24, (int) $d['count'] ) ),
		'orderby'     => 'date',
		'order'       => 'DESC',
	);
	$tags = array_values( array_filter( array_map( 'sanitize_title', array_map( 'strval', ( isset( $d['tags'] ) && is_array( $d['tags'] ) ) ? $d['tags'] : array() ) ) ) );
	if ( $tags ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'post_tag', 'field' => 'slug', 'terms' => $tags ) );
	}
	if ( is_singular( 'post' ) ) {
		$args['exclude'] = array( get_queried_object_id() );
	}
	return get_posts( $args );
}

/* ---------- Schéma transmis au JavaScript du Customizer ---------- */
function corbuilder_panels_js_schema() {
	$types = array();
	foreach ( corbuilder_get_panels() as $id => $def ) {
		$types[ $id ] = array(
			'label'       => $def['label'],
			'description' => $def['description'],
			'preview'     => $def['preview'],
			'fields'      => corbuilder_export_fields( $def['fields'] ),
			'defaults'    => corbuilder_panel_data_defaults( $def ),
		);
	}
	$layout = corbuilder_panel_layout_fields();
	return array(
		'types'    => $types,
		'layout'   => corbuilder_export_fields( $layout ),
		'text'     => corbuilder_export_fields( corbuilder_panel_text_fields() ),
		'style'    => corbuilder_export_fields( corbuilder_panel_style_fields() ),
		'defaults' => corbuilder_field_defaults( $layout ),
	);
}
