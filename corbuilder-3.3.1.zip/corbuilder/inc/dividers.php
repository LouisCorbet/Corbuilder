<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * FORME DE FIN DE SECTION : CHOIX GLOBAL
 * Style → Formes de fin de section : un choix (aucune, vague, courbe, diagonale) appliqué en un clic à TOUTES les sections du
 * site (pages et modèle des articles), en remplaçant le choix de chaque section ; chaque section reste ensuite modifiable.
 *
 * Fonctionnement : le JavaScript du Customizer réécrit la forme de toutes les sections (l'aperçu se met à jour tout de suite,
 * l'enregistrement est normal) et note l'action dans le réglage « divider_apply » : { "shape": …, "t": horodatage }.
 * Ce réglage sert aussi au serveur :
 *  - l'éditeur de contenu n'a pas le droit de changer le style d'une section ; le serveur n'accepte de sa part la forme de fin
 *    de section que si elle est identique à celle du réglage « divider_apply » (donc uniquement via ce choix global) ;
 *  - après l'enregistrement, le serveur applique la forme au modèle des articles et aux pages que le JavaScript n'a pas pu
 *    traiter (l'éditeur de contenu n'a pas accès au modèle des articles dans Personnaliser).
 * ========================================================================= */

/* Valeur du réglage nettoyée : JSON { shape, t } ou chaîne vide */
function corbuilder_sanitize_divider_apply( $value ) {
	$v = json_decode( is_string( $value ) ? $value : '', true );
	if ( ! is_array( $v ) || empty( $v['shape'] ) || ! is_string( $v['shape'] ) || ! array_key_exists( $v['shape'], corbuilder_divider_choices() ) ) {
		return '';
	}
	return wp_json_encode( array( 'shape' => $v['shape'], 't' => ( isset( $v['t'] ) && is_numeric( $v['t'] ) ) ? max( 0, (int) $v['t'] ) : 0 ) );
}

/* Choix global envoyé avec l'enregistrement en cours : array( 'shape' => …, 't' => … ) ou null.
   Il n'est pris en compte que si l'utilisateur a le droit de le faire (administrateur, ou éditeur de contenu quand la zone est cochée). */
function corbuilder_posted_divider_apply( $manager ) {
	if ( ! $manager || ( ! current_user_can( 'edit_theme_options' ) && ! corbuilder_mod( 'editor_zone_dividers' ) ) ) {
		return null;
	}
	$posted = $manager->unsanitized_post_values();
	if ( empty( $posted['divider_apply'] ) ) {
		return null;
	}
	$v = json_decode( corbuilder_sanitize_divider_apply( $posted['divider_apply'] ), true );
	return $v ? $v : null;
}

/* Remplace la forme de fin de chaque section d'une liste (JSON) */
function corbuilder_divider_set_all( $json, $shape ) {
	$items = json_decode( is_string( $json ) ? $json : '', true );
	if ( ! is_array( $items ) ) {
		return $json;
	}
	foreach ( $items as $i => $item ) {
		if ( is_array( $item ) ) {
			if ( ! isset( $item['data'] ) || ! is_array( $item['data'] ) ) {
				$items[ $i ]['data'] = array();
			}
			$items[ $i ]['data']['divider'] = $shape;
		}
	}
	return wp_json_encode( $items );
}

/* Après l'enregistrement : la forme choisie est appliquée à toutes les listes de sections (une seule fois par action) */
function corbuilder_divider_apply_after_save( $manager ) {
	$apply = corbuilder_posted_divider_apply( $manager );
	if ( ! $apply || (int) $apply['t'] <= (int) get_option( 'corbuilder_divider_t', 0 ) ) {
		return;
	}
	update_option( 'corbuilder_divider_t', (int) $apply['t'] );
	foreach ( (array) get_theme_mods() as $key => $value ) {
		if ( is_string( $value ) && preg_match( '/^corbuilder_(p\d+|post_template)_sections$/', (string) $key ) ) {
			$new = corbuilder_divider_set_all( $value, $apply['shape'] );
			if ( $new !== $value ) {
				set_theme_mod( $key, $new );
			}
		}
	}
}
add_action( 'customize_save_after', 'corbuilder_divider_apply_after_save' );
