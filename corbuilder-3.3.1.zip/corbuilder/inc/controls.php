<?php
defined( 'ABSPATH' ) || exit;

/* Choix par vignettes (styles, en-têtes, pieds de page) : chaque élément a un libellé et une image d'aperçu. */
class Corbuilder_Choice_Control extends WP_Customize_Control {
	public $type  = 'corbuilder_choice';
	public $items = array(); // id => array( label, description, preview )

	protected function render_content() {
		$name = '_customize-choice-' . $this->id;
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-choices">
			<?php foreach ( $this->items as $id => $item ) : ?>
				<label class="corbuilder-choice" title="<?php echo esc_attr( isset( $item['description'] ) ? $item['description'] : '' ); ?>">
					<input type="radio" class="screen-reader-text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $id ); ?>" <?php $this->link(); ?> <?php checked( $this->value(), $id ); ?>>
					<span class="corbuilder-choice__img">
						<?php if ( ! empty( $item['preview'] ) ) : ?>
							<img src="<?php echo esc_url( $item['preview'] ); ?>" alt="" loading="lazy">
						<?php else : ?>
							<span class="corbuilder-choice__ph"><?php echo esc_html( mb_substr( $item['label'], 0, 1 ) ); ?></span>
						<?php endif; ?>
					</span>
					<span class="corbuilder-choice__label"><?php echo esc_html( $item['label'] ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
		<?php
	}
}

/* Liste des sections d'une page. L'interface est construite par assets/customizer.js à partir
   du schéma des sections ; la valeur du réglage est un JSON nettoyé côté serveur. */
class Corbuilder_Sections_Control extends WP_Customize_Control {
	public $type    = 'corbuilder_sections';
	public $context = 'page'; // 'page' ou 'post' (modèle des articles)

	public function to_json() {
		parent::to_json();
		$this->json['context'] = $this->context;
	}

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-sections">
			<div class="corbuilder-sections__list corbuilder-list"></div>
			<button type="button" class="button button-primary corbuilder-sections__toggle"><?php esc_html_e( '+ Ajouter une section', 'corbuilder' ); ?></button>
			<div class="corbuilder-picker"></div>
		</div>
		<?php
	}
}

/* Panneau latéral d'une page ou du modèle des articles : « + Ajouter un panneau latéral », vignettes de choix du type, puis ses réglages.
   L'interface est construite par assets/customizer.js ; la valeur du réglage est un JSON nettoyé côté serveur (inc/panels.php). */
class Corbuilder_Panel_Control extends WP_Customize_Control {
	public $type = 'corbuilder_panel';

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-panel">
			<div class="corbuilder-panel__current"></div>
			<button type="button" class="button button-primary corbuilder-panel__toggle"><?php esc_html_e( '+ Ajouter un panneau latéral', 'corbuilder' ); ?></button>
			<div class="corbuilder-picker corbuilder-panel__picker"></div>
		</div>
		<?php
	}
}

/* Sections proposées dans les articles : les mêmes vignettes que « + Ajouter une section », qu'on active ou retire d'un clic.
   L'interface est construite par assets/customizer.js ; la valeur du réglage est la liste JSON des types retirés. */
class Corbuilder_Body_Sections_Control extends WP_Customize_Control {
	public $type = 'corbuilder_body_sections';

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-picker corbuilder-bodysections is-open"></div>
		<?php
	}
}

/* Forme de fin de section appliquée à toutes les sections : une liste et un bouton ; le JavaScript (assets/customizer.js) réécrit la
   forme de chaque section, puis note l'action dans le réglage « divider_apply » (voir inc/dividers.php). */
class Corbuilder_Divider_Control extends WP_Customize_Control {
	public $type = 'corbuilder_divider';

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<div class="corbuilder-divider">
			<label>
				<span class="corbuilder-label"><?php esc_html_e( 'Forme choisie', 'corbuilder' ); ?></span>
				<select class="corbuilder-divider__shape">
					<?php foreach ( corbuilder_divider_choices() as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<button type="button" class="button button-primary corbuilder-divider__apply"><?php esc_html_e( 'Appliquer à toutes les sections', 'corbuilder' ); ?></button>
			<p class="description corbuilder-divider__done" hidden></p>
		</div>
		<?php
	}
}

/* Simple affichage d'information (aucun réglage enregistré) : sert à montrer la version du thème. */
class Corbuilder_Info_Control extends WP_Customize_Control {
	public $type = 'corbuilder_info';

	protected function render_content() {
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<?php
	}
}

/* Historique des versions du thème (aucun réglage enregistré) */
class Corbuilder_Changelog_Control extends WP_Customize_Control {
	public $type = 'corbuilder_changelog';

	protected function render_content() {
		require_once get_template_directory() . '/inc/changelog.php';
		$types = corbuilder_changelog_types();
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<ul class="corbuilder-changelog">
			<?php
			$first = true;
			foreach ( corbuilder_changelog() as $version => $lines ) :
				?>
				<li>
					<details<?php echo $first ? ' open' : ''; ?>>
						<summary><strong><?php echo esc_html( $version ); ?></strong></summary>
						<ul>
							<?php foreach ( $lines as $line ) : ?>
								<li><span class="corbuilder-pill corbuilder-pill--<?php echo esc_attr( $line[0] ); ?>"><?php echo esc_html( isset( $types[ $line[0] ] ) ? $types[ $line[0] ] : $line[0] ); ?></span> <?php echo esc_html( $line[1] ); ?></li>
							<?php endforeach; ?>
						</ul>
					</details>
				</li>
				<?php
				$first = false;
			endforeach;
			?>
		</ul>
		<?php
	}
}

/* Liste de tous les articles (mode « éditeur par sections »), avec un champ de recherche : un clic ouvre les sections de l'article.
   Aucun réglage enregistré ; la liste n'est construite que dans le panneau (jamais dans l'aperçu). */
class Corbuilder_Articles_Control extends WP_Customize_Control {
	public $type = 'corbuilder_articles';

	protected function render_content() {
		$max   = 500;
		$posts = get_posts( array(
			'post_type'        => 'post',
			'post_status'      => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'numberposts'      => $max,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'suppress_filters' => true,
			'no_found_rows'    => true,
		) );
		$current = corbuilder_compose_post();
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>
		<?php if ( ! $posts ) : ?>
			<p class="description"><?php esc_html_e( 'Aucun article pour l’instant (Articles → Ajouter).', 'corbuilder' ); ?></p>
		<?php else : ?>
			<input type="search" class="corbuilder-articles__filter" placeholder="<?php esc_attr_e( 'Rechercher un article…', 'corbuilder' ); ?>">
			<ul class="corbuilder-articles">
				<?php
				foreach ( $posts as $post ) {
					if ( ! corbuilder_can_compose( $post ) ) {
						continue;
					}
					$status = get_post_status_object( $post->post_status );
					$title  = '' !== trim( (string) $post->post_title ) ? $post->post_title : __( '(sans titre)', 'corbuilder' );
					?>
					<li>
						<a class="corbuilder-articles__row<?php echo ( $current && (int) $current->ID === (int) $post->ID ) ? ' is-current' : ''; ?>" href="<?php echo esc_url( corbuilder_compose_url( $post ) ); ?>">
							<strong><?php echo esc_html( $title ); ?></strong>
							<span><?php echo esc_html( ( $status ? $status->label : $post->post_status ) . ' · ' . get_the_date( '', $post ) ); ?></span>
						</a>
					</li>
					<?php
				}
				?>
			</ul>
			<?php if ( count( $posts ) >= $max ) : ?>
				<p class="description"><?php echo esc_html( sprintf( /* translators: %d : nombre d'articles listés */ __( 'Les %d articles les plus récents sont listés ; utilise la recherche pour les retrouver.', 'corbuilder' ), $max ) ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
		<?php
	}
}

/* Sections du corps d'un article (mode « éditeur par sections ») : la valeur est un JSON, rangé dans un champ personnalisé de l'article
   (et non dans les réglages du thème, qui deviendraient énormes avec des centaines d'articles). Réglage créé à la demande,
   sous le nom corbuilder_post_<numéro>_sections (voir inc/post-sections.php). */
class Corbuilder_Post_Sections_Setting extends WP_Customize_Setting {
	public $type    = 'corbuilder_post_sections';
	public $post_id = 0;

	public function __construct( $manager, $id, $args = array() ) {
		parent::__construct( $manager, $id, $args );
		if ( preg_match( '/^corbuilder_post_(\d+)_sections$/', (string) $id, $m ) ) {
			$this->post_id = (int) $m[1];
		}
	}

	/* Droit de modifier CET article (WordPress ne laisse pas redéfinir check_capabilities() : le droit général « edit_posts » est
	   vérifié par WordPress, celui de l'article ici, à la lecture et à l'enregistrement) */
	protected function can_edit_post() {
		return $this->post_id && current_user_can( 'edit_post', $this->post_id );
	}

	/* Valeur en cours d'aperçu si elle existe, sinon la valeur enregistrée (ou le texte de l'éditeur WordPress de l'article, repris dans une section) */
	public function value() {
		if ( ! $this->can_edit_post() ) {
			return '[]';
		}
		$posted = $this->post_value( null );
		if ( null !== $posted ) {
			return $posted;
		}
		return corbuilder_post_body_json( $this->post_id );
	}

	protected function update( $value ) {
		if ( ! $this->can_edit_post() ) {
			return false;
		}
		return corbuilder_save_post_body( $this->post_id, is_string( $value ) ? $value : '[]' );
	}
}
