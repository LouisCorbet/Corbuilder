<?php
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * PAGES LÉGALES : cinq emplacements (mentions légales, CGV, gestion des cookies,
 * politique de confidentialité, plan du site). Chacun pointe vers une page du site, choisie dans
 * Personnaliser → Réglages du thème → Pages légales. Les liens du pied de page
 * n'affichent que les pages publiées. Les modèles de texte sont dans /legal.
 * ========================================================================= */

function corbuilder_legal_pages() {
	return array(
		'mentions' => array(
			'label' => __( 'Mentions légales', 'corbuilder' ),
			'title' => __( 'Mentions légales', 'corbuilder' ),
			'slug'  => 'mentions-legales',
			'file'  => 'mentions-legales.html',
			'mod'   => 'legal_page_mentions',
		),
		'cgv'      => array(
			'label' => __( 'CGV', 'corbuilder' ),
			'title' => __( 'Conditions générales de vente', 'corbuilder' ),
			'slug'  => 'cgv',
			'file'  => 'cgv.html',
			'mod'   => 'legal_page_cgv',
		),
		'cookies'  => array(
			'label' => __( 'Gestion des cookies', 'corbuilder' ),
			'title' => __( 'Gestion des cookies', 'corbuilder' ),
			'slug'  => 'gestion-des-cookies',
			'file'  => 'cookies.html',
			'mod'   => 'legal_page_cookies',
		),
		'privacy'  => array(
			'label' => __( 'Politique de confidentialité', 'corbuilder' ),
			'title' => __( 'Politique de confidentialité', 'corbuilder' ),
			'slug'  => 'politique-de-confidentialite',
			'file'  => 'confidentialite.html',
			'mod'   => 'legal_page_privacy',
		),
		'sitemap'  => array( // pas de modèle de texte : la page contient la section « Plan du site »
			'label'    => __( 'Plan du site', 'corbuilder' ),
			'title'    => __( 'Plan du site', 'corbuilder' ),
			'slug'     => 'plan-du-site',
			'file'     => '',
			'mod'      => 'legal_page_sitemap',
			'sections' => true,
		),
	);
}

/* Page choisie pour un emplacement (0 si aucune). Pour la politique de confidentialité,
   à défaut, la page définie dans Réglages → Confidentialité de WordPress. */
function corbuilder_legal_page_id( $key ) {
	$pages = corbuilder_legal_pages();
	if ( ! isset( $pages[ $key ] ) ) {
		return 0;
	}
	$id = absint( get_theme_mod( $pages[ $key ]['mod'], 0 ) );
	if ( ! $id && 'privacy' === $key ) {
		$id = absint( get_option( 'wp_page_for_privacy_policy' ) );
	}
	return $id;
}

/* Liens à afficher : seulement les pages publiées, dans l'ordre des emplacements */
function corbuilder_legal_links() {
	$links = array();
	foreach ( corbuilder_legal_pages() as $key => $page ) {
		$id = corbuilder_legal_page_id( $key );
		if ( $id && 'publish' === get_post_status( $id ) ) {
			$links[] = array( 'label' => $page['label'], 'url' => get_permalink( $id ) );
		}
	}
	return $links;
}

function corbuilder_footer_legal_html() {
	if ( ! corbuilder_mod( 'show_legal_links' ) ) {
		return '';
	}
	$links = corbuilder_legal_links();
	if ( ! $links ) {
		return '';
	}
	$html = '<nav class="footer-legal" aria-label="' . esc_attr__( 'Informations légales', 'corbuilder' ) . '"><ul>';
	foreach ( $links as $link ) {
		$html .= '<li><a href="' . esc_url( $link['url'] ) . '">' . esc_html( $link['label'] ) . '</a></li>';
	}
	return $html . '</ul></nav>';
}

/* Bandeau des liens légaux, en bas du pied de page (vide s'il n'y a rien à afficher) */
function corbuilder_footer_legal_bar() {
	$nav = corbuilder_footer_legal_html();
	return '' === $nav ? '' : '<div class="footer-legal-bar"><div class="wrap">' . $nav . '</div></div>';
}
