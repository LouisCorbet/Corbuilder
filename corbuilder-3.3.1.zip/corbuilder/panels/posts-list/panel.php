<?php
/**
 * Panneau latéral « Liste d'articles » : les derniers articles du blog en liste compacte (miniature, date, titre) sous le titre du panneau,
 * éventuellement limités à certaines étiquettes. Dans un article, l'article en cours n'apparaît pas.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Liste d’articles', 'corbuilder' ),
	'description' => __( 'Les derniers articles du blog en liste compacte, avec un filtre possible par étiquettes.', 'corbuilder' ),
	'order'       => 10,
	'defaults'    => array( 'title' => __( 'Derniers articles', 'corbuilder' ) ), // valeurs de départ d'un nouveau panneau de ce type
	'fields'      => array(
		'count'        => array( 'type' => 'number', 'label' => __( 'Nombre d’articles', 'corbuilder' ), 'min' => 1, 'max' => 24, 'default' => 5 ),
		'tags'         => array( 'type' => 'multiselect', 'label' => __( 'Étiquettes (aucune cochée : tous les articles)', 'corbuilder' ), 'choices' => 'corbuilder_tag_choices' ),
		'show_image'   => array( 'type' => 'checkbox', 'label' => __( 'Afficher la miniature', 'corbuilder' ), 'default' => true ),
		'show_date'    => array( 'type' => 'checkbox', 'label' => __( 'Afficher la date', 'corbuilder' ), 'default' => true ),
		'show_category' => array( 'type' => 'checkbox', 'label' => __( 'Afficher la catégorie', 'corbuilder' ) ),
		'show_excerpt' => array( 'type' => 'checkbox', 'label' => __( 'Afficher un court extrait', 'corbuilder' ) ),
	),
	'render'      => function ( $d ) {
		$posts = corbuilder_posts_list_get( $d );
		if ( ! $posts ) {
			if ( is_customize_preview() ) { // message d'aide : seulement dans l'aperçu du Customizer, jamais pour les visiteurs
				echo '<p class="reusable__empty">' . esc_html__( 'Aucun article pour l’instant.', 'corbuilder' ) . '</p>';
			}
			return;
		}
		echo '<ul class="side-posts">';
		foreach ( $posts as $p ) {
			$url   = esc_url( get_permalink( $p ) );
			$img   = $d['show_image'] ? get_the_post_thumbnail( $p->ID, 'thumbnail' ) : '';
			$bits  = array();
			if ( $d['show_date'] ) {
				$bits[] = '<time datetime="' . esc_attr( get_the_date( 'c', $p ) ) . '">' . esc_html( get_the_date( '', $p ) ) . '</time>';
			}
			if ( $d['show_category'] ) {
				$cats = get_the_category( $p->ID );
				if ( $cats ) {
					$bits[] = esc_html( $cats[0]->name );
				}
			}
			$excerpt = $d['show_excerpt'] ? wp_trim_words( (string) get_the_excerpt( $p ), 18 ) : '';
			echo '<li class="side-post' . ( $img ? ' side-post--has-image' : '' ) . '">';
			if ( $img ) {
				echo '<a class="side-post__img" href="' . $url . '" tabindex="-1" aria-hidden="true">' . $img . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<div class="side-post__body">';
			if ( $bits ) {
				echo '<p class="side-post__meta">' . implode( ' · ', $bits ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<a class="side-post__title" href="' . $url . '">' . esc_html( get_the_title( $p ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( '' !== $excerpt ) {
				echo '<p class="side-post__excerpt">' . esc_html( $excerpt ) . '</p>';
			}
			echo '</div></li>';
		}
		echo '</ul>';
	},
);
