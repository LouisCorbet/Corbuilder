/* Carte des coordonnées : l'iframe n'est créée (et le site de cartes contacté) qu'au clic sur « Afficher la carte ». */
( function () {
	'use strict';

	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest && e.target.closest( '.map__load' );
		if ( ! b ) {
			return;
		}
		var m = b.closest( '.map' );
		if ( ! m ) {
			return;
		}
		var f = document.createElement( 'iframe' );
		f.src = m.getAttribute( 'data-src' );
		f.title = m.getAttribute( 'data-title' ) || 'Carte';
		f.loading = 'lazy';
		f.referrerPolicy = 'no-referrer';
		f.allowFullscreen = true;
		m.innerHTML = '';
		m.appendChild( f );
		m.classList.add( 'is-loaded' );
	} );
} )();
