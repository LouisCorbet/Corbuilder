/* Inversion : partir des couleurs calculées au repos pour respecter chaque
   contexte (en-tête, section sombre, variantes, couleurs des blocs WordPress).
   Lecture uniquement à l'entrée du pointeur ou du focus, sans boucle permanente. */
( function () {
	'use strict';
	if ( ! document.body.classList.contains( 'btn-hover-inversion' ) ) { return; }
	var selector = '.btn, .wp-block-button__link, button[type="submit"], input[type="submit"]';
	var canvas = document.createElement( 'canvas' );
	canvas.width = canvas.height = 1;
	var context = canvas.getContext( '2d', { willReadFrequently: true } );

	function rgba( color ) {
		if ( context ) {
			context.clearRect( 0, 0, 1, 1 );
			context.fillStyle = color;
			context.fillRect( 0, 0, 1, 1 );
			return context.getImageData( 0, 0, 1, 1 ).data;
		}
		var parts = color.match( /[\d.]+/g ) || [];
		return [ Number( parts[ 0 ] ) || 0, Number( parts[ 1 ] ) || 0, Number( parts[ 2 ] ) || 0,
			parts.length > 3 ? Number( parts[ 3 ] ) * 255 : ( color === 'transparent' ? 0 : 255 ) ];
	}
	function luminance( rgb ) {
		var c = [ rgb[ 0 ], rgb[ 1 ], rgb[ 2 ] ].map( function ( v ) {
			v /= 255;
			return v <= 0.04045 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
		} );
		return c[ 0 ] * 0.2126 + c[ 1 ] * 0.7152 + c[ 2 ] * 0.0722;
	}
	function contrastText( color ) {
		var l = luminance( rgba( color ) );
		var dark = luminance( [ 17, 24, 39 ] );
		var whiteRatio = 1.05 / ( l + 0.05 );
		var darkRatio = ( Math.max( l, dark ) + 0.05 ) / ( Math.min( l, dark ) + 0.05 );
		return whiteRatio >= darkRatio ? '#ffffff' : '#111827';
	}
	function prepare( button ) {
		if ( button.matches( ':disabled, [aria-disabled="true"]' ) ) { return; }
		// Retirer le survol et couper les transitions le temps de lire le vrai repos.
		button.classList.add( 'cb-hover-measure' );
		button.removeAttribute( 'data-cb-hover-ready' );
		var style = window.getComputedStyle( button );
		var background = style.backgroundColor;
		var text = style.color;
		var border = style.borderTopColor;
		var hasBorder = parseFloat( style.borderTopWidth ) > 0 && style.borderTopStyle !== 'none' && rgba( border )[ 3 ] > 0;
		if ( rgba( background )[ 3 ] === 0 ) {
			// Contour (ou texte seul) : fond rempli et texte calculé pour être lisible.
			background = hasBorder ? border : text;
			text = contrastText( background );
		} else {
			var originalBackground = background;
			background = text;
			text = originalBackground;
		}
		button.style.setProperty( '--cb-hover-bg', background );
		button.style.setProperty( '--cb-hover-fg', text );
		button.setAttribute( 'data-cb-hover-ready', '' );
		button.classList.remove( 'cb-hover-measure' );
	}
	function enter( event ) {
		var target = event.target;
		var button = target && target.closest ? target.closest( selector ) : null;
		if ( ! button || ( event.relatedTarget && button.contains( event.relatedTarget ) ) ) { return; }
		prepare( button );
	}
	document.addEventListener( 'pointerover', enter );
	document.addEventListener( 'focusin', enter );
	Array.prototype.forEach.call( document.querySelectorAll( selector ), function ( button ) {
		if ( button.matches( ':hover, :focus-visible' ) ) { prepare( button ); }
	} );
}() );
