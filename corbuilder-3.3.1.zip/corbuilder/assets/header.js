/* En-tête fixe : il se masque quand on descend et réapparaît dès qu'on remonte, même au milieu de la page.
   Il reste visible tant que le menu mobile est ouvert ou qu'un élément de l'en-tête a le focus clavier. */
( function () {
	'use strict';
	var header = document.querySelector( '.site-header' );
	if ( ! header ) { return; }
	var nav = document.getElementById( 'site-nav' );
	var last = window.pageYOffset || 0;
	var ticking = false;
	var THRESHOLD = 6;

	/* Les liens d'ancre s'arrêtent sous l'en-tête au lieu de passer derrière */
	function offset() {
		var top = parseFloat( window.getComputedStyle( header ).top ) || 0;
		document.documentElement.style.scrollPaddingTop = ( header.offsetHeight + top ) + 'px';
	}

	function update() {
		ticking = false;
		var y = window.pageYOffset || 0;
		var doc = document.documentElement.scrollHeight;
		header.classList.toggle( 'is-stuck', y > 10 ); // en-tête transparent : il prend sa couleur dès qu'on a défilé
		if ( y < 0 || y + window.innerHeight > doc + 1 ) { return; } // rebond en bout de page (iOS)
		var menuOpen = nav && nav.classList.contains( 'is-open' );
		var focusIn = header.matches( ':focus-within' );
		if ( y <= header.offsetHeight || menuOpen || focusIn ) {
			header.classList.remove( 'is-hidden' );
			last = y;
			return;
		}
		if ( Math.abs( y - last ) < THRESHOLD ) { return; }
		header.classList.toggle( 'is-hidden', y > last );
		last = y;
	}

	window.addEventListener( 'scroll', function () {
		if ( ! ticking ) {
			ticking = true;
			window.requestAnimationFrame( update );
		}
	}, { passive: true } );
	header.addEventListener( 'focusin', function () { header.classList.remove( 'is-hidden' ); } );
	window.addEventListener( 'resize', offset );
	offset();
	update();
}() );
