/* Compteurs animés : le chiffre part de 0 et monte jusqu'à sa valeur en 2 secondes, quand il devient visible.
   Sans JavaScript, ou si le visiteur a réduit les animations, le chiffre final reste affiché. */
( function () {
	'use strict';
	var els = document.querySelectorAll( '.counter__num[data-to]' );
	if ( ! els.length ) { return; }
	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	if ( reduce || ! ( 'IntersectionObserver' in window ) || ! window.requestAnimationFrame ) { return; }

	var DURATION = 2000;
	var GROUPS = { space: '\u00a0', dot: '.' };

	function format( value, el ) {
		var d = parseInt( el.getAttribute( 'data-decimals' ), 10 ) || 0;
		var parts = value.toFixed( d ).split( '.' );
		var group = GROUPS[ el.getAttribute( 'data-group' ) ];
		if ( group ) { parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, group ); }
		return d ? parts[ 0 ] + ( el.getAttribute( 'data-sep' ) || ',' ) + parts[ 1 ] : parts[ 0 ];
	}

	function run( el ) {
		var to = parseFloat( el.getAttribute( 'data-to' ) );
		var start = null;
		function step( now ) {
			if ( null === start ) { start = now; }
			var p = Math.min( ( now - start ) / DURATION, 1 );
			el.textContent = format( to * ( 1 - Math.pow( 1 - p, 3 ) ), el );
			if ( p < 1 ) {
				window.requestAnimationFrame( step );
			} else {
				el.textContent = el.getAttribute( 'data-final' ); // la valeur saisie, telle quelle
			}
		}
		window.requestAnimationFrame( step );
	}

	var io = new IntersectionObserver( function ( entries ) {
		entries.forEach( function ( e ) {
			if ( e.isIntersecting ) { run( e.target ); io.unobserve( e.target ); }
		} );
	}, { threshold: 0.4 } );

	Array.prototype.forEach.call( els, function ( el ) {
		el.textContent = format( 0, el );
		io.observe( el );
	} );
}() );
