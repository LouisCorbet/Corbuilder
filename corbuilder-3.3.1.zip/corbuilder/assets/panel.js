/* Panneau latéral sur mobile et tablette : un volet qui coulisse depuis le bord de l'écran.
   - la languette (bouton) se tire pour ouvrir le panneau, qui occupe alors tout l'écran ;
   - le panneau se referme en le faisant glisser vers son bord, ou avec la languette, la touche Échap ;
   - sur ordinateur, le panneau est une simple colonne : ce script ne fait rien. */
( function () {
	'use strict';

	var panel = document.getElementById( 'side-panel' );
	if ( ! panel ) { return; }
	var handle = panel.querySelector( '.side-panel__handle' );
	var inner  = panel.querySelector( '.side-panel__inner' );
	var label  = handle ? handle.querySelector( '.screen-reader-text' ) : null;
	if ( ! handle || ! inner ) { return; }

	var root   = document.documentElement;
	var isLeft = 'left' === panel.getAttribute( 'data-side' );
	var sign   = isLeft ? -1 : 1;                       // sens de la fermeture : vers la droite (panneau à droite) ou vers la gauche
	var mq     = window.matchMedia( '(max-width: 1024px)' );
	var open   = false;
	var drag   = null;
	var swallowClick = false;

	function sync() {
		var on = mq.matches && open;
		panel.classList.toggle( 'is-open', on );
		root.classList.toggle( 'has-panel-open', on );
		if ( mq.matches && ! open ) { inner.setAttribute( 'inert', '' ); } else { inner.removeAttribute( 'inert' ); } // fermé : hors de portée du clavier
		handle.setAttribute( 'aria-expanded', String( on ) );
		if ( label ) { label.textContent = handle.getAttribute( on ? 'data-label-close' : 'data-label-open' ) || label.textContent; }
	}

	function set( value ) {
		open = !! value;
		panel.style.transform = '';
		panel.classList.remove( 'is-dragging' );
		sync();
	}

	/* ---------- Glisser ---------- */
	function begin( e, fromHandle ) {
		if ( ! mq.matches || ( drag && drag.id !== e.pointerId ) ) { return; }
		if ( 0 !== e.button && 'mouse' === e.pointerType ) { return; }
		var w = panel.getBoundingClientRect().width || window.innerWidth;
		drag = { id: e.pointerId, x: e.clientX, y: e.clientY, w: w, c0: open ? 0 : w, c: open ? 0 : w, moved: false, handle: fromHandle, lastC: open ? 0 : w, lastT: Date.now(), v: 0 };
		if ( fromHandle ) { try { handle.setPointerCapture( e.pointerId ); } catch ( err ) { /* sans importance */ } }
	}

	function move( e ) {
		if ( ! drag || e.pointerId !== drag.id ) { return; }
		var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
		if ( ! drag.moved ) {
			if ( Math.abs( dx ) < 8 && Math.abs( dy ) < 8 ) { return; }
			if ( ! drag.handle && Math.abs( dy ) > Math.abs( dx ) ) { drag = null; return; } // défilement vertical du panneau : on ne fait rien
			drag.moved = true;
			panel.classList.add( 'is-dragging' );
			if ( ! drag.handle ) { try { inner.setPointerCapture( e.pointerId ); } catch ( err ) { /* sans importance */ } }
		}
		var c   = Math.max( 0, Math.min( drag.w, drag.c0 + sign * dx ) ); // 0 = ouvert, largeur du panneau = fermé
		var now = Date.now();
		if ( now - drag.lastT > 0 ) { drag.v = ( c - drag.lastC ) / ( now - drag.lastT ); }
		drag.lastC = c; drag.lastT = now; drag.c = c;
		panel.style.transform = 'translateX(' + ( sign * c ) + 'px)';
	}

	function end( e ) {
		if ( ! drag || e.pointerId !== drag.id ) { return; }
		var d = drag;
		drag = null;
		if ( ! d.moved ) { return; }
		swallowClick = true; // le « clic » qui suit un glissement ne doit rien déclencher
		window.setTimeout( function () { swallowClick = false; }, 0 );
		if ( Math.abs( d.v ) > 0.4 ) { set( d.v < 0 ); return; } // geste rapide : le sens décide
		set( d.c < d.w / 2 );
	}

	function cancel( e ) {
		if ( ! drag || e.pointerId !== drag.id ) { return; }
		var moved = drag.moved;
		drag = null;
		if ( moved ) { set( open ); }
	}

	[ [ handle, true ], [ inner, false ] ].forEach( function ( pair ) {
		var el = pair[ 0 ], fromHandle = pair[ 1 ];
		el.addEventListener( 'pointerdown', function ( e ) { begin( e, fromHandle ); } );
		el.addEventListener( 'pointermove', move );
		el.addEventListener( 'pointerup', end );
		el.addEventListener( 'pointercancel', cancel );
	} );

	panel.addEventListener( 'click', function ( e ) {
		if ( swallowClick ) { e.preventDefault(); e.stopPropagation(); }
	}, true );

	handle.addEventListener( 'click', function () { set( ! open ); } );

	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' === e.key && open && mq.matches ) { set( false ); handle.focus(); }
	} );

	if ( mq.addEventListener ) { mq.addEventListener( 'change', function () { set( false ); } ); } else if ( mq.addListener ) { mq.addListener( function () { set( false ); } ); }

	sync();
} )();
