/* Visionneuse de la galerie : photo en grand, précédent / suivant, clavier (← → Échap), glissement au doigt.
   Sans JavaScript, le clic sur une vignette ouvre simplement le fichier image. */
( function () {
	'use strict';

	var links = document.querySelectorAll( 'a[data-corbuilder-lightbox]' );
	if ( ! links.length ) { return; }

	var groups = {};
	Array.prototype.forEach.call( links, function ( a ) {
		var g = a.getAttribute( 'data-corbuilder-lightbox' );
		( groups[ g ] = groups[ g ] || [] ).push( a );
	} );

	var box, img, caption, count, btnClose, btnPrev, btnNext, list = [], index = 0, opener = null, startX = null;

	function button( cls, label, text ) {
		var b = document.createElement( 'button' );
		b.type = 'button';
		b.className = 'lb__btn ' + cls;
		b.setAttribute( 'aria-label', label );
		b.textContent = text;
		return b;
	}

	function build() {
		if ( box ) { return; }
		box = document.createElement( 'div' );
		box.className = 'lb';
		box.hidden = true;
		box.setAttribute( 'role', 'dialog' );
		box.setAttribute( 'aria-modal', 'true' );
		box.setAttribute( 'aria-label', 'Visionneuse de photos' );

		var fig = document.createElement( 'figure' );
		fig.className = 'lb__figure';
		img = document.createElement( 'img' );
		img.className = 'lb__img';
		caption = document.createElement( 'figcaption' );
		caption.className = 'lb__caption';
		fig.appendChild( img );
		fig.appendChild( caption );

		count = document.createElement( 'span' );
		count.className = 'lb__count';
		btnClose = button( 'lb__close', 'Fermer', '×' );
		btnPrev = button( 'lb__prev', 'Photo précédente', '‹' );
		btnNext = button( 'lb__next', 'Photo suivante', '›' );

		box.appendChild( fig );
		box.appendChild( count );
		box.appendChild( btnClose );
		box.appendChild( btnPrev );
		box.appendChild( btnNext );
		document.body.appendChild( box );

		btnClose.addEventListener( 'click', close );
		btnPrev.addEventListener( 'click', function () { go( -1 ); } );
		btnNext.addEventListener( 'click', function () { go( 1 ); } );
		box.addEventListener( 'click', function ( e ) { if ( e.target === box ) { close(); } } );
		box.addEventListener( 'touchstart', function ( e ) { startX = e.changedTouches[ 0 ].clientX; }, { passive: true } );
		box.addEventListener( 'touchend', function ( e ) {
			if ( null === startX ) { return; }
			var dx = e.changedTouches[ 0 ].clientX - startX;
			startX = null;
			if ( Math.abs( dx ) > 50 ) { go( dx < 0 ? 1 : -1 ); }
		}, { passive: true } );
	}

	function show() {
		var a = list[ index ];
		var thumb = a.querySelector( 'img' );
		img.src = a.getAttribute( 'href' );
		img.alt = thumb ? thumb.getAttribute( 'alt' ) || '' : '';
		var text = a.getAttribute( 'data-caption' ) || '';
		caption.textContent = text;
		caption.hidden = ! text;
		count.textContent = ( index + 1 ) + ' / ' + list.length;
		box.classList.toggle( 'lb--single', list.length < 2 );
		// précharge les voisines
		[ 1, -1 ].forEach( function ( d ) {
			if ( list.length > 1 ) { new Image().src = list[ ( index + d + list.length ) % list.length ].getAttribute( 'href' ); }
		} );
	}

	function go( d ) {
		if ( list.length < 2 ) { return; }
		index = ( index + d + list.length ) % list.length;
		show();
	}

	function open( a ) {
		build();
		list = groups[ a.getAttribute( 'data-corbuilder-lightbox' ) ];
		index = list.indexOf( a );
		opener = a;
		box.hidden = false;
		document.body.classList.add( 'lb-open' );
		show();
		btnClose.focus();
	}

	function close() {
		if ( ! box || box.hidden ) { return; }
		box.hidden = true;
		document.body.classList.remove( 'lb-open' );
		img.removeAttribute( 'src' );
		if ( opener ) { opener.focus(); }
	}

	document.addEventListener( 'keydown', function ( e ) {
		if ( ! box || box.hidden ) { return; }
		if ( 'Escape' === e.key ) { close(); }
		else if ( 'ArrowRight' === e.key ) { go( 1 ); }
		else if ( 'ArrowLeft' === e.key ) { go( -1 ); }
		else if ( 'Tab' === e.key ) { // le focus reste dans la visionneuse
			var f = [ btnClose, btnPrev, btnNext ].filter( function ( b ) { return b.offsetParent !== null || list.length > 1 || b === btnClose; } );
			var i = f.indexOf( document.activeElement );
			e.preventDefault();
			f[ ( i + ( e.shiftKey ? -1 : 1 ) + f.length ) % f.length ].focus();
		}
	} );

	Array.prototype.forEach.call( links, function ( a ) {
		a.addEventListener( 'click', function ( e ) {
			if ( e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || 0 !== e.button ) { return; } // ouvertures « normales » du navigateur
			e.preventDefault();
			open( a );
		} );
	} );
}() );
