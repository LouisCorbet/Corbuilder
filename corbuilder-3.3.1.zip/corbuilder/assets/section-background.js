/* Fonds des sections : fixe, parallaxe ou dérive douce.
   Le calque reste dans sa section : pas de background-attachment:fixed, qui
   fonctionne mal sur mobile et sous les masques des séparateurs.
   Aucun effet sans JavaScript ou si le visiteur réduit les animations. */
( function () {
	'use strict';
	if ( ! window.requestAnimationFrame ) { return; }
	var layers = document.querySelectorAll( '.section > .section__bgmotion[data-bg-animation]' );
	if ( ! layers.length ) { return; }
	var media = window.matchMedia ? window.matchMedia( '(prefers-reduced-motion: reduce)' ) : null;
	var frame = null;
	var props = [ '--bg-x', '--bg-y', '--bg-inset-x', '--bg-inset-y', '--bg-height' ];
	var items = Array.prototype.map.call( layers, function ( layer ) {
		var angle = Math.random() * Math.PI * 2;
		var rawIntensity = layer.getAttribute( 'data-bg-intensity' );
		var intensity = rawIntensity === null || rawIntensity === '' ? 50 : Number( rawIntensity );
		if ( ! isFinite( intensity ) ) { intensity = 50; }
		return { layer: layer, section: layer.parentElement, mode: layer.getAttribute( 'data-bg-animation' ), visible: true,
			intensity: Math.max( 0, Math.min( 100, intensity ) ) / 50,
			x: 0, y: 0, fromX: 0, fromY: 0, angle: angle, toX: Math.cos( angle ), toY: Math.sin( angle ), elapsed: 0, duration: randomDuration(), last: null };
	} );

	function randomDuration() { return 6500 + Math.random() * 2500; }
	function set( item, key, value ) { item.layer.style.setProperty( key, value.toFixed( 3 ) + 'px' ); }
	function schedule() {
		if ( frame !== null || document.hidden || ( media && media.matches ) ) { return; }
		frame = window.requestAnimationFrame( update );
	}

	function update( now ) {
		frame = null;
		if ( document.hidden || ( media && media.matches ) ) { return; }
		var vh = window.innerHeight || document.documentElement.clientHeight;
		var moving = false;
		// Toutes les mesures avant les écritures : pas de recalcul de mise en page à chaque calque.
		var rects = items.map( function ( item ) { return item.visible ? item.section.getBoundingClientRect() : null; } );
		items.forEach( function ( item, i ) {
			var rect = rects[ i ];
			if ( ! rect || rect.height <= 0 || rect.width <= 0 || rect.bottom <= 0 || rect.top >= vh ) {
				item.last = null;
				item.layer.classList.remove( 'is-bg-animated' );
				return;
			}
			item.layer.classList.add( 'is-bg-animated' );
			if ( item.mode === 'fixed' ) {
				// L'origine de l'image reste à y=0 de la fenêtre, même quand la section défile.
				set( item, '--bg-height', Math.max( vh, rect.height ) );
				set( item, '--bg-y', -rect.top );
			} else if ( item.mode === 'parallax' ) {
				var travel = ( rect.height + vh ) * 0.11 + 2;
				set( item, '--bg-inset-y', travel );
				set( item, '--bg-height', rect.height + travel * 2 );
				set( item, '--bg-y', ( vh / 2 - rect.top - rect.height / 2 ) * 0.22 );
			} else if ( item.mode === 'movement' ) {
				// 0 : immobile ; 50 : mouvement d'origine ; 100 : amplitude et cadence doublées.
				if ( item.intensity === 0 ) {
					item.layer.classList.remove( 'is-bg-animated' );
					return;
				}
				// Déplacement proportionné à la section, perceptible en quelques secondes.
				// Les cibles sont sur une ellipse : jamais deux coordonnées proches de zéro.
				var radiusX = Math.max( 24, Math.min( 48, rect.width * 0.04 ) ) * item.intensity;
				var radiusY = Math.max( 20, Math.min( 36, rect.height * 0.06 ) ) * item.intensity;
				set( item, '--bg-inset-x', radiusX + 8 );
				set( item, '--bg-inset-y', radiusY + 8 );
				item.elapsed += item.last === null ? 0 : Math.min( 64, Math.max( 0, now - item.last ) ) * item.intensity;
				item.last = now;
				var p = Math.min( 1, item.elapsed / item.duration );
				var ease = p * p * ( 3 - 2 * p );
				item.x = item.fromX + ( item.toX - item.fromX ) * ease;
				item.y = item.fromY + ( item.toY - item.fromY ) * ease;
				set( item, '--bg-x', item.x * radiusX );
				set( item, '--bg-y', item.y * radiusY );
				if ( p >= 1 ) {
					item.fromX = item.x; item.fromY = item.y;
					// Prochaine direction nettement différente pour éviter une longue quasi-immobilité.
					item.angle += Math.PI * ( 0.6 + Math.random() * 0.8 );
					item.toX = Math.cos( item.angle ); item.toY = Math.sin( item.angle );
					item.elapsed = 0; item.duration = randomDuration();
				}
				moving = true;
			}
		} );
		if ( moving ) { schedule(); }
	}

	if ( 'IntersectionObserver' in window ) {
		var observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				items.forEach( function ( item ) {
					if ( item.section === entry.target ) { item.visible = entry.isIntersecting; }
				} );
			} );
			schedule();
		} );
		items.forEach( function ( item ) { observer.observe( item.section ); } );
	}
	if ( 'ResizeObserver' in window ) {
		var resize = new ResizeObserver( schedule );
		items.forEach( function ( item ) { resize.observe( item.section ); } );
	}
	window.addEventListener( 'scroll', schedule, { passive: true, capture: true } );
	window.addEventListener( 'resize', schedule, { passive: true } );
	window.addEventListener( 'load', schedule );
	window.addEventListener( 'pageshow', schedule );
	document.addEventListener( 'visibilitychange', function () {
		items.forEach( function ( item ) { item.last = null; } );
		if ( document.hidden && frame !== null ) { window.cancelAnimationFrame( frame ); frame = null; }
		schedule();
	} );
	function preferenceChanged() {
		if ( frame !== null ) { window.cancelAnimationFrame( frame ); frame = null; }
		items.forEach( function ( item ) {
			props.forEach( function ( prop ) { item.layer.style.removeProperty( prop ); } );
			item.layer.classList.remove( 'is-bg-animated' );
			item.last = null;
		} );
		schedule();
	}
	if ( media ) {
		if ( media.addEventListener ) { media.addEventListener( 'change', preferenceChanged ); }
		else if ( media.addListener ) { media.addListener( preferenceChanged ); }
	}
	schedule();
}() );
