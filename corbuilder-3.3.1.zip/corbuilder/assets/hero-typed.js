/* Image Head, variante « Texte animé » : les mots s'écrivent à la suite du titre, s'effacent, puis le suivant s'écrit.
   Avec « réduire les animations » activé dans le système, le premier mot reste affiché, sans mouvement. */
( function () {
	'use strict';

	var els = document.querySelectorAll( '.hero__typed' );
	if ( ! els.length ) { return; }
	if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) { return; }

	// vitesse : [écriture, effacement, pause une fois le mot écrit] en millisecondes
	var speeds = { slow: [ 110, 55, 2400 ], normal: [ 70, 35, 1800 ], fast: [ 45, 22, 1200 ] };

	Array.prototype.forEach.call( els, function ( el ) {
		var words;
		try { words = JSON.parse( el.getAttribute( 'data-words' ) || '[]' ); } catch ( e ) { words = []; }
		var out = el.querySelector( '.hero__typed-text' );
		if ( ! out || ! Array.isArray( words ) || ! words.length ) { return; }

		var sp    = speeds[ el.getAttribute( 'data-speed' ) ] || speeds.normal;
		var chars = words.map( function ( w ) { return Array.from( String( w ) ); } ); // lettres entières (accents, émojis)
		var w = 0, c = 0, erasing = false;

		function tick() {
			var cur = chars[ w ];
			if ( ! erasing ) {
				c++;
				out.textContent = cur.slice( 0, c ).join( '' );
				if ( c >= cur.length ) {
					if ( chars.length < 2 ) { return; } // un seul mot : il s'écrit une fois et reste
					erasing = true;
					return setTimeout( tick, sp[ 2 ] );
				}
				return setTimeout( tick, sp[ 0 ] );
			}
			c--;
			out.textContent = cur.slice( 0, c ).join( '' );
			if ( c <= 0 ) {
				erasing = false;
				w = ( w + 1 ) % chars.length;
				return setTimeout( tick, 350 );
			}
			return setTimeout( tick, sp[ 1 ] );
		}

		out.classList.add( 'is-typing' ); // le curseur clignotant n'apparaît qu'avec le script
		out.textContent = '';
		setTimeout( tick, 400 );
	} );
}() );
