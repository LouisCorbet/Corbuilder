</main>
<?php corbuilder_render_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>
