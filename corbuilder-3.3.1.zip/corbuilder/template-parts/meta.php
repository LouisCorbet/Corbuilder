<?php if ( 'post' === get_post_type() ) : ?>
	<div class="entry-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></div>
<?php endif; ?>
