<?php get_header(); ?>
<div class="wrap content-area">
<?php if ( have_posts() ) : ?>
	<?php if ( is_archive() ) : ?>
		<h1 class="page-title"><?php the_archive_title(); ?></h1>
	<?php elseif ( is_search() ) : ?>
		<h1 class="page-title"><?php printf( esc_html__( 'Résultats pour : %s', 'corbuilder' ), '<span>' . esc_html( get_search_query() ) . '</span>' ); ?></h1>
	<?php endif; ?>
	<?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content' ); endwhile; ?>
	<?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?>
<?php else : ?>
	<h1 class="page-title"><?php esc_html_e( 'Rien à afficher', 'corbuilder' ); ?></h1>
	<p><?php esc_html_e( 'Aucun contenu ne correspond. Essaie une recherche :', 'corbuilder' ); ?></p>
	<?php get_search_form(); ?>
<?php endif; ?>
</div>
<?php get_footer(); ?>
