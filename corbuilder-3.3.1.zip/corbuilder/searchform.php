<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="s"><?php esc_html_e( 'Rechercher', 'corbuilder' ); ?></label>
	<input type="search" id="s" class="search-field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Rechercher…', 'corbuilder' ); ?>">
	<button type="submit"><?php esc_html_e( 'OK', 'corbuilder' ); ?></button>
</form>
