<?php
defined( 'ABSPATH' ) || exit;

define( 'CORBUILDER_VERSION', '2.6.1' );

require_once get_template_directory() . '/inc/helpers.php';
require_once get_template_directory() . '/inc/modules.php';
require_once get_template_directory() . '/inc/buttons.php';
require_once get_template_directory() . '/inc/cards.php';
require_once get_template_directory() . '/inc/contact.php';
require_once get_template_directory() . '/inc/sections.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/legal.php';
require_once get_template_directory() . '/inc/migration.php';
require_once get_template_directory() . '/inc/dividers.php';
require_once get_template_directory() . '/inc/editor-role.php';
require_once get_template_directory() . '/inc/upgrade.php';
require_once get_template_directory() . '/inc/versions.php';
require_once get_template_directory() . '/inc/updates.php';

if ( is_admin() ) {
	require_once get_template_directory() . '/inc/requirements.php';
	require_once get_template_directory() . '/inc/legal-admin.php';
	require_once get_template_directory() . '/inc/transfer.php';
}

function corbuilder_setup() {
	load_theme_textdomain( 'corbuilder', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	register_nav_menus( array(
		'primary' => __( 'En-tête', 'corbuilder' ),
		'footer'  => __( 'Pied de page', 'corbuilder' ),
		'footer2' => __( 'Pied de page, 2e colonne', 'corbuilder' ),
	) );
}
add_action( 'after_setup_theme', 'corbuilder_setup' );

/* Éditeur des articles : classique par défaut (case « Articles » du Customizer). Les pages et les motifs gardent les blocs. */
function corbuilder_editor_for_posts( $use_block_editor, $post_type ) {
	if ( 'post' === $post_type && corbuilder_mod( 'classic_editor_posts' ) ) {
		return false;
	}
	return $use_block_editor;
}
add_filter( 'use_block_editor_for_post_type', 'corbuilder_editor_for_posts', 10, 2 );

/* Animation choisie (identifiant) si elle existe, sinon chaîne vide */
function corbuilder_active_animation() {
	$id   = (string) corbuilder_mod( 'animation' );
	$list = corbuilder_get_animations();
	return ( 'none' !== $id && isset( $list[ $id ] ) ) ? $id : '';
}

/* Feuilles de style : base, variables des réglages, puis uniquement les modules choisis */
function corbuilder_assets() {
	wp_enqueue_style( 'corbuilder', get_stylesheet_uri(), array(), CORBUILDER_VERSION . '.' . (int) @filemtime( get_stylesheet_directory() . '/style.css' ) ); // date du fichier : jamais de feuille de style périmée en cache
	wp_add_inline_style( 'corbuilder', corbuilder_root_css() );

	corbuilder_enqueue_module_css( 'corbuilder-global-style', corbuilder_selected( 'style' ), 'style.css' );
	corbuilder_enqueue_module_css( 'corbuilder-header-style', corbuilder_selected( 'header' ), 'header.css' );
	corbuilder_enqueue_module_css( 'corbuilder-footer-style', corbuilder_selected( 'footer' ), 'footer.css' );

	$anim = corbuilder_active_animation();
	if ( $anim ) {
		$list = corbuilder_get_animations();
		wp_enqueue_style( 'corbuilder-animation', $list[ $anim ]['uri'], array( 'corbuilder' ), CORBUILDER_VERSION );
	}

	if ( corbuilder_mod( 'header_sticky' ) ) {
		wp_enqueue_script( 'corbuilder-header', get_template_directory_uri() . '/assets/header.js', array(), CORBUILDER_VERSION, true );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'corbuilder_assets' );

/* Classes <body> */
function corbuilder_body_class( $classes ) {
	if ( 'outline' === corbuilder_mod( 'btn_style' ) ) {
		$classes[] = 'btn-outline';
	}
	if ( in_array( corbuilder_mod( 'card_style' ), array( 'strong', 'border', 'flat' ), true ) ) {
		$classes[] = 'card-' . corbuilder_mod( 'card_style' );
	}
	if ( corbuilder_surface_hex( 'header' ) ) {
		$classes[] = 'has-header-color';
	}
	if ( corbuilder_mod( 'hide_site_name_mobile' ) && has_custom_logo() ) { // sans logo, le nom reste affiché
		$classes[] = 'hide-name-mobile';
	}
	if ( corbuilder_mod( 'header_sticky' ) ) {
		$classes[] = 'has-sticky-header';
	}
	if ( in_array( corbuilder_mod( 'header_height' ), array( 'compact', 'slim' ), true ) ) {
		$classes[] = 'header-h-' . corbuilder_mod( 'header_height' );
	}
	if ( corbuilder_active_animation() ) {
		$classes[] = 'anim-' . corbuilder_active_animation();
	}
	// En-tête transparent : seulement si la page commence par une section « bandeau » (celle qui porte le H1).
	if ( corbuilder_mod( 'header_transparent' ) && is_page() ) {
		$sections = corbuilder_get_page_sections( get_queried_object_id() );
		$registry = corbuilder_get_sections();
		if ( $sections && ! empty( $registry[ $sections[0]['type'] ]['h1'] ) ) {
			$classes[] = 'header-transparent';
		}
	}
	return $classes;
}
add_filter( 'body_class', 'corbuilder_body_class' );

/* Animations : la classe « js » n'est posée que si le script est actif, le contenu reste donc visible sans JavaScript */
function corbuilder_anim_head() {
	if ( corbuilder_active_animation() ) {
		echo '<script>document.documentElement.className+=" js";</script>' . "\n";
	}
}
add_action( 'wp_head', 'corbuilder_anim_head', 1 );

function corbuilder_footer_scripts() {
	?>
<script>(function(){var b=document.querySelector('.nav-toggle'),n=document.getElementById('site-nav');if(!b||!n)return;b.addEventListener('click',function(){var o=n.classList.toggle('is-open');b.setAttribute('aria-expanded',o)})})();</script>
	<?php
	if ( corbuilder_active_animation() ) {
		?>
<script>(function(){var els=document.querySelectorAll('.anim');if(!els.length)return;var show=function(e){e.classList.add('is-in')};try{if(!('IntersectionObserver' in window)){els.forEach(show);return}var io=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){show(x.target);io.unobserve(x.target)}})},{threshold:.12});els.forEach(function(e){io.observe(e)})}catch(e){els.forEach(show)}})();</script>
		<?php
	}
}
add_action( 'wp_footer', 'corbuilder_footer_scripts', 99 );

/* Allègement : suppression des scripts emoji */
function corbuilder_cleanup() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'corbuilder_cleanup' );

add_filter( 'excerpt_length', function () { return 35; } );
add_filter( 'excerpt_more', function () { return '…'; } );
