<?php
/**
 * Section « Coordonnées » : adresse, téléphone, e-mail, horaires, réseaux sociaux et carte.
 * Les informations se saisissent une seule fois, dans Personnaliser → Coordonnées ;
 * le pied de page les utilise aussi.
 */
defined( 'ABSPATH' ) || exit;

return array(
	'label'       => __( 'Coordonnées', 'corbuilder' ),
	'description' => __( 'Affiche les coordonnées saisies dans Personnaliser → Coordonnées (adresse, téléphone, e-mail, horaires, réseaux sociaux, carte). Décoche ce que tu ne veux pas montrer ici.', 'corbuilder' ),
	'order'       => 46,
	'fields'      => array(
		'title'        => array( 'type' => 'text', 'label' => __( 'Titre (H2)', 'corbuilder' ) ),
		'subtitle'     => array( 'type' => 'text', 'label' => __( 'Sous-titre (H3)', 'corbuilder' ) ),
		'text'         => array( 'type' => 'textarea', 'label' => __( 'Paragraphe', 'corbuilder' ) ),
		'show_address' => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’adresse', 'corbuilder' ), 'default' => true ),
		'show_phone'   => array( 'type' => 'checkbox', 'label' => __( 'Afficher le téléphone', 'corbuilder' ), 'default' => true ),
		'show_email'   => array( 'type' => 'checkbox', 'label' => __( 'Afficher l’e-mail', 'corbuilder' ), 'default' => true ),
		'show_hours'   => array( 'type' => 'checkbox', 'label' => __( 'Afficher les horaires', 'corbuilder' ), 'default' => true ),
		'show_social'  => array( 'type' => 'checkbox', 'label' => __( 'Afficher les réseaux sociaux', 'corbuilder' ), 'default' => true ),
		'layout'       => array(
			'type'    => 'select',
			'label'   => __( 'Disposition', 'corbuilder' ),
			'choices' => array(
				'rows' => __( 'Sur 2 lignes (informations, puis carte en dessous)', 'corbuilder' ),
				'cols' => __( 'Sur 2 colonnes (informations à gauche, carte à droite)', 'corbuilder' ),
			),
			'default' => 'rows',
		),
		'map_shadow'   => array(
			'type'    => 'select',
			'label'   => __( 'Ombre de la carte', 'corbuilder' ),
			'choices' => array(
				'none'   => __( 'Aucune', 'corbuilder' ),
				'soft'   => __( 'Légère', 'corbuilder' ),
				'strong' => __( 'Prononcée', 'corbuilder' ),
			),
			'default' => 'none',
		),
		'show_map'     => array( 'type' => 'checkbox', 'label' => __( 'Afficher la carte (chargée seulement au clic)', 'corbuilder' ), 'default' => true ),
	) + corbuilder_color_choice_fields( 'icon_color', 'icon_color_custom', __( 'Couleur des icônes', 'corbuilder' ), 'secondary' ),
	'skip'        => function ( $d ) {
		return '' === $d['title'] && '' === $d['subtitle'] && '' === trim( (string) $d['text'] ) && '' === corbuilder_contact_info_html( $d );
	},
	'render'      => function ( $d ) {
		echo corbuilder_section_head_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput
		$html = corbuilder_contact_info_html( $d );
		if ( '' === $html ) {
			echo '<p class="reusable__empty">' . esc_html__( 'Renseigne tes coordonnées dans Personnaliser → Coordonnées.', 'corbuilder' ) . '</p>';
			return;
		}
		$css = corbuilder_color_choice_css( $d['icon_color'], $d['icon_color_custom'], 'secondary' );
		echo '<div class="contact-wrap"' . ( '' !== $css ? ' style="--icon-color:' . esc_attr( $css ) . '"' : '' ) . '>' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	},
);
